<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;



class DefaultController extends Controller
{
    /**
     * @Route("/homepage", name="homepage")
     */
    public function homepageAction(Request $request)
    {
        // replace this example code with whatever you need
        /* return $this->render('default/index.html.twig', [
            'base_dir' => realpath($this->getParameter('kernel.project_dir')).DIRECTORY_SEPARATOR,
        ]); */
        
        
        // return \FOS\RestBundle\View\View::create(['message' => 'test dynamic connexion']);

       /*  $em = $this->container->get('doctrine')->getManager('tenantdb');

        $mdf = $em->getMetadataFactory();
        $classes = $mdf->getAllMetadata();

        $schemaTool = new SchemaTool($em);
        $metadata = $em->getClassMetadata($classes);
        $sqlDiff = $schemaTool->getUpdateSchemaSql([$metadata], true); */


        //Loading Fixtures
        //$options = array('command' => 'doctrine:fixtures:load',"--append" => true);
        //$application->run(new \Symfony\Component\Console\Input\ArrayInput($options));

        $em = $this->getDoctrine()->getManager();
        $users = $em->getRepository('SadevUserBundle:User')->findAll();
        return \FOS\RestBundle\View\View::create($users);
    }


}
