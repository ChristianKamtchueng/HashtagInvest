<?php

namespace Sadev\UserBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SadevUserBundle extends Bundle
{
}
