<?php

namespace Sadev\UserBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class DefaultController extends Controller
{
    public function indexAction()
    {
        return $this->render('SadevUserBundle:Default:index.html.twig');
    }
}
