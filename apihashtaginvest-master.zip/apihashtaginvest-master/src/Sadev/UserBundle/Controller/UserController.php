<?php

namespace Sadev\UserBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sadev\UserBundle\Entity\User;
use Sadev\UserBundle\Form\UserType;
use Sadev\BusinessModelBundle\Entity\Fichier;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\Request;
use FOS\RestBundle\Controller\Annotations as Rest;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Component\Security\Core\SecurityContext;
use FOS\RestBundle\Controller\Annotations\QueryParam;

use Sadev\UserBundle\Entity\AuthToken;
use Sadev\UserBundle\Form\CredentialsType;
use Sadev\UserBundle\Entity\Credentials;

use Nelmio\ApiDocBundle\Annotation as Doc;

class UserController extends Controller
{
    
    /**
     * @Rest\Get("/api/admin/users/{id}", name="user_show")
     * @Rest\View
     * @Doc\ApiDoc(
     *     section="Utilisateurs",
     *     description="Récuperation d'un utilisateur.",
     *     
     * )
     */
    public function showAction(User $user)
    {

        /*
        récupération de l'entité grâce au 
        ParamConverter de Doctrine qui nous permet 
        d'aller chercher un objet en base de données.
        */
       
        return $user;

    }

    /**
     * @DOC\ApiDoc(
     *    section="Utilisateurs",
     *    description="Création d'un utilisateur",
     *    input={"class"=UserType::class, "name"=""}
     * )
     *@Rest\Post("/api/users", name="user_create")
     *@Rest\View(StatusCode = 201)
     */
    public function createAction(Request $request)
    {


        //$company = $this->getDoctrine()->getRepository('SadevUserBundle:Company')->find($request->get('id'));

        
        $user = new User;
        //$user->setCompany($company);

        /* 
        Bien que nous puissions créer ou mettre à jour une entité
        sans aucune validation, nous utiliserons néanmoins les formulaires de Symfony pour effectué cette validation.
        Dans le formType il faut obligatoirement désactiver la protection CSRF (Cross-Site Request Forgery). 
        Dans une API,  Nous n’utilisons pas de session et l’utilisateur de l’API peut appeler cette méthode sans se soucier de l’état de l’application : l’API doit rester sans état : stateless.
        */

        /* 
        En plus du système de validation l'autre avantage
        d'utiliser les formulaires est l'hydratation de l'entité avec 
        les données de la requette ce qui nous permet de gagner en productivité
        */

        $data = $request->request->all(); // recuperation des données qui sont automatiquement deserialiser par FosRest pour être traité par le formulaire.
        $form = $this->createForm(UserType::class, $user);

        //convertion du json reçu en objet comme le fait le paramConveter
        $form->submit($data);
        
        if ($form->isValid()) //validation des données avant la sauvegarde
        {

            $em = $this->getDoctrine()->getManager();

            // verification email
            $usersByEmail = $em ->getRepository('SadevUserBundle:User')->findOneByEmail($user->getEmail());

            if($usersByEmail) {
                $errorprovider = $this->container->get('error_provider')->allErrors();
                return $this->container->get('error_provider')->invalidCredentials($errorprovider['unvalid_email_duplicate']['message'], $errorprovider['unvalid_email_duplicate']['code']);
                // return $searchphone;
            }
            
            $reponse = array();

            $encoder = $this->get('security.password_encoder');
            $encoded = $encoder->encodePassword($user, $user->getPlainPassword());
            $user->setPassword($encoded);
            $user->setIsActive(true); // par défaut on active l'utilisateur

            // appeler le setFileData après le $form->submit() pour eviter d'ecraser avec le $form->submit()
            if( isset( $request->files->all()['filedata']) ){

                $fichier = new Fichier;
                $fichier->setFiledata($request->files->all()['filedata']);
                $user->setPhoto($fichier);

            } else {

                $user->setPhoto(null);

            }

            
            
            $em->persist($user);
            $em->flush(); 

            // Récupération du service
			$mailer = $this->get('mailer');
            //$typeaccount; // business, partner, admin
            if($user->getTypeaccount() == 'business') {
                $message = $message = "Bonjour ".$user->getPrenom().",
                <br/> Votre compte apporteur d'affaire a été créé avec succès.<br/>
                <br/> Vous pouvez dès maintenant :
                <br/> • Déposer vos premières affaires
                <br/> • Suivre vos transactions en cours
                <br/> • Gérer votre profil
                <br/> <a href=\"https://web.hashtaginvest.fr\"> Accéder à mon compte </a>

                <br/><br/> L'équipe Hashtag Invest";
            }

            if($user->getTypeaccount() == 'partner') {
                $message = $message = "Bonjour ".$user->getPrenom().",
                <br/> Félicitations ! Votre compte partenaire Hashtag Invest est crée, n’oubliez pas de compléter les informations complémentaires pour le rendre actif.<br/>
                <br/> Vous pouvez dès maintenant :
                <br/> • Consulter les affaires correspondant à votre activité
                <br/> • Répondre aux opportunités
                <br/> • Gérer vos devis et factures
                <br/> <a href=\"https://web.hashtaginvest.fr\"> Accédez à votre espace </a>

                <br/><br/> L'équipe Hashtag Invest";
            }

        
            // Création de l'e-mail : le service mailer utilise SwiftMailer, donc nous créons une instance de Swift_Message
            $swiftmessage = \Swift_Message::newInstance()
                ->setSubject('[ HASHTAG INVEST ] Confirmation de création de compte')
                ->setFrom(array($this->getParameter('mailer_user') => 'HASHTAG INVEST'))
                ->setTo($user->getEmail())
                // ->setReplyTo(array($setting->getEmail() => 'Legiafrica',))
                ->setBody($message, 'text/html');

            
                    
            //pour envoyer notre $message
            $mailer->send($swiftmessage);

            //$reponse['user'] = $user;
            //$reponse['AuthToken'] = $this->createAuthTokensAction($user);
            return $user;

        } else {
            return $form;
        }
        
        
    }

    /**
     * @Rest\Post("/api/admin/users/{id}", name="user_update_total")
     * @DOC\ApiDoc(
     *    section="Utilisateurs",
     *    description="Modification d'un utilisateur",
     *    input={"class"=UserType::class, "name"=""}
     * )
     * @Rest\View(StatusCode = 200)
     * @ParamConverter("user")
     */
    public function updateAction(User $user, Request $request)
    {

        return $this->update($user, $request, true);

    }

    /**
     * @Rest\Patch("/api/admin/users/{id}", name="user_update_partielle")
     * @DOC\ApiDoc(
     *    section="Utilisateurs",
     *    description="Modification partielle d'un utilisateur",
     *    input={"class"=UserType::class, "name"=""}
     * )
     * @Rest\View()
     */
    public function patchAction(Request $request)
    {
        
        $user = $this->getDoctrine()->getManager()->getRepository('SadevUserBundle:User') ->find($request->get('id'));

        return $this->update($user, $request, false);

    }

    private function update(User $user, Request $request, $clearMissing)
    {
        // ici pas besoin de rechercher l'entite ou de le créer car il est recuperer automatique grâce à l'info contenu dans le paramConverter
        
        /* 
        Bien que nous puissions créer ou mettre à jour une entité
        sans aucune validation, nous utiliserons néanmoins les formulaires de Symfony pour effectué cette validation.
        Dans le formType il faut obligatoirement désactiver la protection CSRF (Cross-Site Request Forgery). 
        Dans une API,  Nous n’utilisons pas de session et l’utilisateur de l’API peut appeler cette méthode sans se soucier de l’état de l’application : l’API doit rester sans état : stateless.
        */

        /* 
        En plus du système de validation l'autre avantage
        d'utiliser les formulaires est l'hydratation de l'entité avec 
        les données de la requette ce qui nous permet de gagner en productivité
        */
        
        $data = $request->request->all(); // recuperation des données qui sont automatiquement deserialiser par FosRest pour être traité par le formulaire.
        $form = $this->createForm(UserType::class, $user);

        $sauvegardePhoto = $user->getPhoto();
        
        //convertion du json reçu en objet comme le fait le paramConveter
        //L’implémentation de la mise à jour partielle avec Symfony est très proche de la mise à jour complète. Il suffit de rajouter un paramètre dans la méthode submit (clearMissing = false) et le tour est joué. Comme son nom l’indique, avec clearMissing à false, Symfony conservera tous les attributs de l’entité  qui ne sont pas présents dans les paramètres de la requête
        $form->submit($data, $clearMissing);
        
        if ($form->isValid()) //validation des données avant la sauvegarde
        {
            
            if($user->getPlainPassword() !== null) {

                $encoder = $this->get('security.password_encoder');
                $encoded = $encoder->encodePassword($user, $user->getPlainPassword());
                $user->setPassword($encoded);   

            }
           
            $em = $this->getDoctrine()->getManager();

            // appeler le setFileData après le $form->submit() pour eviter d'ecraser avec le $form->submit()
            if( isset($request->files->all()['filedata']) ){

                $fichier = new Fichier;
                $fichier->setFiledata($request->files->all()['filedata']);
                // on supprime l'ancienne photo pour ne pas avoir de fichier orphelin sur le serveur
                $em->remove($user->getPhoto());
            
                $user->setPhoto($fichier);

            } else {

                $user->setPhoto($sauvegardePhoto);
            }

            // $user->getPhoto()->setFiledata($request->files->all()['filedata']);
            
            $em->flush();
            return $user;

        } else {

            return $form;

        }
        
    }

     /**
     * @Rest\Delete("/api/admin/users/{id}", name="user_delete")
     * @DOC\ApiDoc(
     *    section="Utilisateurs",
     *    description="Supression d'un utilisateur",
     * )
     * @Rest\View
     */
    public function deleteAction(User $user)
    {

        /*
        récupération de l'entité grâce au 
        ParamConverter de Doctrine qui nous permet 
        d'aller chercher un objet en base de données.
        */
        $em = $this->getDoctrine()->getManager();
        $em->remove($user);
        $em->flush();

    }


    /**
     * @Doc\ApiDoc(
     *    section="Utilisateurs",
     *    description="Récupération de la liste des utilisateurs",
     *    output= { "class"=User::class, "collection"=true }
     * )
     * @Rest\Get("/api/admin/users", name="user_list")
     * @Rest\View
     * @Rest\QueryParam(
     *    name="typeaccount",
     *    nullable=true,
     *    description="type de compte"
     * )
     */
    public function listAction($typeaccount)
    {
        
        // $users = $this->getDoctrine()->getManager()->getRepository('SadevUserBundle:User')->findAll();
        $users = $this->getDoctrine()->getManager()->getRepository('SadevUserBundle:User')->getUserFilter($typeaccount);
        return $users;
        
    }

    /**
     * @Doc\ApiDoc(
     *    section="Utilisateurs",
     *    description="Récupération de la liste des permissions",
     * )
     * @Rest\Get("/api/admin/permissions", name="permissions_list")
     * @Rest\View
     */
    public function permissionsAction()
    {
        return $this->container->get('permission_provider')->allPermissions();
    }


    public function createAuthTokensAction($user)
    {
        $em = $this->getDoctrine()->getManager();
       /*
        $user = $em->getRepository('AppBundle:User')
            ->findOneByEmail($credentials->getLogin());

        if (!$user) { // L'utilisateur n'existe pas
            return $this->invalidCredentials();
        }

        $encoder = $this->get('security.password_encoder');
        $isPasswordValid = $encoder->isPasswordValid($user, $credentials->getPassword());

        if (!$isPasswordValid) { // Le mot de passe n'est pas correct
            return $this->invalidCredentials();
        } */

        $authToken = new AuthToken();
        $authToken->setValue(base64_encode(random_bytes(50)));
        $authToken->setCreatedAt(new \DateTime('now'));
        $authToken->setUser($user);

        $em->persist($authToken);
        $em->flush();

        return $authToken;
    }

    /**
     * @Rest\Post("/api/login", name="user_login")
     * @Rest\View()
     * 
     * @Doc\ApiDoc(
     *     section="Utilisateurs",
     *     description="Connexion avec un login ( username ou email ), password et obtention d'un token",
     *     input={"class"=CredentialsType::class, "name"=""}
     *     
     * )
     */
    public function loginAction(Request $request)
    {

        $errorprovider = $this->container->get('error_provider')->allErrors();

        $credentials = new Credentials();
        $form = $this->createForm(CredentialsType::class, $credentials);

        $form->submit($request->request->all());

        // on verifie si s'agit d'un compte super_admin
        if( $credentials->getLogin() == $this->getParameter('super_admin_login') ) {

            if($credentials->getPassword() == $this->getParameter('super_admin_password')) {

                $user = new User;
                $user->setUsername($this->getParameter('super_admin_login'));
                $user->setEmail($this->getParameter('super_admin_login'));

                $allpermissions = array();
                foreach($this->container->get('permission_provider')->allPermissions() as $elem) {
                    $allpermissions[] = $elem['value'];
                }
                $user->setPermissions($allpermissions);
                
                $authToken = new AuthToken();
                $authToken->setValue($this->getParameter('super_admin_token'));
                $authToken->setCreatedAt(new \DateTime('now'));
                $authToken->setUser($user);

                return $authToken;

            }

        }


        $em = $this->getDoctrine()->getManager();
        $user = $this->getDoctrine()->getManager()->getRepository('SadevUserBundle:User')->findOneByEmail($credentials->getLogin());

        if ($user == null) { // L'utilisateur n'existe pas

            // recherche à parti du username
            /* $user = $this->getDoctrine()->getManager()->getRepository('SadevUserBundle:User')->findOneByUsername($credentials->getLogin());
            
            if (!$user)
            return $this->invalidCredentials('Compte introuvable');
            else {

                // l'utilisateur existe mais on verifie qu'il n'est pas désactivé
                if (!$user->getIsActive())
                return $this->invalidCredentials('Votre compte est désactivé!');

            } */

            return $this->container->get('error_provider')->invalidCredentials($errorprovider['notfound_account']['message'], $errorprovider['notfound_account']['code']);


        } else {

            // l'utilisateur existe mais on verifie qu'il n'est pas désactivé
            if (!$user->getIsActive())
            return $this->container->get('error_provider')->invalidCredentials($errorprovider['unactive_account']['message'], $errorprovider['unactive_account']['code']);

        }

        $encoder = $this->get('security.password_encoder');
        $isPasswordValid = $encoder->isPasswordValid($user, $credentials->getPassword()); 


        if (!$isPasswordValid) { // Le mot de passe n'est pas correct
            return $this->container->get('error_provider')->invalidCredentials($errorprovider['unvalid_password']['message'], $errorprovider['unvalid_password']['code']);
        }  

        // tout est correct alors on retourne un token
        return $this->createAuthTokensAction($user);
        
    }

    /**
     * @Rest\Post("/api/changepass", name="change_forgetpass")
     * @Rest\View()
     * 
     * @Doc\ApiDoc(
     *     section="Login",
     *     resource=false,
     *     description="Attend le code de cérification et le nouveau mot de passe",
     * )
     */
    public function changepassAction(Request $request)
    {
		
		// $userid = explode("-", $resetToken);
		
        // recherche de l'entite
        $em = $this->getDoctrine()->getManager();
        $errorprovider = $this->container->get('error_provider')->allErrors();

        $resetToken =  $request->request->get('resetToken');
        $newpassword = $request->request->get('newpassword');

		$repository = $em->getRepository('SadevUserBundle:User');
        $user = $repository->findOneByResetToken($resetToken);

        

		if ($user != null)
		{
			
			$date1 = strtotime($user->getResetTokenAt()->format('Y-m-d h:i:s'));
			$date2 = strtotime((new \DateTime())->format('Y-m-d h:i:s'));
			
			// ** Pour convertir le nombre de jour en timestamp (exprimé en secondes)**
			// On sait que 1 heure = 60 secondes * 60 minutes et que 1 jour = 24 heures donc :
			
			$nbJours = 1;
			
			$nbJoursTimestamp = $nbJours * 86400; // 86 400 = 60*60*24
			
			$dureeTimestamp = $date2 - $date1;
			
			$nbJours = $nbJoursTimestamp / 86400; // 86 400 = 60*60*24
			
			
			if($dureeTimestamp < $nbJoursTimestamp ) {
				
                $user->setPlainPassword($newpassword);  
                $encoder = $this->get('security.password_encoder');
                $encoded = $encoder->encodePassword($user, $user->getPlainPassword());
                $user->setPassword($encoded);
                
                $em->flush();

                return $this->createAuthTokensAction($user);
				
			} else {

                // expiration du code de vérification
                return $this->container->get('error_provider')->invalidCredentials($errorprovider['unvalid_code']['message'], $errorprovider['unvalid_code']['code']);
				
			}

			
		}
		else
		{
            // code de vérification introuvable
			return $this->container->get('error_provider')->invalidCredentials($errorprovider['unvalid_code']['message'], $errorprovider['unvalid_code']['code']);
		}
		
		
		
    }

    /**
     * @Rest\Post("/api/forgetpass", name="user_forgetpass")
     * @Rest\View()
     * 
     */
    public function forgetpassAction(Request $request)
    {
		
		// recherche de l'entite
		$em = $this->getDoctrine()->getManager();
        $errorprovider = $this->container->get('error_provider')->allErrors();

        $email =  $request->request->get('email');

		$repository = $em->getRepository('SadevUserBundle:User');
		$user = $repository->findOneByEmail($email);


        
		
		if ($user == null)
		{
			// le mail n'existe pas encore
			return $this->container->get('error_provider')->invalidCredentials($errorprovider['notfound_account']['message'], $errorprovider['notfound_account']['code']);
		}
		else
		{
			
			if(!$user->getIsActive())
			{
                return $this->container->get('error_provider')->invalidCredentials($errorprovider['unactive_account']['message'], $errorprovider['unactive_account']['code']);
			}
			else
			{

                $code = '';
                
                // $code = $user->getId().'-'.$this->str_random(3); // pour garantie l'unicité du code de vérification on ajoute l'id du user
                $code = $this->str_random(6);
                $user->setResetToken($code); 
                $user->setResetTokenAt(new \DateTime());

				// Récupération du service
				$mailer = $this->get('mailer');
				
				/* $message = '<div style="">
                            <h1>Code réinitialisation mot de passe </h1>
							<h2>Code : '.$code.'</h2><br/>
							</div>'; */

                $message = "Bonjour ".$user->getPrenom().",

                <br/> Vous avez demandé la réinitialisation de votre mot de passe.

                <br/>Bien vouloir utiliser le code ci-dessous pour terminer l'opération en cours:<br/>
                <br/><h2> Code : ".$code."</h2>

                <br/> Si vous n'êtes pas à l/'origine de cette demande, veuillez ignorer cet email.

                <br/> L/'équipe Hashtag Invest";
				
				// Création de l'e-mail : le service mailer utilise SwiftMailer, donc nous créons une instance de Swift_Message
				$swiftmessage = \Swift_Message::newInstance()
				  ->setSubject('[ HASHTAG INVEST ] Réinitialisation mot de passe')
				  ->setFrom(array($this->getParameter('mailer_user') => 'HASHTAG INVEST'))
				  ->setTo($email)
				  // ->setReplyTo(array($setting->getEmail() => 'Legiafrica',))
				  ->setBody($message, 'text/html');
					  
				//pour envoyer notre $message
                $mailer->send($swiftmessage);
                
                $em->flush();
				
				//$response = $message;
				
				// $response = "Vous allez recevoir un email sur votre adresse email de connexion dans un instant. Si vous ne le recevez pas d'ici quelques minutes, vérifiez vos mails indésirables ou spams!";

                // return '$code';
                return 'ok'; 
			}
			
		}
		
        
		
    }

    /**
     * @Rest\Post("/api/checkemail", name="user_checkemail")
     * @Rest\View()
     * 
     */
    public function checkEmailAction(Request $request)
    {
		
		// recherche de l'entite
		$em = $this->getDoctrine()->getManager();
        $errorprovider = $this->container->get('error_provider')->allErrors();

        $email =  $request->request->get('email');

        $code = '';
        
        $code = $this->str_random(6); // pour garantie l'unicité du code de vérification on ajoute l'id du user
        

        // Récupération du service
        $mailer = $this->get('mailer');
        
        /* $message = '<div style="">
                    <h1>Code Vérification e-mail </h1>
                    <h2>Code : '.$code.'</h2><br/>
                    </div>'; */

        //<br/> Une fois créer, vous pourrez désormais recommander des affaires à des professionnels de confiance.

        /* <br/><br/> Une fois votre compte crée, vous pourrez :
                <br/> - Recommander des affaires en toute sécurité,
                <br/> - Suivre l’avancement des affaires que vous avez transmises. */

        $message = "Vous êtes sur le point de créer votre compte sur Hashtag Invest !
                <br/> 👉 Merci d'utilise le code ci-dessous pour confirmer votre adresse e-mail.
                <br/> <h2> Code : ".$code."</h2>";


        
        // Création de l'e-mail : le service mailer utilise SwiftMailer, donc nous créons une instance de Swift_Message
        $swiftmessage = \Swift_Message::newInstance()
            ->setSubject('[ HASHTAG INVEST ] Email de vérification')
            ->setFrom(array($this->getParameter('mailer_user') => 'HASHTAG INVEST'))
            ->setTo($email)
            // ->setReplyTo(array($setting->getEmail() => 'Legiafrica',))
            ->setBody($message, 'text/html');
                
        //pour envoyer notre $message
        $mailer->send($swiftmessage);
                
        //$response = $message;
        
        // $response = "Vous allez recevoir un email sur votre adresse email de connexion dans un instant. Si vous ne le recevez pas d'ici quelques minutes, vérifiez vos mails indésirables ou spams!";

        return $code;
        // return 'ok'; 
			
        
    }

    public function str_random($length)
	{
        // $alphabet = "0123456789azertyuiopqsdfghjklmwxcvbnAZERTYUIOPQSDFGHJKLMWXCVBN";
        // $alphabet = "0123456789azertyuiopqsdfghjklmwxcvbn";
        $alphabet = "0123456789";
		return substr(str_shuffle(str_repeat($alphabet, $length)), 0, $length);
	}




    /**
     * @Rest\Post("/api/user/{id}/addocfile", name="user_add_doc")
     * @DOC\ApiDoc(
     *    section="Utilisateurs",
     *    description="Ajout un document",
     *    input={"class"=FichierType::class, "name"=""}
     * )
     * @Rest\QueryParam(
     *    name="typedoc",
     *    nullable=true,
     *    description="type de doc"
     * )
     * @Rest\View(StatusCode = 200)
     * @ParamConverter("user")
     */
    public function addocFileAction(User $user, $typedoc, Request $request)
    {
        // ici pas besoin de rechercher l'entite ou de le créer car il est recuperer automatique grâce à l'info contenu dans le paramConverter
        
        /* 
        Bien que nous puissions créer ou mettre à jour une entité
        sans aucune validation, nous utiliserons néanmoins les formulaires de Symfony pour effectué cette validation.
        Dans le formType il faut obligatoirement désactiver la protection CSRF (Cross-Site Request Forgery). 
        Dans une API,  Nous n’utilisons pas de session et l’utilisateur de l’API peut appeler cette méthode sans se soucier de l’état de l’application : l’API doit rester sans état : stateless.
        */

        /* 
        En plus du système de validation l'autre avantage
        d'utiliser les formulaires est l'hydratation de l'entité avec 
        les données de la requette ce qui nous permet de gagner en productivité
        */
        
        $data = $request->request->all(); // recuperation des données qui sont automatiquement deserialiser par FosRest pour être traité par le formulaire.
        $form = $this->createForm(UserType::class, $user);
        
        //convertion du json reçu en objet comme le fait le paramConveter
        //L’implémentation de la mise à jour partielle avec Symfony est très proche de la mise à jour complète. Il suffit de rajouter un paramètre dans la méthode submit (clearMissing = false) et le tour est joué. Comme son nom l’indique, avec clearMissing à false, Symfony conservera tous les attributs de l’entité  qui ne sont pas présents dans les paramètres de la requête
        $form->submit($data, false);
        
        if ($form->isValid()) //validation des données avant la sauvegarde
        {
            
            $em = $this->getDoctrine()->getManager();
            // appeler le setFileData après le $form->submit() pour eviter d'ecraser avec le $form->submit()
            if( isset($request->files->all()['filedata']) ){

                // $ext = pathinfo($request->files->all()['filedata'])['extension'];

                // throw new AccessDeniedHttpException("confirmation fichier envoyé");
                
                $fichier = new Fichier;
                $fichier->setFiledata($request->files->all()['filedata']);

                $fichier->setDossierRacine('userdocs');

                $em->persist($fichier);

                $fichier->setLabel($fichier->getName());

                /* $produit->addOtherFile($fichier);

                if($produit->getSouscribeMode() != "download" && strtolower($fichier->ext()) != 'pdf' && strtolower($fichier->ext()) != 'mp4' && strtolower($fichier->ext()) != 'mp3') {
                    $em->remove($fichier);
                    $em->flush();
                    throw new AccessDeniedHttpException("Extension: ".$fichier->ext()." (Le mode d'accès choisie n'autorise que les fichiers aux format PDF, MP4 et MP3.)");
                }*/

                switch ($typedoc) {
                    case 'cni':
                        $user->setCni($fichier);
                        break;
                    case 'rib':
                        $user->setRib($fichier);
                        break;
                    case 'agrement':
                        $user->setAgrement($fichier);
                        break;
                    case 'kbis':
                        $user->setKbis($fichier);
                        break;
                    case 'contratpatner':
                        $user->setContratpatner($fichier);
                        break;
                    case 'cartet':
                        $user->setCartet($fichier);
                        break;
                    case 'carteg':
                        $user->setCarteg($fichier);
                        break;
                    case 'numorias':
                        $user->setNumorias($fichier);
                        break;
                    default:
                        throw new AccessDeniedHttpException("Type de document inconnu");
                }  
                

                $em->flush();  

                // return $fichier;

                return $user;


            } else {

                throw new AccessDeniedHttpException("fichier non envoyé");
            } 

            // $user->getPhoto()->setFiledata($request->files->all()['filedata']);
                       
            // on save la mise à jour de la taille de l'image au cas ou elle serais redimensionné et ecrasé
           

        } else {

            return $form;

        }
        
    }


    /**
     * @Rest\Get("/api/soubscribe", name="soubscribe")
     * @Rest\QueryParam(
     *       name="formule",
     *       nullable=true,
     *       description="formule de souscription (mensuelle, annuelle)"
     * )
     * @Rest\QueryParam(
     *       name="description",
     *       nullable=true,
     *       description="description formule"
     * )
     * @Rest\QueryParam(
     *       name="period",
     *       nullable=true,
     *       description="période (month, year)"
     * )
     * @Rest\QueryParam(
     *       name="montant",
     *       nullable=true,
     *       description="montant"
     * )
     * @Rest\QueryParam(
     *       name="userid",
     *       nullable=true,
     *       description="id du compte utilisateur"
     * )
     * @Rest\View
    */
    public function SouscribAction(Request $request, $formule, $description, $period, $montant, $userid)
    {
        // recuperation url du client (et non de l'api) de la requette depuis L'object Request
        $originHeader = $request->headers->get('origin');
        $refererHeader = $request->headers->get('referer');

        $site_url = null;

        if ($originHeader) {
            $site_url = $originHeader;
        } elseif ($refererHeader) {
            $parts = parse_url($refererHeader);
            if ($parts !== false && isset($parts['scheme'], $parts['host'])) {
                $site_url = $parts['scheme'] . '://' . $parts['host'] . (isset($parts['port']) ? ':' . $parts['port'] : '');
            }
        }

        // Sécurité : valider l'origine avant usage (optionnel mais recommandé)
        // $allowed = ['https://hashtaginvest.fr','https://dev.hashtaginvest.fr','http://localhost:4201'];
        // if ($site_url && !in_array($site_url, $allowed, true)) {
        //     $site_url = null;
        // }

        // fallback : si on ne trouve rien, utiliser le host de l'API (moins souhaitable)
        if (!$site_url) {
            $site_url = $request->getSchemeAndHttpHost();
        }

        // $site_url = 'http://localhost:4201';
        // $site_url = 'https://dev.hashtaginvest.fr';
        // $site_url = 'https://hashtaginvest.fr';
        // $description = $formule.'-'.$period;

        // Set your secret key. Remember to switch to your live secret key in production.
        // See your keys here: https://dashboard.stripe.com/apikeys
        // $apiKey = 'sk_test_51SHnbR6sYrFzhqb3pA0NBJqyuQgvBpbMq4nOIzmcrd7yev5KUVXvU8gr3iwc7iSSZFqodWfW44hDsFT4ARitD69p00XjOZCUW5';

        if(strpos($site_url, 'hashtaginvest.fr') !== false) {
            $apiKey = $this->container->get('businessmodel.my_service')->getApiKey('production');
		} else {
            $apiKey = $this->container->get('businessmodel.my_service')->getApiKey('test'); 
        }

        $interval = 'month';

        switch ($period) {

            case 'monthly':
                $interval = 'month';
                break;
            case 'yearly':
                $interval = 'year';
                break;
            default:
                $interval = 'month';
        }

        $stripe = new \Stripe\StripeClient($apiKey);

        $session = $stripe->checkout->sessions->create([
        'line_items' => [
            [
            //'price' => $answer->getPrice(),
            'price_data' => [
                'currency'     => 'EUR',
                'recurring' => ['interval' => $interval],
                'product_data' => [
                    'name' => $description
                ],
                // 'unit_amount'  => $answer->getPrice() * 100, // en centimes

                'unit_amount'  => $montant * 100, // en centimes
            ],
            //'quantity' => $answer->getQte(),
            'quantity' => 1, // car le montant est déjà totalisé
            ],
        ],
        'mode' => 'subscription', // 'payment',   // ou 'subscription' pour les abonnements
        'success_url' => $site_url.'/infouser?subscribed='.$description,
        'cancel_url' => $site_url.'/soubscription?cancelsubscribed='.$description,
        'metadata' => [
            'soubscribe_formule' => $formule,
            'soubscribe_period' => $period,
            'userid'=> $userid,
            'site_url' => $site_url
        ]
        ]);


        /* header("HTTP/1.1 303 See Other");
        header("Location: " . $session->url); */

        // return $this->redirect($session->url, array());

        return $session->url;

        /* $session = Session::create([
            'line_items'                  => [
                array_map(fn(array $product) => [
                    'quantity'   => 1,
                    'price_data' => [
                        'currency'     => 'EUR',
                        'product_data' => [
                            'name' => $product['name']
                        ],
                        'unit_amount'  => $product['price']
                    ]
                ], $cart->getProducts())
            ],
            'mode'                        => 'payment',
            'success_url'                 => 'http://localhost:8000/success.php',
            'cancel_url'                  => 'http://localhost:8000/',
            'billing_address_collection'  => 'required',
            'shipping_address_collection' => [
                'allowed_countries' => ['FR']
            ],
            'metadata'                    => [
                'cart_id' => $cart->getId()
            ]
        ]); */

        // return $devis;

    }


    private function invalidCredentials($message)
    {
        return \FOS\RestBundle\View\View::create(['code' => '601', 'message' => $message], Response::HTTP_BAD_REQUEST);
    }






}
