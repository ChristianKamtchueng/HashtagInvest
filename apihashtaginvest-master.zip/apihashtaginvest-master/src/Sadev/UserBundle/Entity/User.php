<?php

namespace Sadev\UserBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use JMS\Serializer\Annotation\Type;
use JMS\Serializer\Annotation as Serializer;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Security\Core\Encoder\PasswordEncoderInterface;
use JMS\Serializer\Annotation\VirtualProperty;




/**
 * User
 *
 * @ORM\Table(name="user")
 * @ORM\Entity(repositoryClass="Sadev\UserBundle\Repository\UserRepository")
 * @ORM\InheritanceType("JOINED")
 * @ORM\DiscriminatorColumn(name="discriminator", type="string")
 * @ORM\DiscriminatorMap({"user"="User"})
 * @Serializer\ExclusionPolicy("ALL")
 * 
 */


class User implements UserInterface
{
    
     /**
     * Identifiant unique d'un utilisateur
     * @var int
     * 
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * 
     * @Serializer\Expose
     * @Serializer\Since("2.0")
     */
    protected $id;

    /**
     * Nom d'utilisateur dans le système
     * 
     * @var string
     *
     * @ORM\Column(name="username", type="string", length=255, unique=true, nullable=true)
     * 
     * @Serializer\Expose
     * @Serializer\Since("1.0")
     */
    private $username;

    /**
     * Adresse Email
     * 
     * @var string
     *
     * @ORM\Column(name="email", type="string", length=255, unique=true)
     * @Assert\Email()
     * 
     * @Serializer\Expose
     * @Serializer\Since("1.0")
     */
    private $email;

     /**
     * Date de creation de l'info
     * 
     * @var \DateTime
     *
     * @ORM\Column(name="dateCreate", type="datetime", nullable=true)
     * @Type("DateTime<'Y-m-d H:i'>")
     * @Serializer\Expose
     */
    protected $dateCreate;


    /**
     * Date de modification de l'info
     * 
     * @var \DateTime
     *
     * @ORM\Column(name="dateModif", type="datetime", nullable=true)
     * @Type("DateTime<'Y-m-d H:i'>")
     * @Serializer\Expose
     */
    protected $dateModif;


    /**
     * @ORM\Column(type="string")
     * 
     * 
     * @Serializer\Since("2.0")
     */
    protected $password;



    protected $plainPassword;


    /**
     * @var string
     *
     * @ORM\Column(name="salt", type="string", length=255, nullable=true)
     */
    private $salt;
	
	
	/**
     * @ORM\Column(name="is_active", type="boolean")
     * 
     * @Serializer\Expose
     * 
     */
    private $isActive;

    /**
     * @var array
     *
     * @ORM\Column(name="roles", type="array", nullable=false)
     * 
     * @Serializer\Expose
     * 
     */
    private $roles;


    /**
    * @ORM\OneToMany(targetEntity="Sadev\UserBundle\Entity\AuthToken", mappedBy="user", cascade={"remove"})
	*/
	private $tokens; // Ici est au pluriel,


    /**
     * @ORM\OneToOne(targetEntity="Sadev\BusinessModelBundle\Entity\Fichier", cascade={"remove", "persist"})
     * 
     * @ORM\JoinColumn(nullable=true)
     * 
     * @Serializer\Expose
     * 
     */
    private $photo;


    /**
     * @var text
     *
     * @ORM\Column(name="firebaseNotifToken", type="text", nullable=true)
     * @Serializer\Expose
     */
    private $firebaseNotifToken;

    /**
     * @var text
     *
     * @ORM\Column(name="photobase64", type="text", nullable=true)
     * @Serializer\Expose
     */
    private $photobase64;


    


    /**
     * @var string
     *
     * @ORM\Column(name="nom", type="string", length=255)
     * @Serializer\Expose
     */
    private $nom;

    /**
     * @var string
     *
     * @ORM\Column(name="prenom", type="string", length=255)
     * @Serializer\Expose
     */
    private $prenom;

    /**
     * @var string
     *
     * @ORM\Column(name="adresse", type="text", nullable=true)
     * @Serializer\Expose
     */
    private $adresse;

    /**
     * @var string
     *
     * @ORM\Column(name="telephone", type="string", length=255, nullable=true)
     * @Serializer\Expose
     */
    private $telephone;


    /**
     * @var \DateTime
     * @Assert\GreaterThanOrEqual("-120 years")
     * @ORM\Column(name="dateNaissance", type="datetime", nullable=true)
     * @Type("DateTime<'Y-m-d'>")
     * @Serializer\Expose
     */
    
    protected $dateNaissance;


    /**
     * @var integer
     *
     * @ORM\Column(name="civility", type="string", length=255, nullable=true)
     * @Serializer\Expose
     */
    private $civility;

    /**
     * @var array
     *
     * @ORM\Column(name="permissions", type="array", nullable=true)
     * 
     * @Serializer\Expose
     * 
     */
    private $permissions;


    /**
     * @var string
     *
     * @ORM\Column(name="company", type="string", length=255, nullable=true)
     * @Serializer\Expose
     */
    private $company;


    /**
     * @var string
     *
     * @ORM\Column(name="region", type="string", length=255 , nullable=true)
     * @Serializer\Expose
     */
    private $region;



    /**
     * @ORM\OneToMany(targetEntity="Sadev\BusinessModelBundle\Entity\Activity", mappedBy="partner")
     * @Serializer\Expose
    */
    private $activities;





    /**
     * @var string
     *
     * @ORM\Column(name="typeaccount", type="string", length=255, options={"default":"business"})
     * @Serializer\Expose
     */
    private $typeaccount; // business, partner, admin
    

    /**
     * @var string
     *
     * @ORM\Column(name="metier", type="string", length=255, nullable=true)
     * @Serializer\Expose
     */
    private $metier;


    /**
     * @var string
     *
     * @ORM\Column(name="speciality", type="string", length=255, nullable=true)
     * @Serializer\Expose
     */
    private $speciality;


    /**
     * @var string
     *
     * @ORM\Column(name="expert_name", type="string", length=255, nullable=true)
     * @Serializer\Expose
     */
    private $expertName;


    /**
     * @var string
     *
     * @ORM\Column(name="ville", type="string", length=255, nullable=true)
     * @Serializer\Expose
     */
    private $ville;
    

    /**
     * @var string
     *
     * @ORM\Column(name="telephonepro", type="string", length=255, nullable=true)
     * @Serializer\Expose
     */
    private $telephonepro;


    /**
     * @var string
     *
     * @ORM\Column(name="siret", type="string", length=255, nullable=true)
     * @Serializer\Expose
     */
    private $siret;


    /**
     * @var string
     *
     * @ORM\Column(name="iban", type="string", length=255, nullable=true)
     * @Serializer\Expose
     */
    private $iban;

    /**
     * @var string
     *
     * @ORM\Column(name="bic", type="string", length=255, nullable=true)
     * @Serializer\Expose
     */
    private $bic;



    /**
     * @ORM\OneToOne(targetEntity="Sadev\BusinessModelBundle\Entity\Fichier", cascade={"remove", "persist"})
     * @ORM\JoinColumn(nullable=true)
     * @Serializer\Expose
     */
    private $cni;

    /**
     * @ORM\OneToOne(targetEntity="Sadev\BusinessModelBundle\Entity\Fichier", cascade={"remove", "persist"})
     * @ORM\JoinColumn(nullable=true)
     * @Serializer\Expose
     */
    private $agrement;

    /**
     * @ORM\OneToOne(targetEntity="Sadev\BusinessModelBundle\Entity\Fichier", cascade={"remove", "persist"})
     * @ORM\JoinColumn(nullable=true)
     * @Serializer\Expose
     */
    private $rib;

    /**
     * @ORM\OneToOne(targetEntity="Sadev\BusinessModelBundle\Entity\Fichier", cascade={"remove", "persist"})
     * @ORM\JoinColumn(nullable=true)
     * @Serializer\Expose
     */
    private $kbis;

    /**
     * @ORM\OneToOne(targetEntity="Sadev\BusinessModelBundle\Entity\Fichier", cascade={"remove", "persist"})
     * @ORM\JoinColumn(nullable=true)
     * @Serializer\Expose
     */
    private $contratpatner;

    /**
     * @ORM\OneToOne(targetEntity="Sadev\BusinessModelBundle\Entity\Fichier", cascade={"remove", "persist"})
     * @ORM\JoinColumn(nullable=true)
     * @Serializer\Expose
     */
    private $cartet;

    /**
     * @ORM\OneToOne(targetEntity="Sadev\BusinessModelBundle\Entity\Fichier", cascade={"remove", "persist"})
     * @ORM\JoinColumn(nullable=true)
     * @Serializer\Expose
     */
    private $carteg;

    /**
     * @ORM\OneToOne(targetEntity="Sadev\BusinessModelBundle\Entity\Fichier", cascade={"remove", "persist"})
     * @ORM\JoinColumn(nullable=true)
     * @Serializer\Expose
     */
    private $numorias;


    /**
     * @var string
     *
     * @ORM\Column(name="resetToken", type="string", length=255, unique=true, nullable=true)
     */
    private $resetToken;
	
	/**
     * @var \DateTime
     *
     * @ORM\Column(name="resetTokenAt", type="datetime", nullable=true)
     */
    private $resetTokenAt;


    /**
     * @var string
     *
     * @ORM\Column(name="formule", type="string", length=255, unique=true, nullable=true)
     * @Serializer\Expose
     */
    private $formule; // synergie, alliance, elan


    /**
     * @var \DateTime
     *
     * @ORM\Column(name="dateExpiration", type="datetime", nullable=true)
     * @Serializer\Expose
     */
    private $dateExpiration; // date d'expiration de l'abonnement

    /**
    * @ORM\OneToMany(targetEntity="Sadev\BusinessModelBundle\Entity\SoubscriptionPayment", mappedBy="user")
	*/
    private $soubscriptionpayment;


    
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->dateCreate = new \DateTime();
        $this->isActive = true;
    }

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    
    /**
     * Set username
     *
     * @param string $username
     *
     * @return User
     */
    public function setUsername($username)
    {
        $this->username = $username;

        return $this;
    }

    /**
     * Get username
     *
     * @return string
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * Set email
     *
     * @param string $email
     *
     * @return User
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }

     /**
     * Set dateCreate
     *
     * @param \DateTime $dateCreate
     *
     * @return Data
     */
    public function setDateCreate($dateCreate)
    {
        $this->dateCreate = $dateCreate;

        return $this;
    }

    /**
     * Get dateCreate
     *
     * @return \DateTime
     */
    public function getDateCreate()
    {
        return $this->dateCreate;
    }


    /**
     * Set dateModif
     *
     * @param \DateTime $dateModif
     *
     * @return Data
     */
    public function setDateModif($dateModif)
    {
        $this->dateModif = $dateModif;

        return $this;
    }

    /**
     * Get dateModif
     *
     * @return \DateTime
     */
    public function getDateModif()
    {
        return $this->dateModif;
    }


    /**
     * Set password
     *
     * @param string $password
     *
     * @return User
     */
    public function setPassword($password)
    {
        $this->password = $password;

        return $this;
    }

    /**
     * Get password
     *
     * @return string
     */
    public function getPassword()
    {
        return $this->password;
    }

    public function getPlainPassword()
    {
        return $this->plainPassword;
    }
 
    public function setPlainPassword($plainPassword)
    {
        $this->plainPassword = $plainPassword;
 
        return $this;
    }

    /**
     * Set roles
     *
     * @param array $roles
     *
     * @return User
     */
    public function setRoles($roles)
    {
        $this->roles = $roles;

        return $this;
    }

    /**
     * Get roles
     *
     * @return array
     */
    public function getRoles()
    {
        return [];
    }


    

    
    /**
     * Set salt
     *
     * @param string $salt
     *
     * @return User
     */
    public function setSalt($salt)
    {
        $this->salt = $salt;

        return $this;
    }

    /**
     * Get salt
     *
     * @return string
     */
    public function getSalt()
    {
        return null;
    }

    /**
     * Set isActive
     *
     * @param boolean $isActive
     *
     * @return User
     */
    public function setIsActive($isActive)
    {
        $this->isActive = $isActive;

        return $this;
    }

    /**
     * Get isActive
     *
     * @return boolean
     */
    public function getIsActive()
    {
        return $this->isActive;
    }

    
    public function eraseCredentials()
    {
        // Suppression des données sensibles
        $this->plainPassword = null;
    }



    
    /**
     * Add token
     *
     * @param \Sadev\UserBundle\Entity\AuthToken $token
     *
     * @return User
     */
    public function addToken(\Sadev\UserBundle\Entity\AuthToken $token)
    {
        $this->tokens[] = $token;

        return $this;
    }

    /**
     * Remove token
     *
     * @param \Sadev\UserBundle\Entity\AuthToken $token
     */
    public function removeToken(\Sadev\UserBundle\Entity\AuthToken $token)
    {
        $this->tokens->removeElement($token);
    }

    /**
     * Get tokens
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getTokens()
    {
        return $this->tokens;
    }

    /**
     * Set photo
     *
     * @param \Sadev\BusinessModelBundle\Entity\Fichier $photo
     *
     * @return User
     */
    public function setPhoto(\Sadev\BusinessModelBundle\Entity\Fichier $photo = null)
    {
        $this->photo = $photo;

        return $this;
    }

    /**
     * Get photo
     *
     * @return \Sadev\BusinessModelBundle\Entity\Fichier
     */
    public function getPhoto()
    {
        return $this->photo;
    }

    /**
     * Set firebaseNotifToken
     *
     * @param string $firebaseNotifToken
     *
     * @return User
     */
    public function setFirebaseNotifToken($firebaseNotifToken)
    {
        $this->firebaseNotifToken = $firebaseNotifToken;

        return $this;
    }

    /**
     * Get firebaseNotifToken
     *
     * @return string
     */
    public function getFirebaseNotifToken()
    {
        return $this->firebaseNotifToken;
    }

    

    

    /**
     * Set nom
     *
     * @param string $nom
     *
     * @return User
     */
    public function setNom($nom)
    {
        $this->nom = $nom;

        return $this;
    }

    /**
     * Get nom
     *
     * @return string
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Set prenom
     *
     * @param string $prenom
     *
     * @return User
     */
    public function setPrenom($prenom)
    {
        $this->prenom = $prenom;

        return $this;
    }

    /**
     * Get prenom
     *
     * @return string
     */
    public function getPrenom()
    {
        return $this->prenom;
    }

    /**
     * Set adresse
     *
     * @param string $adresse
     *
     * @return User
     */
    public function setAdresse($adresse)
    {
        $this->adresse = $adresse;

        return $this;
    }

    /**
     * Get adresse
     *
     * @return string
     */
    public function getAdresse()
    {
        return $this->adresse;
    }

    /**
     * Set telephone
     *
     * @param string $telephone
     *
     * @return User
     */
    public function setTelephone($telephone)
    {
        $this->telephone = $telephone;

        return $this;
    }

    /**
     * Get telephone
     *
     * @return string
     */
    public function getTelephone()
    {
        return $this->telephone;
    }

    /**
     * Set dateNaissance
     *
     * @param \DateTime $dateNaissance
     *
     * @return User
     */
    public function setDateNaissance($dateNaissance)
    {
        $this->dateNaissance = $dateNaissance;

        return $this;
    }

    /**
     * Get dateNaissance
     *
     * @return \DateTime
     */
    public function getDateNaissance()
    {
        return $this->dateNaissance;
    }

    /**
     * Set civility
     *
     * @param string $civility
     *
     * @return User
     */
    public function setCivility($civility)
    {
        if(in_array($civility, ['mr', 'mme', 'mlle']))
        $this->civility = $civility;


        return $this;
    }

    /**
     * Get civility
     *
     * @return string
     */
    public function getCivility()
    {
        return $this->civility;
    }

    /**
     * Set permissions
     *
     * @param array $permissions
     *
     * @return User
     */
    public function setPermissions($permissions)
    {
        $this->permissions = $permissions;

        return $this;
    }

    /**
     * Get permissions
     *
     * @return array
     */
    public function getPermissions()
    {
        return $this->permissions;
    }

    /**
     * Set company
     *
     * @param string $company
     *
     * @return User
     */
    public function setCompany($company)
    {
        $this->company = $company;

        return $this;
    }

    /**
     * Get company
     *
     * @return string
     */
    public function getCompany()
    {
        return $this->company;
    }

    /**
     * Set region
     *
     * @param string $region
     *
     * @return User
     */
    public function setRegion($region)
    {
        $this->region = $region;

        return $this;
    }

    /**
     * Get region
     *
     * @return string
     */
    public function getRegion()
    {
        return $this->region;
    }

    /**
     * Set typeaccount
     *
     * @param string $typeaccount
     *
     * @return User
     */
    public function setTypeaccount($typeaccount)
    {
        $this->typeaccount = $typeaccount;

        return $this;
    }

    /**
     * Get typeaccount
     *
     * @return string
     */
    public function getTypeaccount()
    {
        return $this->typeaccount;
    }

    /**
     * Set metier
     *
     * @param string $metier
     *
     * @return User
     */
    public function setMetier($metier)
    {
        $this->metier = $metier;

        return $this;
    }

    /**
     * Get metier
     *
     * @return string
     */
    public function getMetier()
    {
        return $this->metier;
    }

    /**
     * Set speciality
     *
     * @param string $speciality
     *
     * @return User
     */
    public function setSpeciality($speciality)
    {
        $this->speciality = $speciality;

        return $this;
    }

    /**
     * Get speciality
     *
     * @return string
     */
    public function getSpeciality()
    {
        return $this->speciality;
    }

    /**
     * Set expertName
     *
     * @param string $expertName
     *
     * @return User
     */
    public function setExpertName($expertName)
    {
        $this->expertName = $expertName;

        return $this;
    }

    /**
     * Get expertName
     *
     * @return string
     */
    public function getExpertName()
    {
        return $this->expertName;
    }

    /**
     * Set ville
     *
     * @param string $ville
     *
     * @return User
     */
    public function setVille($ville)
    {
        $this->ville = $ville;

        return $this;
    }

    /**
     * Get ville
     *
     * @return string
     */
    public function getVille()
    {
        return $this->ville;
    }

    /**
     * Set telephonepro
     *
     * @param string $telephonepro
     *
     * @return User
     */
    public function setTelephonepro($telephonepro)
    {
        $this->telephonepro = $telephonepro;

        return $this;
    }

    /**
     * Get telephonepro
     *
     * @return string
     */
    public function getTelephonepro()
    {
        return $this->telephonepro;
    }

    /**
     * Set siret
     *
     * @param string $siret
     *
     * @return User
     */
    public function setSiret($siret)
    {
        $this->siret = $siret;

        return $this;
    }

    /**
     * Get siret
     *
     * @return string
     */
    public function getSiret()
    {
        return $this->siret;
    }

    /**
     * Add activity
     *
     * @param \Sadev\BusinessModelBundle\Entity\Activity $activity
     *
     * @return User
     */
    public function addActivity(\Sadev\BusinessModelBundle\Entity\Activity $activity)
    {
        $this->activities[] = $activity;

        return $this;
    }

    /**
     * Remove activity
     *
     * @param \Sadev\BusinessModelBundle\Entity\Activity $activity
     */
    public function removeActivity(\Sadev\BusinessModelBundle\Entity\Activity $activity)
    {
        $this->activities->removeElement($activity);
    }

    /**
     * Get activities
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getActivities()
    {
        return $this->activities;
    }

    /**
     * Set iban
     *
     * @param string $iban
     *
     * @return User
     */
    public function setIban($iban)
    {
        $this->iban = $iban;

        return $this;
    }

    /**
     * Get iban
     *
     * @return string
     */
    public function getIban()
    {
        return $this->iban;
    }

    /**
     * Set bic
     *
     * @param string $bic
     *
     * @return User
     */
    public function setBic($bic)
    {
        $this->bic = $bic;

        return $this;
    }

    /**
     * Get bic
     *
     * @return string
     */
    public function getBic()
    {
        return $this->bic;
    }

    

    /**
     * Set cni
     *
     * @param \Sadev\BusinessModelBundle\Entity\Fichier $cni
     *
     * @return User
     */
    public function setCni(\Sadev\BusinessModelBundle\Entity\Fichier $cni = null)
    {
        $this->cni = $cni;

        return $this;
    }

    /**
     * Get cni
     *
     * @return \Sadev\BusinessModelBundle\Entity\Fichier
     */
    public function getCni()
    {
        return $this->cni;
    }

    /**
     * Set agrement
     *
     * @param \Sadev\BusinessModelBundle\Entity\Fichier $agrement
     *
     * @return User
     */
    public function setAgrement(\Sadev\BusinessModelBundle\Entity\Fichier $agrement = null)
    {
        $this->agrement = $agrement;

        return $this;
    }

    /**
     * Get agrement
     *
     * @return \Sadev\BusinessModelBundle\Entity\Fichier
     */
    public function getAgrement()
    {
        return $this->agrement;
    }

    /**
     * Set rib
     *
     * @param \Sadev\BusinessModelBundle\Entity\Fichier $rib
     *
     * @return User
     */
    public function setRib(\Sadev\BusinessModelBundle\Entity\Fichier $rib = null)
    {
        $this->rib = $rib;

        return $this;
    }

    /**
     * Get rib
     *
     * @return \Sadev\BusinessModelBundle\Entity\Fichier
     */
    public function getRib()
    {
        return $this->rib;
    }

    /**
     * Set kbis
     *
     * @param \Sadev\BusinessModelBundle\Entity\Fichier $kbis
     *
     * @return User
     */
    public function setKbis(\Sadev\BusinessModelBundle\Entity\Fichier $kbis = null)
    {
        $this->kbis = $kbis;

        return $this;
    }

    /**
     * Get kbis
     *
     * @return \Sadev\BusinessModelBundle\Entity\Fichier
     */
    public function getKbis()
    {
        return $this->kbis;
    }

    /**
     * Set contratpatner
     *
     * @param \Sadev\BusinessModelBundle\Entity\Fichier $contratpatner
     *
     * @return User
     */
    public function setContratpatner(\Sadev\BusinessModelBundle\Entity\Fichier $contratpatner = null)
    {
        $this->contratpatner = $contratpatner;

        return $this;
    }

    /**
     * Get contratpatner
     *
     * @return \Sadev\BusinessModelBundle\Entity\Fichier
     */
    public function getContratpatner()
    {
        return $this->contratpatner;
    }

    /**
     * Set cartet
     *
     * @param \Sadev\BusinessModelBundle\Entity\Fichier $cartet
     *
     * @return User
     */
    public function setCartet(\Sadev\BusinessModelBundle\Entity\Fichier $cartet = null)
    {
        $this->cartet = $cartet;

        return $this;
    }

    /**
     * Get cartet
     *
     * @return \Sadev\BusinessModelBundle\Entity\Fichier
     */
    public function getCartet()
    {
        return $this->cartet;
    }

    /**
     * Set carteg
     *
     * @param \Sadev\BusinessModelBundle\Entity\Fichier $carteg
     *
     * @return User
     */
    public function setCarteg(\Sadev\BusinessModelBundle\Entity\Fichier $carteg = null)
    {
        $this->carteg = $carteg;

        return $this;
    }

    /**
     * Get carteg
     *
     * @return \Sadev\BusinessModelBundle\Entity\Fichier
     */
    public function getCarteg()
    {
        return $this->carteg;
    }

    /**
     * Set numorias
     *
     * @param \Sadev\BusinessModelBundle\Entity\Fichier $numorias
     *
     * @return User
     */
    public function setNumorias(\Sadev\BusinessModelBundle\Entity\Fichier $numorias = null)
    {
        $this->numorias = $numorias;

        return $this;
    }

    /**
     * Get numorias
     *
     * @return \Sadev\BusinessModelBundle\Entity\Fichier
     */
    public function getNumorias()
    {
        return $this->numorias;
    }


    /**
     * @VirtualProperty
    **/
    public function cniFile()
    {
        if($this->cni)
            return $this->cni->url();
        
        return null;
    }

    /**
     * @VirtualProperty
    **/
    public function agrementFile()
    {
        if($this->agrement)
            return $this->agrement->url();
        
        return null;
    }

    /**
     * @VirtualProperty
    **/
    public function ribFile()
    {
        if($this->rib)
            return $this->rib->url();
        
        return null;
    }


    /**
     * @VirtualProperty
    **/
    public function kbisFile()
    {
        if($this->kbis)
            return $this->kbis->url();
        
        return null;
    }


    /**
     * @VirtualProperty
    **/
    public function contratpatnerFile()
    {
        if($this->contratpatner)
            return $this->contratpatner->url();
        
        return null;
    }


    /**
     * @VirtualProperty
    **/
    public function cartetFile()
    {
        if($this->cartet)
            return $this->cartet->url();
        
        return null;
    }

    /**
     * @VirtualProperty
    **/
    public function cartegFile()
    {
        if($this->carteg)
            return $this->carteg->url();
        
        return null;
    }


    /**
     * @VirtualProperty
    **/
    public function numoriasFile()
    {
        if($this->numorias)
            return $this->numorias->url();
        
        return null;
    }
    


    /**
     * Set photobase64
     *
     * @param string $photobase64
     *
     * @return User
     */
    public function setPhotobase64($photobase64)
    {
        $this->photobase64 = $photobase64;

        return $this;
    }

    /**
     * Get photobase64
     *
     * @return string
     */
    public function getPhotobase64()
    {
        return $this->photobase64;
    }

    /**
     * Set resetToken
     *
     * @param string $resetToken
     *
     * @return User
     */
    public function setResetToken($resetToken)
    {
        $this->resetToken = $resetToken;

        return $this;
    }

    /**
     * Get resetToken
     *
     * @return string
     */
    public function getResetToken()
    {
        return $this->resetToken;
    }

    /**
     * Set resetTokenAt
     *
     * @param \DateTime $resetTokenAt
     *
     * @return User
     */
    public function setResetTokenAt($resetTokenAt)
    {
        $this->resetTokenAt = $resetTokenAt;

        return $this;
    }

    /**
     * Get resetTokenAt
     *
     * @return \DateTime
     */
    public function getResetTokenAt()
    {
        return $this->resetTokenAt;
    }

    /**
     * Set formule
     *
     * @param string $formule
     *
     * @return User
     */
    public function setFormule($formule)
    {
        $this->formule = $formule;

        return $this;
    }

    /**
     * Get formule
     *
     * @return string
     */
    public function getFormule()
    {
        return $this->formule;
    }

    /**
     * Set dateExpiration
     *
     * @param \DateTime $dateExpiration
     *
     * @return User
     */
    public function setDateExpiration($dateExpiration)
    {
        $this->dateExpiration = $dateExpiration;

        return $this;
    }

    /**
     * Get dateExpiration
     *
     * @return \DateTime
     */
    public function getDateExpiration()
    {
        return $this->dateExpiration;
    }

    /**
     * Add soubscriptionpayment
     *
     * @param \Sadev\BusinessModelBundle\Entity\SoubscriptionPayment $soubscriptionpayment
     *
     * @return User
     */
    public function addSoubscriptionpayment(\Sadev\BusinessModelBundle\Entity\SoubscriptionPayment $soubscriptionpayment)
    {
        $this->soubscriptionpayment[] = $soubscriptionpayment;

        return $this;
    }

    /**
     * Remove soubscriptionpayment
     *
     * @param \Sadev\BusinessModelBundle\Entity\SoubscriptionPayment $soubscriptionpayment
     */
    public function removeSoubscriptionpayment(\Sadev\BusinessModelBundle\Entity\SoubscriptionPayment $soubscriptionpayment)
    {
        $this->soubscriptionpayment->removeElement($soubscriptionpayment);
    }

    /**
     * Get soubscriptionpayment
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getSoubscriptionpayment()
    {
        return $this->soubscriptionpayment;
    }
}
