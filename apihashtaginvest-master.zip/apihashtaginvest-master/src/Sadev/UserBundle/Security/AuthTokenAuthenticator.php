<?php
namespace Sadev\UserBundle\Security;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Authentication\Token\PreAuthenticatedToken;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\Exception\AuthenticationException;
use Symfony\Component\Security\Core\Exception\CustomUserMessageAuthenticationException;
use Symfony\Component\Security\Core\Exception\BadCredentialsException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Security\Core\Exception\TokenNotFoundException;

use Symfony\Component\Security\Core\User\UserProviderInterface;
use Symfony\Component\Security\Http\Authentication\AuthenticationFailureHandlerInterface;
use Symfony\Component\Security\Http\Authentication\SimplePreAuthenticatorInterface;
use Symfony\Component\Security\Http\HttpUtils;

class AuthTokenAuthenticator implements SimplePreAuthenticatorInterface, AuthenticationFailureHandlerInterface
{
    /**
    * Durée de validité du token en secondes, 365 jour
    */
    // const TOKEN_VALIDITY_DURATION = 365 * 24 * 3600 ;

    /**
    * Durée de validité du token en secondes, 1 jour
    */
    // const TOKEN_VALIDITY_DURATION = 60 * 60 * 24;

    /**
    * Durée de validité du token en secondes,  5 ans
    */
    const TOKEN_VALIDITY_DURATION = 5 * 365 * 24 * 3600 ;


    protected $httpUtils;
    protected $superAdminToken;

    public function __construct(HttpUtils $httpUtils, $super_admin_token)
    {
        $this->httpUtils = $httpUtils;
        $this->superAdminToken = $super_admin_token;
    }

    public function createToken(Request $request, $providerKey)
    {
        // on ignore la route de login et la route de creation des utilisateurs
        $targetUrl = '/api/login';
        $targetUrl2 = '/api/users';
        
        //$targetUrl = '/auth-tokens';
        // Si la requête est une création de token, aucune vérification n'est effectuée
        if ( $request->getMethod() === "POST" && ( $this->httpUtils->checkRequestPath($request, $targetUrl) or $this->httpUtils->checkRequestPath($request, $targetUrl2)   )  ) {
            return;
        } 

        $authTokenHeader = $request->headers->get('X-Auth-Token');

        if (!$authTokenHeader) {
            throw new BadCredentialsException('X-Auth-Token header is required');
        }

        // on verifie si s'agit d'un token super_admin
        if($authTokenHeader == $this->superAdminToken) {
            return;
        }

        return new PreAuthenticatedToken(
            'anon.',
            $authTokenHeader,
            $providerKey
        );

    }

    public function authenticateToken(TokenInterface $token, UserProviderInterface $userProvider, $providerKey)
    {
        if (!$userProvider instanceof AuthTokenUserProvider) {
            throw new \InvalidArgumentException(
                sprintf(
                    'The user provider must be an instance of AuthTokenUserProvider (%s was given).',
                    get_class($userProvider)
                )
            );
        }

        $authTokenHeader = $token->getCredentials();
        $authToken = $userProvider->getAuthToken($authTokenHeader);

        if(!$authToken)
        {
            // throw new NotFoundHttpException("Not found authentication token");
            throw new TokenNotFoundException("Not found authentication token");
        }
        
        if (!$authToken || !$this->isTokenValid($authToken)) {
            // throw new BadCredentialsException('Invalid authentication token');
            throw new TokenNotFoundException('Invalid authentication token');
        } 

       

        $user = $authToken->getUser();
        $pre = new PreAuthenticatedToken(
            $user,
            $authTokenHeader,
            $providerKey,
            $user->getRoles()
        );

        // Nos utilisateurs n'ont pas de role particulier, on doit donc forcer l'authentification du token
        $pre->setAuthenticated(true);

        return $pre;
    }

    public function supportsToken(TokenInterface $token, $providerKey)
    {
        return $token instanceof PreAuthenticatedToken && $token->getProviderKey() === $providerKey;
    }

    /**
    * Vérifie la validité du token
    */
    private function isTokenValid($authToken)
    {
        return (time() - $authToken->getCreatedAt()->getTimestamp()) < self::TOKEN_VALIDITY_DURATION;
    }

    public function onAuthenticationFailure(Request $request, AuthenticationException $exception)
    {
        // Si les données d'identification ne sont pas correctes, une exception est levée
        throw $exception;
    }

}