<?php

// src/Sadev/UserBundle/Security/Permissions.php
namespace Sadev\UserBundle\Security;

use Symfony\Component\HttpFoundation\Response as Resp;


class Error
{
	 
	/**
	* Recherche les caractères spéciaux  dans la chaine et les remplace par leur équivalence
	* Ensuite return la chaine modifier
	* 
	*
	*/
 
    public function allErrors() {
		
		$allerrors = array();

		$allerrors['notfound_account'] = ['code'=>600, 'message'=>'Compte introuvable lors de la connexion'];
		$allerrors['unactive_account'] = ['code'=>601, 'message'=>'Compte désactivé'];
		$allerrors['unvalid_email_duplicate'] = ['code'=>602, 'message'=>'Adresse e-mail déjà existante'];
		$allerrors['unvalid_phone_number_duplicate'] = ['code'=>603, 'message'=>'Numero de téléphone déjà existant'];
		$allerrors['unvalid_password'] = ['code'=>605, 'message'=>'mot de passe incorrect'];
		$allerrors['unvalid_code'] = ['code'=>606, 'message'=>'Code de vérification invalide'];
		$allerrors['limit_database'] = ['code'=>607, 'message'=>'Nombre de base de données atteind'];
		$allerrors['invalid_key'] = ['code'=>608, 'message'=>'Clé introuvable'];
		$allerrors['invalid_key_activated'] = ['code'=>609, 'message'=>'Clé déjà utilisé'];
		$allerrors['notfound_database'] = ['code'=>610, 'message'=>'Base de donnée introuvable'];
		$allerrors['duplicate_invitation'] = ['code'=>611, 'message'=>'Invitation déjà envoyé'];
		
		return $allerrors;

    }


	public function invalidCredentials($message, $code = null)
    {
        if($code == null)
        $code = '600';

        return \FOS\RestBundle\View\View::create(['code' => $code, 'message' => $message], Resp::HTTP_BAD_REQUEST);
    }
 
    
	
  
}