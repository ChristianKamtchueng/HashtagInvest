<?php

// src/Sadev/UserBundle/Security/Permissions.php
namespace Sadev\UserBundle\Security;


class Permissions
{
	 
	/**
	* Recherche les caractères spéciaux  dans la chaine et les remplace par leur équivalence
	* Ensuite return la chaine modifier
	* 
	*
	*/
 
    public function allPermissions() {
			
			$allpermissions = array(
				['designation'=>'Admin - Accès a l\'espace d\'administration', 'value'=>'adminAccess'],
				['designation'=>'Admin - Edition utilisateur', 'value'=>'adminEditUser'],
				['designation'=>'Admin - Edition souscription', 'value'=>'adminEditSouscription'],
				['designation'=>'Admin - Edition paramètres', 'value'=>'adminEditSetting'],
				['designation'=>'Admin - Edition menu', 'value'=>'adminEditMenu'],
				['designation'=>'Admin - Gestion message', 'value'=>'adminManageMessage'],
			);
		
			return $allpermissions;
    }
 
    
	
  
}