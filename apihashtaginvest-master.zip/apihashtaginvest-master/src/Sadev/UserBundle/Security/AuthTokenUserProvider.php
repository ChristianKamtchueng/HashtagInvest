<?php

// Comme pour tous les systèmes d’authentification de Symfony, nous avons besoin d’un fournisseur d’utilisateurs (UserProvider). Pour notre cas, il faut que notre fournisseur puisse charger un token en utilisant la valeur dans notre entête X-Auth-Token.
// Cette classe permettra de récupérer les utilisateurs en se basant sur le token d’authentification fourni.

namespace Sadev\UserBundle\Security;

use Symfony\Component\Security\Core\User\UserProviderInterface;
use Symfony\Component\Security\Core\User\User;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Security\Core\Exception\UnsupportedUserException;
use Doctrine\ORM\EntityRepository;
use Doctrine\DBAL\Connection;
use Symfony\Component\HttpFoundation\RequestStack;
use Doctrine\ORM\EntityManager;

use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Security\Core\Exception\BadCredentialsException;

use Symfony\Component\DependencyInjection\ContainerInterface;

use Sadev\BusinessModelBundle\Entity\Produit;

class AuthTokenUserProvider implements UserProviderInterface
{
    protected $authTokenRepository;
    protected $userRepository;
    protected $connection;

    public function __construct(RequestStack $requestStack, EntityManager $em, $kernel)
    {
        
        $this->request = $requestStack->getCurrentRequest();
        $this->em = $em;
        $this->kernel = $kernel;
        // on definir les sources des tokens et Users

        $this->authTokenRepository = $em->getRepository('SadevUserBundle:AuthToken');
        $this->userRepository = $em->getRepository('SadevUserBundle:User');
    
    }

    public function getAuthToken($authTokenHeader)
    {
        return $this->authTokenRepository->findOneByValue($authTokenHeader);
    }

    public function loadUserByUsername($email)
    {
        return $this->userRepository->findByEmail($email);
    }

    public function refreshUser(UserInterface $user)
    {
        // Le systéme d'authentification est stateless, on ne doit donc jamais appeler la méthode refreshUser
        throw new UnsupportedUserException();
    }

    public function supportsClass($class)
    {
        return 'Sadev\UserBundle\Entity\User' === $class;
    }

   
}