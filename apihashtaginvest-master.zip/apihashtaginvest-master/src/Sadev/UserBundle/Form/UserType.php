<?php

namespace Sadev\UserBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

use Symfony\Component\Form\Extension\Core\Type\CollectionType;

use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\FileType;

use Sadev\BusinessModelBundle\Form\FichierType;
use Symfony\Component\Form\Extension\Core\Type\BirthdayType;




class UserType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        
        $builder
        ->add('isActive')
        ->add('nom')
        ->add('prenom')
        ->add('adresse')
        ->add('telephone')
        ->add('dateNaissance', BirthdayType::class, [
            'description' => " ",
        ])
        ->add('civility')
        ->add('username')
        ->add('plainPassword')
        ->add('email')
        ->add('region')
        ->add('company')
        ->add('firebaseNotifToken')
        ->add('typeaccount') // business, partner, admin //
        ->add('metier')
        ->add('speciality')
        ->add('expertName')
        ->add('ville')
        ->add('telephonepro')
        ->add('siret')
        ->add('iban')
        ->add('rib')
        ->add('bic')        
        //->add('photo', FichierType::class)
        ->add('photobase64')
        /* ->add('roles', CollectionType::class, [
            'entry_type' => TextType::class,
            'allow_add' => true,
            'allow_delete'=>true,
            'error_bubbling' => false,
        ]); */
        ->add('permissions', CollectionType::class, array(
            //'entry_type' => PermissionType::class,
            'description' => " permissions",
            'allow_add' => true,
            'allow_delete'=>true,
            'error_bubbling' => false,
        ))
        ;
    }
    
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Sadev\UserBundle\Entity\User',
            'csrf_protection' => false
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'sadev_userbundle_user';
    }


}
