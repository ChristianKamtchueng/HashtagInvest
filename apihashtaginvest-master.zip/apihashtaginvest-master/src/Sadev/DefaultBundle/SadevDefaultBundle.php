<?php

namespace Sadev\DefaultBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SadevDefaultBundle extends Bundle
{
}
