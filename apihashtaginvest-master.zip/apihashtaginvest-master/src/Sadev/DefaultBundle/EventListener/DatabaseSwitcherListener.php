<?php

namespace Sadev\DefaultBundle\EventListener;

use Symfony\Component\HttpFoundation\RequestStack;
use Doctrine\DBAL\Connection;
use Doctrine\ORM\EntityManager;

use Symfony\Component\Security\Core\Exception\AuthenticationException;
use Symfony\Component\Security\Core\Exception\CustomUserMessageAuthenticationException;
use Symfony\Component\Security\Core\Exception\BadCredentialsException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

use Symfony\Component\HttpFoundation\Response;

use Symfony\Component\DependencyInjection\ContainerInterface;

class DatabaseSwitcherListener
{
    private $request;
    private $connection;
    private $em;
    private $base_host;
    private $kernel;
 
    public function __construct(RequestStack $requestStack, ContainerInterface $container, Connection $connection, EntityManager $em, $kernel, $base_host, $base_version) {
        $this->request = $requestStack->getCurrentRequest();
        $this->connection = $connection;
        $this->em = $em;
        $this->kernel = $kernel;
        $this->base_host = $base_host;
        $this->base_version = $base_version;
    }
 
    public function onKernelRequest() {
                
        // on se connecte à la base de donnée du tenant ( uniquement  pour les routes non sécurisés  pour les routes sécurisés (api) voir les services  du SadevBusinessModelBundle dans le dossier Security)


       /*  $connection = $this->connection;
        if (!$this->connection->isConnected()) {

            $params = $this->connection->getParams();

            $DbName = $this->request->headers->get('X-Tenant');

            if (!$DbName) {
                throw new BadCredentialsException('X-Tenant header is required');
            }

            if($DbName != "sadev")
            {
                $tenant = $this->em->getRepository('SadevDefaultBundle:Company')->findOneBy(
                    array('baseName' => $DbName)
                );
    
                if ($tenant) {
    
                    $params['dbname'] = $DbName;
    
                    $connection->__construct(
                        $params,
                        $connection->getDriver(),
                        $connection->getConfiguration(),
                        $connection->getEventManager()
                    );
    
                    $connection->connect();
        
                    //Mise à jour de la bdd si la version de la base de donnée du tenant est differente de la version de la base donnée du projet (à definir dans les paramètres)
                    if($tenant->getBaseVersion() != $this->base_version)
                    { 

                        $application = new \Symfony\Bundle\FrameworkBundle\Console\Application($this->kernel);
                        $application->setAutoExit(false);
                        //Create de Schema 
                        $options = array('command' => 'doctrine:schema:update',"--force" => true, "--em"=>"tenantdb");
                        $application->run(new \Symfony\Component\Console\Input\ArrayInput($options));

                        
                        // on met à jour la version de la base de donnée 
                        $tenant->setBaseVersion($this->base_version); 
                        $this->em->flush();
                        
                    }
    
                }else {
                    throw new NotFoundHttpException("Unknown tenants exception");
                }
               
    
            }
            

        } */



    }


}