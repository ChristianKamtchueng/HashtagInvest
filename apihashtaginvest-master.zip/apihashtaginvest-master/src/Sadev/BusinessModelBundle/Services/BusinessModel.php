<?php

// namespace Sadev\BusinessModelBundle\Entity;

namespace Sadev\BusinessModelBundle\Services;

class BusinessModel
{

    /* private $type;
    private $data; */

    function __construct()
    {
        /* $this->type = $type;
        $this->data = $data; */
    }

    function random_username($string) {

        $username = $string;

        $string = $this->nameRewrite($string);

        $lastname = strtolower(substr($string, 0, 5));
        $nrRand = rand(0, 100);
        $username =  $lastname . $nrRand;
    
        /* $pattern = " ";
        $firstPart = strstr(strtolower($string), $pattern, true);
        $secondPart = substr(strstr(strtolower($string), $pattern, false), 0,3);
        $nrRand = rand(0, 100);
        
        $username = trim($firstPart).trim($secondPart).trim($nrRand); */


        // $username = str_replace(' ','',$string);

        // $username = mb_convert_case($string, MB_CASE_LOWER, "UTF-8");

        // $username = substr(str_replace(' ','', mb_convert_case($string, MB_CASE_LOWER, "UTF-8")), 0, 5).rand(1,3);

        return $username;

    }

    public function nameRewrite($string)
    {
        
		$accent = array('à', 'á', 'â', 'ã', 'ä', 'å', 'À', 'Á', 'Â', 'Ã', 'Ä', 'Å', 'ç', 'Ç', 'é', 'è', 'ê', 'ë', 'È', 'É', 'Ê', 'Ë', 'ì', 'í', 'î', 'ï', 'Ì', 'Í', 'Î', 'Ï', 'ò', 'ó', 'ô', 'õ', 'ö', 'Ò', 'Ó', 'Ô', 'Õ', 'Ö', 'ù', 'ú', 'û', 'ü', 'Ú', 'Ù', 'Û', 'Ü', 'Ý', 'ý', 'ÿ', 'ñ', '&#039;');
        $sans_accent = array('a', 'a', 'a', 'a', 'a', 'a', 'A', 'A', 'A', 'A', 'A', 'A', 'c', 'C', 'e', 'e', 'e', 'e', 'E', 'E', 'E', 'E', 'i', 'i', 'i', 'i', 'I', 'I', 'I', 'I', 'o', 'o', 'o', 'o', 'o', 'O', 'O', 'O', 'O', 'O', 'u', 'u', 'u', 'u', 'U', 'U', 'U', 'U', 'y', 'y', 'y', 'n', '-');      
		
        $string = str_replace($accent, $sans_accent, $string);
		$string = strtolower($string);
		
		$url = array();
	 
		for ($i = 0; $i < strlen($string); $i++) 
		array_push($url, $string[$i]);
		
		$url_aff = '';
		
		foreach($url as $string)
		{

			if(preg_match('#^[a-zA-Z0-9]$#', $string) != true)
			$string = str_replace($string, '-', $string);
			
            $url_aff .= $string;

		}
		
		return  $url_aff;
		
    }

}
