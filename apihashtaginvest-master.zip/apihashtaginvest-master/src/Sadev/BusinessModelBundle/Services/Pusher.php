<?php

// namespace Sadev\BusinessModelBundle\Entity;

namespace Sadev\BusinessModelBundle\Services;

define('SECRET_KEY', "AAAAGdVgvu4:APA91bEx_jhXxOTir2yt_nTG5PbVP0_v3O9ydArgCCZC51Nmn6h05w_8p5h77hFdniBFSHoNEpGecNHggKNakDhjdHjf5qaMK2_O3Yu-bwfPYHmI3FV5c74iAs0grMs0vpXt7aTz441_");

class Pusher 
{

    public function pushToUsers(array $toIds, $type, $data){
        $push = new Push($type, $data);
        $this->send($toIds, $push->getPush());
    }
    
    public function pushToTopic($topicName, $type, $data){
        $push = new Push($type, $data);
        $this->sendToTopic($topicName, $push->getPush());
    }
    
    private  function send($registration_ids, $data)
    {
        $fields = array(
            'registration_ids' => $registration_ids,
            'priority' => 'high',
            'data' => $data
        );
        return $this->sendPushNotification($fields);
    }
    
    private function sendPushNotification($fields)
    {

        $headers = array(
            'Authorization: key=' . SECRET_KEY,
            'Content-Type: application/json'
        );

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

        $result = curl_exec($ch);
        if ($result === FALSE) {
            die('Error : ' . curl_error($ch));
        }

        curl_close($ch);
        return $result;
    }
}
