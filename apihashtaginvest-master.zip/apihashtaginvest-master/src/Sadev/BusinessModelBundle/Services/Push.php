<?php

// namespace Sadev\BusinessModelBundle\Entity;

namespace Sadev\BusinessModelBundle\Services;

class Push
{

    private $type;
    private $data;

    function __construct($type, $data)
    {
        $this->type = $type;
        $this->data = $data;
    }

    function getPush()
    {
        $res = array();
        $res['type'] = $this->type;
        $res['data'] = $this->data;
        return $res;
    }

}
