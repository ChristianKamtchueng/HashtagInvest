<?php

// src/Erico/ApiBundle/Services/MyService.php
namespace Sadev\BusinessModelBundle\Services;


class MyService
{
	 
	/**
	* Recherche les caractères spéciaux  dans la chaine et les remplace par leur équivalence
	* Ensuite return la chaine modifier
	* 
	*
	 @param string $ch
	*/

	// public $endpointSecret = "whsec_gBc85ttd9efIl8vRzmLIlV92OTV8Kl2f";
    //public $apiKey = 'sk_test_51SHnbR6sYrFzhqb3pA0NBJqyuQgvBpbMq4nOIzmcrd7yev5KUVXvU8gr3iwc7iSSZFqodWfW44hDsFT4ARitD69p00XjOZCUW5';

 
    public function converToSpecialChar($ch) {
			
		$specialChar = array('&quot;', '&lt;', '&gt;', '&laquo;', '&raquo;', '&amp;', '&euro;', '&yen;', '&copy;', '&reg;', '&agrave;', '&acirc;', '&eacute;', '&egrave;', '&ecirc;', '&icirc;', '&iuml;', '&oelig;', '&ugrave;', '&ucirc;', '&ccedil;');
		$notspecialChar = array('"', '<', '>', '«', '»', '&', '€', '¥', '©', '®', 'à', 'â', 'é', 'è', 'ê', 'î', 'ï', 'œ', 'ù', 'û', 'ç');
		for($i=0; $i < count($specialChar); $i++)
		{
			$ch = str_ireplace ( $notspecialChar[$i], $specialChar[$i], $ch);
		}
		
		return $ch;
    }
 
    public function exceptionkeyword() {
		$exception = array('les', 'ils', 'elles', 'elle', 'vous', 'nous', 'des', 'pas', 'pour', 'mais', 'non', 'dans', 'une', 'une',  'quoi', 'quel',  'quelles', 'qui', 'mon', 'notre', 'votre', 'leur', 'son', 'par', 'pour', 'aux', 'sur');
		return $exception;
    }

	public function getApiKey($env) {

		if($env == 'production') {
			$exception = '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';
		} else {
			$exception = 'sk_test_51SHnbR6sYrFzhqb3pA0NBJqyuQgvBpbMq4nOIzmcrd7yev5KUVXvU8gr3iwc7iSSZFqodWfW44hDsFT4ARitD69p00XjOZCUW5';
		}	

		return $exception;

    }

	public function getEndpointSecret($env) {

		if($env == 'production') {
			$exception = 'whsec_BnPBNFK4x6Sj2qETIzEb16dY0U725WMp';
		} else {
			$exception = 'whsec_gBc85ttd9efIl8vRzmLIlV92OTV8Kl2f';
		}

		return $exception;
    }
	
  
}