<?php

namespace Sadev\BusinessModelBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SadevBusinessModelBundle extends Bundle
{
}
