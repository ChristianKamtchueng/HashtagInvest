<?php

namespace Sadev\BusinessModelBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sadev\BusinessModelBundle\Entity\Categorie;
use Sadev\BusinessModelBundle\Form\CategorieType;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\Request;
use FOS\RestBundle\Controller\Annotations as Rest;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Component\Security\Core\SecurityContext;
use FOS\RestBundle\Controller\Annotations\QueryParam;

use Nelmio\ApiDocBundle\Annotation as Doc;

use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;


class CategorieController extends Controller
{
    
    /**
     * @Rest\Get("/api/admin/categories/{id}", name="categorie_admin_show")
     * @Rest\View
     * @Doc\ApiDoc(
     *     section="Categorie",
     *     description="Récuperation d'une categorie",
     *     
     * )
     */
    public function showAction(Categorie $categorie)
    {

        /*
        récupération de l'entité grâce au 
        ParamConverter de Doctrine qui nous permet 
        d'aller chercher un objet en base de données.
        */
       
        return $categorie;

    }

    /**
     * @DOC\ApiDoc(
     *    section="Categorie",
     *    description="Création d'une categorie",
     *    input={"class"=CategorieType::class, "name"=""}
     * )
     *@Rest\Post("/api/admin/categories", name="categorie_admin_create")
     *@Rest\View(StatusCode = 201)
     */
    public function createAction(Request $request)
    {

        $categorie = new Categorie;
        //$user->setCompany($company);

        /* 
        Bien que nous puissions créer ou mettre à jour une entité
        sans aucune validation, nous utiliserons néanmoins les formulaires de Symfony pour effectué cette validation.
        Dans le formType il faut obligatoirement désactiver la protection CSRF (Cross-Site Request Forgery). 
        Dans une API,  Nous n’utilisons pas de session et l’utilisateur de l’API peut appeler cette méthode sans se soucier de l’état de l’application : l’API doit rester sans état : stateless.
        */

        /* 
        En plus du système de validation l'autre avantage
        d'utiliser les formulaires est l'hydratation de l'entité avec 
        les données de la requette ce qui nous permet de gagner en productivité
        */

        $data = $request->request->all(); // recuperation des données qui sont automatiquement deserialiser par FosRest pour être traité par le formulaire.
        $form = $this->createForm(CategorieType::class, $categorie);

        //convertion du json reçu en objet comme le fait le paramConveter
        $form->submit($data);

        if ($form->isValid()) //validation des données avant la sauvegarde
        {

            $em = $this->getDoctrine()->getManager();

            // vérification du chemin
            $categories = $this->getDoctrine()->getManager()->getRepository('SadevBusinessModelBundle:Categorie')->findAll();
        
            foreach($categories as $elem)
            {
                if($elem->chemin() == $categorie->chemin()) {

                    throw new AccessDeniedHttpException('Catégorie déjà existante: impossible de créer une même catégorie deux fois. ');
                    
                    break;

                }
            
            }

            // recuperation de l'auteur
            $authTokenHeader = $request->headers->get('X-Auth-Token');
            
            $token = $this->getDoctrine()->getManager()->getRepository('SadevUserBundle:AuthToken')->findOneByValue($authTokenHeader);
            if ($token !== null) { 
                $categorie->setCreateBy($token->getUser());
            } 

            // on force le type en fonction du parent
            if( $categorie->getParent() !== null)
            $categorie->setTypeContent($categorie->getParent()->getTypeContent());
            

            $em->persist($categorie);
            $em->flush(); 
            return $categorie;

        } else {

            return $form;

        }
        
        
    }

    /**
     *@DOC\ApiDoc(
     * section="Categorie",
     * description="Modification totale d'une categorie",
     * input={"class"=CategorieType::class, "name"=""}
     *)
     *@Rest\Put("/api/admin/categories/{id}", name="categorie_admin_update_total")
     *@Rest\View(StatusCode = 200)
     *@ParamConverter("categorie")
     */
    public function updateAction(Categorie $categorie, Request $request)
    {

        return $this->update($categorie, $request, true);

    }

    /**
     *@Rest\Patch("/api/admin/categories/{id}", name="categorie_admin_update_partielle")
     *@DOC\ApiDoc(
     *    section="Categorie",
     *    description="Modification partielle d'une categorie",
     *    input={"class"=CategorieType::class, "name"=""}
     *)
     *@Rest\View()
     */
    public function patchAction(Request $request)
    {
        
        $categorie = $this->getDoctrine()->getManager()->getRepository('SadevBusinessModelBundle:Categorie') ->find($request->get('id'));

        return $this->update($categorie, $request, false);

    }

    private function update(Categorie $categorie, Request $request, $clearMissing)
    {
        // ici pas besoin de rechercher l'entite ou de le créer car il est recuperer automatique grâce à l'info contenu dans le paramConverter
        
        /* 
        Bien que nous puissions créer ou mettre à jour une entité
        sans aucune validation, nous utiliserons néanmoins les formulaires de Symfony pour effectué cette validation.
        Dans le formType il faut obligatoirement désactiver la protection CSRF (Cross-Site Request Forgery). 
        Dans une API,  Nous n’utilisons pas de session et l’utilisateur de l’API peut appeler cette méthode sans se soucier de l’état de l’application : l’API doit rester sans état : stateless.
        */

        /* 
        En plus du système de validation l'autre avantage
        d'utiliser les formulaires est l'hydratation de l'entité avec 
        les données de la requette ce qui nous permet de gagner en productivité
        */
        
        $data = $request->request->all(); // recuperation des données qui sont automatiquement deserialiser par FosRest pour être traité par le formulaire.
        $form = $this->createForm(CategorieType::class, $categorie);
        
        //convertion du json reçu en objet comme le fait le paramConveter
        //L’implémentation de la mise à jour partielle avec Symfony est très proche de la mise à jour complète. Il suffit de rajouter un paramètre dans la méthode submit (clearMissing = false) et le tour est joué. Comme son nom l’indique, avec clearMissing à false, Symfony conservera tous les attributs de l’entité  qui ne sont pas présents dans les paramètres de la requête
        $form->submit($data, $clearMissing);
        
        if ($form->isValid()) //validation des données avant la sauvegarde
        {
            $em = $this->getDoctrine()->getManager();

            // vérification du chemin
            $categories = $this->getDoctrine()->getManager()->getRepository('SadevBusinessModelBundle:Categorie')->findAll();
        
            foreach($categories as $elem)
            {
                if($elem->chemin() == $categorie->chemin() && $elem->getId() !== $categorie->getId()) {

                    throw new AccessDeniedHttpException('Catégorie déjà existante: impossible de créer une même catégorie deux fois. ');
                    
                    break;

                }
            
            }

            $descendants = $categorie->descendant();

            // vérification parent
            if( $categorie->getParent() !== null && in_array($categorie->getParent()->getId(), $descendants))
            throw new AccessDeniedHttpException('Catégorie parente incorrect: une catégorie fille ou descendante ne peu pas être parent de sa catégorie parente.');

            // on force le type en fonction du parent
            if( $categorie->getParent() !== null)
            $categorie->setTypeContent($categorie->getParent()->getTypeContent());
            
            $em->flush();
            return $categorie;

        } else {
            return $form;
        }
        
    }

     /**
     * @Rest\Delete("/api/admin/categories/{id}", name="categorie_admin_delete")
     * @DOC\ApiDoc(
     *    section="Categorie",
     *    description="Supression d'une categorie",
     * )
     * @Rest\View
     */
    public function deleteAction(Categorie $categorie)
    {

        /*
        récupération de l'entité grâce au 
        ParamConverter de Doctrine qui nous permet 
        d'aller chercher un objet en base de données.
        */
        $em = $this->getDoctrine()->getManager();
        $em->remove($categorie);
        $em->flush();

    }


    /**
     * @Doc\ApiDoc(
     *    section="Categorie",
     *    description="Récupération de la liste des categories",
     *    output= { "class"=Categorie::class, "collection"=true }
     * )
     * @Rest\Get("/api/admin/categories", name="categorie_admin_list")
     * @Rest\View
     * @Rest\QueryParam(
     *       name="type",
     *       nullable=true,
     *       description="Type de catégorie"
     * )
     */
    public function listAction($type)
    {

        if($type == null || $type == '')
        $categories = $this->getDoctrine()->getManager()->getRepository('SadevBusinessModelBundle:Categorie')->findBy(array(), array('id'=>'DESC'));
        else
        $categories = $this->getDoctrine()->getManager()->getRepository('SadevBusinessModelBundle:Categorie')->findBy(array('typeContent'=>$type), array('id'=>'DESC'));

        /* $parent = array();
        foreach($categories as $elem)
        {
            if($elem->getParent() == null) {
                $parent[] = $elem;
            }
           
        }

        return $parent; */

        return $categories;

    }



}
