<?php

namespace Sadev\BusinessModelBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sadev\BusinessModelBundle\Entity\Activity;
use Sadev\BusinessModelBundle\Form\ActivityType;
use Sadev\BusinessModelBundle\Entity\Fichier;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\Request;
use FOS\RestBundle\Controller\Annotations as Rest;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Component\Security\Core\SecurityContext;
use FOS\RestBundle\Controller\Annotations\QueryParam;

use Nelmio\ApiDocBundle\Annotation as Doc;

class ActivityController extends Controller
{
    
    /**
     * @Rest\Get("/api/admin/activity/{id}", name="activity_admin_show")
     * @Rest\View
     * @Doc\ApiDoc(
     *     section="Activity",
     *     description="Récuperation d'une activité",
     *     
     * )
     */
    public function showAction(Activity $activity)
    {

        /*
        récupération de l'entité grâce au 
        ParamConverter de Doctrine qui nous permet 
        d'aller chercher un objet en base de données.
        */ 
        return $activity;

    }

    /**
     * @DOC\ApiDoc(
     *    section="Activity",
     *    description="Création d'une activité",
     *    input={"class"=ActivityType::class, "name"=""}
     * )
     * @Rest\Post("/api/admin/activity", name="activity_admin_create")
     * @Rest\View(StatusCode = 201)
     */
    public function createAction(Request $request)
    {

        $activity = new Activity;
        //$user->setCompany($company);

        /* 
        Bien que nous puissions créer ou mettre à jour une entité
        sans aucune validation, nous utiliserons néanmoins les formulaires de Symfony pour effectué cette validation.
        Dans le formType il faut obligatoirement désactiver la protection CSRF (Cross-Site Request Forgery). 
        Dans une API,  Nous n’utilisons pas de session et l’utilisateur de l’API peut appeler cette méthode sans se soucier de l’état de l’application : l’API doit rester sans état : stateless.
        */

        /* 
        En plus du système de validation l'autre avantage
        d'utiliser les formulaires est l'hydratation de l'entité avec 
        les données de la requette ce qui nous permet de gagner en productivité
        */

        $data = $request->request->all(); // recuperation des données qui sont automatiquement deserialiser par FosRest pour être traité par le formulaire.
        $form = $this->createForm(ActivityType::class, $activity);

        //convertion du json reçu en objet comme le fait le paramConveter
        $form->submit($data);

        if ($form->isValid()) //validation des données avant la sauvegarde
        {

            $em = $this->getDoctrine()->getManager();

            // recuperation de l'auteur
            $authTokenHeader = $request->headers->get('X-Auth-Token');
            
            $token = $this->getDoctrine()->getManager()->getRepository('SadevUserBundle:AuthToken')->findOneByValue($authTokenHeader);
            if ($token !== null) { 
                $activity->setCreateBy($token->getUser());
                $activity->setPartner($token->getUser());
            } 

            $em->persist($activity);
            $em->flush(); 
            return $activity;

        } else {

            return $form;

        }
        
        
    }

    /**
     *@DOC\ApiDoc(
     * section="Activity",
     * description="Modification totale d'une activité",
     * input={"class"=ActivityType::class, "name"=""}
     *)
     *@Rest\Post("/api/admin/activities/{id}", name="activity_admin_update_total")
     *@Rest\View(StatusCode = 200)
     *@ParamConverter("activity")
     */
    public function updateAction(Activity $activity, Request $request)
    {

        return $this->update($activity, $request, true);

    }

    /**
     *@Rest\Patch("/api/admin/activity/{id}", name="activity_admin_update_partielle")
     *@DOC\ApiDoc(
     *    section="Activity",
     *    description="Modification partielle d'une activité",
     *    input={"class"=ActivityType::class, "name"=""}
     *)
     *@Rest\View()
     */
    public function patchAction(Request $request)
    {
        
        $activity = $this->getDoctrine()->getManager()->getRepository('SadevBusinessModelBundle:Activity') ->find($request->get('id'));

        return $this->update($activity, $request, false);

    }

    private function update(Activity $activity, Request $request, $clearMissing)
    {

        // ici pas besoin de rechercher l'entite ou de le créer car il est recuperer automatique grâce à l'info contenu dans le paramConverter

        /* 
        Bien que nous puissions créer ou mettre à jour une entité
        sans aucune validation, nous utiliserons néanmoins les formulaires de Symfony pour effectué cette validation.
        Dans le formType il faut obligatoirement désactiver la protection CSRF (Cross-Site Request Forgery). 
        Dans une API,  Nous n’utilisons pas de session et l’utilisateur de l’API peut appeler cette méthode sans se soucier de l’état de l’application : l’API doit rester sans état : stateless.
        */

        /* 
        En plus du système de validation l'autre avantage
        d'utiliser les formulaires est l'hydratation de l'entité avec 
        les données de la requette ce qui nous permet de gagner en productivité
        */

        $data = $request->request->all(); // recuperation des données qui sont automatiquement deserialiser par FosRest pour être traité par le formulaire.
        $form = $this->createForm(ActivityType::class, $activity);

        //convertion du json reçu en objet comme le fait le paramConveter
        //L’implémentation de la mise à jour partielle avec Symfony est très proche de la mise à jour complète. Il suffit de rajouter un paramètre dans la méthode submit (clearMissing = false) et le tour est joué. Comme son nom l’indique, avec clearMissing à false, Symfony conservera tous les attributs de l’entité  qui ne sont pas présents dans les paramètres de la requête
        $form->submit($data, $clearMissing);

        if ($form->isValid()) //validation des données avant la sauvegarde
        {

            $em = $this->getDoctrine()->getManager();

            // appeler le setFileData après le $form->submit() pour eviter d'ecraser avec le $form->submit()
            /* if( isset( $request->files->all()['filesdata']) ){

                foreach($request->files->all()['filesdata'] as $elem) {
                    $fichier = new Fichier;
                    $fichier->setFiledata($elem);
                    $activity->addPiecesJointe($fichier);
                }

            } */

            $em->flush();

            return $activity;

        } else {

            return $form;

        }


    }

     /**
     * @Rest\Delete("/api/admin/activity/{id}", name="activity_admin_delete")
     * @DOC\ApiDoc(
     *    section="Activity",
     *    description="Supression d'une activité",
     * )
     * @Rest\View
     */
    public function deleteAction(Activity $activity)
    {

        /*
        récupération de l'entité grâce au 
        ParamConverter de Doctrine qui nous permet 
        d'aller chercher un objet en base de données.
        */
        $em = $this->getDoctrine()->getManager();
        $em->remove($activity);
        $em->flush();

    }


    /**
     * @Doc\ApiDoc(
     *    section="Activity",
     *    description="Récupération de la liste des activités",
     *    output= { "class"=Activity::class, "collection"=true }
     * )
     * @Rest\Get("/api/admin/activities", name="activity_admin_list")
     * @Rest\QueryParam(
     *       name="partner",
     *       nullable=true,
     *       description="id du partenaire"
     * )
     * @Rest\View
     */
    public function listAction($partner)
    {
        if($partner == '' || $partner == null){

            $activities = $this->getDoctrine()->getManager()->getRepository('SadevBusinessModelBundle:Activity')->findAll();

        } else {

            $activities = $this->getDoctrine()->getManager()->getRepository('SadevBusinessModelBundle:Activity')->findBy(array('partner' => $partner));

        }

        return $activities;
    }



}
