<?php

namespace Sadev\BusinessModelBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sadev\BusinessModelBundle\Entity\Answer;
use Sadev\BusinessModelBundle\Form\AnswerType;
use Symfony\Component\HttpFoundation\Request;
use FOS\RestBundle\Controller\Annotations as Rest;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use FOS\RestBundle\Controller\Annotations\QueryParam;
use Nelmio\ApiDocBundle\Annotation as Doc;

class AnswerController extends Controller
{
    /**
     * @Rest\Get("/api/admin/answer/{id}", name="answer_admin_show")
     * @Rest\View
     * @Doc\ApiDoc(
     *     section="Answer",
     *     description="Récupération d'une réponse"
     * )
     */
    public function showAction(Answer $answer)
    {
        return $answer;
    }

    /**
     * @Doc\ApiDoc(
     *    section="Answer",
     *    description="Création d'une réponse",
     *    input={"class"=AnswerType::class, "name"=""}
     * )
     * @Rest\Post("/api/admin/answer", name="answer_admin_create")
     * @Rest\View(StatusCode = 201)
     */
    public function createAction(Request $request)
    {
        $answer = new Answer();
        $data = $request->request->all();
        $form = $this->createForm(AnswerType::class, $answer);
        $form->submit($data);

        if ($form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            // récupération de l'auteur
            $authTokenHeader = $request->headers->get('X-Auth-Token');
            $token = $em->getRepository('SadevUserBundle:AuthToken')->findOneByValue($authTokenHeader);
            if ($token !== null) {
                $answer->setCreateBy($token->getUser());
                // $business->setPartner($token->getUser());
            }

            $em->persist($answer);
            $em->flush();
            return $answer;
        } else {
            return $form;
        }
    }

    /**
     * @Doc\ApiDoc(
     *    section="Answer",
     *    description="Modification totale d'une réponse",
     *    input={"class"=AnswerType::class, "name"=""}
     * )
     * @Rest\Post("/api/admin/answers/{id}", name="answer_admin_update_total")
     * @Rest\View(StatusCode = 200)
     * @ParamConverter("answer")
     */
    public function updateAction(Answer $answer, Request $request)
    {
        return $this->update($answer, $request, true);
    }

    /**
     * @Rest\Patch("/api/admin/answer/{id}", name="answer_admin_update_partielle")
     * @Doc\ApiDoc(
     *    section="Answer",
     *    description="Modification partielle d'une réponse",
     *    input={"class"=AnswerType::class, "name"=""}
     * )
     * @Rest\View()
     */
    public function patchAction(Request $request)
    {
        $answer = $this->getDoctrine()->getManager()->getRepository('SadevBusinessModelBundle:Answer')->find($request->get('id'));
        return $this->update($answer, $request, false);
    }

    private function update(Answer $answer, Request $request, $clearMissing)
    {
        $data = $request->request->all();
        $form = $this->createForm(AnswerType::class, $answer);
        $form->submit($data, $clearMissing);

        if ($form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->flush();
            return $answer;
        } else {
            return $form;
        }
    }

    /**
     * @Rest\Delete("/api/admin/answer/{id}", name="answer_admin_delete")
     * @Doc\ApiDoc(
     *    section="Answer",
     *    description="Suppression d'une réponse"
     * )
     * @Rest\View
     */
    public function deleteAction(Answer $answer)
    {
        $em = $this->getDoctrine()->getManager();
        $em->remove($answer);
        $em->flush();
    }

    /**
     * @Doc\ApiDoc(
     *    section="Answer",
     *    description="Récupération de la liste des réponses",
     *    output= { "class"=Answer::class, "collection"=true }
     * )
     * @Rest\Get("/api/admin/answers", name="answer_admin_list")
     * @Rest\QueryParam(
     *       name="business",
     *       nullable=true,
     *       description="id du business"
     * )
     * @Rest\View
     */
    public function listAction($business)
    {
        if ($business == '' || $business == null) {
            $answers = $this->getDoctrine()->getManager()->getRepository('SadevBusinessModelBundle:Answer')->findAll();
        } else {
            $answers = $this->getDoctrine()->getManager()->getRepository('SadevBusinessModelBundle:Answer')->findBy(['business' => $business]);
        }
        return $answers;
    }
}