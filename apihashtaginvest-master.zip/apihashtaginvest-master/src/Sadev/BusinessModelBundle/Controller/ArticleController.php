<?php

namespace Sadev\BusinessModelBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sadev\BusinessModelBundle\Entity\Article;
use Sadev\BusinessModelBundle\Form\ArticleType;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\Request;
use FOS\RestBundle\Controller\Annotations as Rest;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Component\Security\Core\SecurityContext;
use FOS\RestBundle\Controller\Annotations\QueryParam;

use Nelmio\ApiDocBundle\Annotation as Doc;


class ArticleController extends Controller
{
    
    /**
     * @Rest\Get("/api/admin/articles/{id}", name="article_admin_show")
     * @Rest\View
     * @Doc\ApiDoc(
     *     section="Article",
     *     description="Récuperation d'une article",
     *     
     * )
     */
    public function showAction(Article $article)
    {

        /*
        récupération de l'entité grâce au 
        ParamConverter de Doctrine qui nous permet 
        d'aller chercher un objet en base de données.
        */
        $em = $this->getDoctrine()->getManager();

        $enrelations = array();

        foreach($article->getCategories() as $elem ) {


            if(count($enrelations) >= 5)
            break;

            // $r = array();
            $r = $this->actuCat($elem, $em);

            foreach($r as $art){

                if(count($enrelations) >= 5)
                break;

                if($art->getId() !== $article->getid()) {
                    $row['id'] = $art->getId();
                    $row['titre'] = $art->getTitre();
                    $row['datepublish'] = $art->getDatePublish()->format('Y-m-d');
                    $row['photo'] = $art->getPhoto();
                    $row['slug'] = $art->getSlug();
                    $enrelations[] = $row;
                }
               

            }
            

        }
		
		
		
		//$next = $em->getRepository('EricoApiBundle:Produit')->getNext($produit->getId());
		$article->publicationsSimilaires = $enrelations;
       
        return $article;        

    }

    /**
     * @DOC\ApiDoc(
     *    section="Article",
     *    description="Création d'un article",
     *    input={"class"=ArticleType::class, "name"=""}
     * )
     *@Rest\Post("/api/admin/articles", name="article_admin_create")
     *@Rest\View(StatusCode = 201)
     */
    public function createAction(Request $request)
    {

        $article = new article;
        //$user->setCompany($company);

        /* 
        Bien que nous puissions créer ou mettre à jour une entité
        sans aucune validation, nous utiliserons néanmoins les formulaires de Symfony pour effectué cette validation.
        Dans le formType il faut obligatoirement désactiver la protection CSRF (Cross-Site Request Forgery). 
        Dans une API,  Nous n’utilisons pas de session et l’utilisateur de l’API peut appeler cette méthode sans se soucier de l’état de l’application : l’API doit rester sans état : stateless.
        */

        /* 
        En plus du système de validation l'autre avantage
        d'utiliser les formulaires est l'hydratation de l'entité avec 
        les données de la requette ce qui nous permet de gagner en productivité
        */

        $data = $request->request->all(); // recuperation des données qui sont automatiquement deserialiser par FosRest pour être traité par le formulaire.
        $form = $this->createForm(ArticleType::class, $article);

        //convertion du json reçu en objet comme le fait le paramConveter
        $form->submit($data);

        if ($form->isValid()) //validation des données avant la sauvegarde
        {

            $em = $this->getDoctrine()->getManager();

            // recuperation de l'auteur
            $authTokenHeader = $request->headers->get('X-Auth-Token');
            
            $token = $this->getDoctrine()->getManager()->getRepository('SadevUserBundle:AuthToken')->findOneByValue($authTokenHeader);
            if ($token !== null) { 
                $article->setCreateBy($token->getUser());
            } 

            if($article->photoSelected != null)
            $article->setPhoto($article->photoSelected);

            $em->persist($article);
            $em->flush(); 
            return $article;

        } else {

            return $form;

        }
        
        
    }

    /**
     *@DOC\ApiDoc(
     * section="Article",
     * description="Modification totale d'un article",
     * input={"class"=ArticleType::class, "name"=""}
     *)
     *@Rest\Put("/api/admin/articles/{id}", name="article_admin_update_total")
     *@Rest\View(StatusCode = 200)
     *@ParamConverter("article")
     */
    public function updateAction(Article $article, Request $request)
    {

        return $this->update($article, $request, true);

    }

    /**
     *@Rest\Patch("/api/admin/articles/{id}", name="article_admin_update_partielle")
     *@DOC\ApiDoc(
     *    section="Article",
     *    description="Modification partielle d'un article",
     *    input={"class"=ArticleType::class, "name"=""}
     *)
     *@Rest\View()
     */
    public function patchAction(Request $request)
    {
        
        $article = $this->getDoctrine()->getManager()->getRepository('SadevBusinessModelBundle:Article') ->find($request->get('id'));

        return $this->update($article, $request, false);

    }

    private function update(Article $article, Request $request, $clearMissing)
    {
        // ici pas besoin de rechercher l'entite ou de le créer car il est recuperer automatique grâce à l'info contenu dans le paramConverter
        
        /* 
        Bien que nous puissions créer ou mettre à jour une entité
        sans aucune validation, nous utiliserons néanmoins les formulaires de Symfony pour effectué cette validation.
        Dans le formType il faut obligatoirement désactiver la protection CSRF (Cross-Site Request Forgery). 
        Dans une API,  Nous n’utilisons pas de session et l’utilisateur de l’API peut appeler cette méthode sans se soucier de l’état de l’application : l’API doit rester sans état : stateless.
        */

        /* 
        En plus du système de validation l'autre avantage
        d'utiliser les formulaires est l'hydratation de l'entité avec 
        les données de la requette ce qui nous permet de gagner en productivité
        */
        
        $data = $request->request->all(); // recuperation des données qui sont automatiquement deserialiser par FosRest pour être traité par le formulaire.
        $form = $this->createForm(ArticleType::class, $article);
        
        //convertion du json reçu en objet comme le fait le paramConveter
        //L’implémentation de la mise à jour partielle avec Symfony est très proche de la mise à jour complète. Il suffit de rajouter un paramètre dans la méthode submit (clearMissing = false) et le tour est joué. Comme son nom l’indique, avec clearMissing à false, Symfony conservera tous les attributs de l’entité  qui ne sont pas présents dans les paramètres de la requête
        $form->submit($data, $clearMissing);
        
        if ($form->isValid()) //validation des données avant la sauvegarde
        {
            $em = $this->getDoctrine()->getManager();

            if($article->photoSelected !== null)
            $article->setPhoto($article->photoSelected);
            
            $em->flush();
            return $article;
        } else {
            return $form;
        }
        
    }

     /**
     * @Rest\Delete("/api/admin/articles/{id}", name="article_admin_delete")
     * @DOC\ApiDoc(
     *    section="Article",
     *    description="Supression d'un article",
     * )
     * @Rest\View
     */
    public function deleteAction(Article $article)
    {

        /*
        récupération de l'entité grâce au 
        ParamConverter de Doctrine qui nous permet 
        d'aller chercher un objet en base de données.
        */
        $em = $this->getDoctrine()->getManager();
        $em->remove($article);
        $em->flush();

    }


    /**
     * @Doc\ApiDoc(
     *    section="Article",
     *    description="Récupération de la liste des articles",
     *    output= { "class"=Article::class, "collection"=true }
     * )
     * @Rest\Get("/api/admin/articles", name="article_admin_list")
     * @Rest\QueryParam(
     *       name="idcat",
     *       nullable=true,
     *       description="id catégorie"
     * )
     * @Rest\QueryParam(
     *       name="nbrresult",
     *       nullable=true,
     *       description="Nombre de resultats par page"
     * )
     * @Rest\QueryParam(
     *       name="numpage",
     *       nullable=true,
     *       description="Numero de la page"
     * )
     * @Rest\View
     */
    public function listAction($idcat, $numpage, $nbrresult)
    {

        $em = $this->getDoctrine()->getManager();
        
        if($nbrresult == '' || $nbrresult == null)
		{
            $nbrresult = 10;
        }
        
        $debutresultat = 0;

        if($numpage > 1 )
		{
			$debutresultat = $nbrresult * ($numpage-1); //car le numero de page peut etre negatif
		}

        if($idcat != '' && $idcat != null)
        {
            $cat = $em->getRepository('SadevBusinessModelBundle:Categorie')->find($idcat);
            // $actus = $this->actuCat($cat, $em);
             $result = $this->actuCat($cat,  $em);
			$actus = array();
			
			$comp = 0;
			
			while( $comp < $nbrresult )
			{

				$index = $debutresultat + $comp;
				
				if(isset($result[$index]))
				{
					$actus[] = $result[$index];
				}
				
                $comp++;

            }

        }	
		else
		{
			// $actus = $em->getRepository('SadevBusinessModelBundle:Article')->findBy(array('isPublish'=>true), array('datePublish' => 'DESC'), $nbrresult, $debutresultat);
			$actus = $em->getRepository('SadevBusinessModelBundle:Article')->findBy(array(), array('id' => 'DESC'), $nbrresult, $debutresultat);
        }
        

        return $actus; 

        /* $article = $this->getDoctrine()->getManager()->getRepository('SadevBusinessModelBundle:Article')->findAll();
        return $article; */

    }

    public function actuCat($cat, $em)
	{
		$actus = array();
		
		//recuperation des actualites qui ont pour categorie par defaut $cat
		// $this->actuDefaultCatandFils($cat, $actus, $em);
		$this->actuCatandFils($cat, $actus, $em);
		
		//elemination des doublons
		$newActus = array();
		$temp = array();
		
		foreach($actus as $elemActu){
			
			if(!(in_array($elemActu->getId(), $temp))){
			
				$newActus[] = $elemActu;
				$temp[] = $elemActu->getId();
				
			}
		
		}
		
		return $newActus;
		
	}
	
	public function actuCatandFils($cat, &$actus, $em)
	{
		
		$pub = $em->getRepository('SadevBusinessModelBundle:Article')->FindActuCat($cat->getId());
		
		foreach($pub as $elemActu){
            
			$actus[] = $elemActu;
		
		}
		
		if($cat->getFils() != null)
		{
			
			foreach($cat->getFils() as $elem){
			
				$this->actuCatandFils($elem, $actus, $em);
				
			}
			
		}
		
	}

	



}
