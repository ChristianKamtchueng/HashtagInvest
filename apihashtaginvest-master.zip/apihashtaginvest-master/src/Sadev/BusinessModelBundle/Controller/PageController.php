<?php

namespace Sadev\BusinessModelBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sadev\BusinessModelBundle\Entity\Page;
use Sadev\BusinessModelBundle\Form\PageType;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\Request;
use FOS\RestBundle\Controller\Annotations as Rest;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Component\Security\Core\SecurityContext;
use FOS\RestBundle\Controller\Annotations\QueryParam;

use Nelmio\ApiDocBundle\Annotation as Doc;


class PageController extends Controller
{
    
    /**
     * @Rest\Get("/api/admin/pages/{id}", name="page_admin_show")
     * @Rest\View
     * @Doc\ApiDoc(
     *     section="Page",
     *     description="Récuperation d'une page",
     *     
     * )
     */
    public function showAction(Page $page)
    {

        /*
        récupération de l'entité grâce au 
        ParamConverter de Doctrine qui nous permet 
        d'aller chercher un objet en base de données.
        */
       
        return $page;

    }

    /**
     * @DOC\ApiDoc(
     *    section="Page",
     *    description="Création d'une page",
     *    input={"class"=PageType::class, "name"=""}
     * )
     *@Rest\Post("/api/admin/pages", name="page_admin_create")
     *@Rest\View(StatusCode = 201)
     */
    public function createAction(Request $request)
    {

        $page = new Page;
        //$user->setCompany($company);

        /* 
        Bien que nous puissions créer ou mettre à jour une entité
        sans aucune validation, nous utiliserons néanmoins les formulaires de Symfony pour effectué cette validation.
        Dans le formType il faut obligatoirement désactiver la protection CSRF (Cross-Site Request Forgery). 
        Dans une API,  Nous n’utilisons pas de session et l’utilisateur de l’API peut appeler cette méthode sans se soucier de l’état de l’application : l’API doit rester sans état : stateless.
        */

        /* 
        En plus du système de validation l'autre avantage
        d'utiliser les formulaires est l'hydratation de l'entité avec 
        les données de la requette ce qui nous permet de gagner en productivité
        */

        $data = $request->request->all(); // recuperation des données qui sont automatiquement deserialiser par FosRest pour être traité par le formulaire.
        $form = $this->createForm(PageType::class, $page);

        //convertion du json reçu en objet comme le fait le paramConveter
        $form->submit($data);

        if ($form->isValid()) //validation des données avant la sauvegarde
        {

            $em = $this->getDoctrine()->getManager();

            // recuperation de l'auteur
            $authTokenHeader = $request->headers->get('X-Auth-Token');
            
            $token = $this->getDoctrine()->getManager()->getRepository('SadevUserBundle:AuthToken')->findOneByValue($authTokenHeader);
            if ($token !== null) { 
                $page->setCreateBy($token->getUser());
            } 

            if($page->photoSelected != null)
            $page->setPhoto($page->photoSelected);

            if($page->fichierSelected != null)
            $page->setFichier($page->fichierSelected);

            $em->persist($page);
            $em->flush(); 
            return $page;

        } else {

            return $form;

        }
        
        
    }

    /**
     *@DOC\ApiDoc(
     * section="Page",
     * description="Modification totale d'une page",
     * input={"class"=PageType::class, "name"=""}
     *)
     *@Rest\Put("/api/admin/pages/{id}", name="page_admin_update_total")
     *@Rest\View(StatusCode = 200)
     *@ParamConverter("page")
     */
    public function updateAction(Page $page, Request $request)
    {

        return $this->update($page, $request, true);

    }

    /**
     *@Rest\Patch("/api/admin/pages/{id}", name="page_admin_update_partielle")
     *@DOC\ApiDoc(
     *    section="Page",
     *    description="Modification partielle d'une page",
     *    input={"class"=PageType::class, "name"=""}
     *)
     *@Rest\View()
     */
    public function patchAction(Request $request)
    {
        
        $page = $this->getDoctrine()->getManager()->getRepository('SadevBusinessModelBundle:Page') ->find($request->get('id'));

        return $this->update($page, $request, false);

    }

    private function update(Page $page, Request $request, $clearMissing)
    {
        // ici pas besoin de rechercher l'entite ou de le créer car il est recuperer automatique grâce à l'info contenu dans le paramConverter
        
        /* 
        Bien que nous puissions créer ou mettre à jour une entité
        sans aucune validation, nous utiliserons néanmoins les formulaires de Symfony pour effectué cette validation.
        Dans le formType il faut obligatoirement désactiver la protection CSRF (Cross-Site Request Forgery). 
        Dans une API,  Nous n’utilisons pas de session et l’utilisateur de l’API peut appeler cette méthode sans se soucier de l’état de l’application : l’API doit rester sans état : stateless.
        */

        /* 
        En plus du système de validation l'autre avantage
        d'utiliser les formulaires est l'hydratation de l'entité avec 
        les données de la requette ce qui nous permet de gagner en productivité
        */
        
        $data = $request->request->all(); // recuperation des données qui sont automatiquement deserialiser par FosRest pour être traité par le formulaire.
        $form = $this->createForm(PageType::class, $page);
        
        //convertion du json reçu en objet comme le fait le paramConveter
        //L’implémentation de la mise à jour partielle avec Symfony est très proche de la mise à jour complète. Il suffit de rajouter un paramètre dans la méthode submit (clearMissing = false) et le tour est joué. Comme son nom l’indique, avec clearMissing à false, Symfony conservera tous les attributs de l’entité  qui ne sont pas présents dans les paramètres de la requête
        $form->submit($data, $clearMissing);
        
        if ($form->isValid()) //validation des données avant la sauvegarde
        {
            $em = $this->getDoctrine()->getManager();

            if($page->photoSelected != null)
            $page->setPhoto($page->photoSelected);

            if($page->fichierSelected != null)
            $page->setFichier($page->fichierSelected);

            $descendants = array();
            foreach($page->descendant() as $elem ) {
                $descendants[] =  $elem->id;
            }

            // vérification parent
            if( $page->getParent() !== null && in_array($page->getParent()->getId(), $descendants))
            throw new AccessDeniedHttpException('Page parente incorrect: une page fille ou descendante ne peu pas être parent de sa page parente.');

            
            $em->flush();
            return $page;
        } else {
            return $form;
        }
        
    }

     /**
     * @Rest\Delete("/api/admin/pages/{id}", name="page_admin_delete")
     * @DOC\ApiDoc(
     *    section="Page",
     *    description="Supression d'une page",
     * )
     * @Rest\View
     */
    public function deleteAction(Page $page)
    {

        /*
        récupération de l'entité grâce au 
        ParamConverter de Doctrine qui nous permet 
        d'aller chercher un objet en base de données.
        */
        $em = $this->getDoctrine()->getManager();
        $em->remove($page);
        $em->flush();

    }


    /**
     * @Doc\ApiDoc(
     *    section="Page",
     *    description="Récupération de la liste des pages",
     *    output= { "class"=Page::class, "collection"=true }
     * )
     * @Rest\Get("/api/admin/pages", name="page_admin_list")
     * @Rest\View
     */
    public function listAction()
    {
        $pageS = $this->getDoctrine()->getManager()->getRepository('SadevBusinessModelBundle:Page')->findAll();
        
        return $pageS;
    }



}
