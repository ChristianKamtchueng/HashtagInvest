<?php

namespace Sadev\BusinessModelBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sadev\BusinessModelBundle\Entity\Devis;
use Sadev\BusinessModelBundle\Form\DevisType;
use Sadev\BusinessModelBundle\Entity\DevisPayment;

use Symfony\Component\HttpFoundation\Request;
use FOS\RestBundle\Controller\Annotations as Rest;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use FOS\RestBundle\Controller\Annotations\QueryParam;
use Nelmio\ApiDocBundle\Annotation as Doc;


class DevisController extends Controller
{
    /**
     * @Rest\Get("/api/admin/devis/{id}", name="devis_admin_show")
     * @Rest\View
     * @Doc\ApiDoc(
     *     section="Devis",
     *     description="Récupération d'un devis"
     * );
     */
    public function showAction(Devis $devis)
    {

        return $devis;

    }

    /**
     * @Doc\ApiDoc(
     *    section="Devis",
     *    description="Création d'un devis",
     *    input={"class"=DevisType::class, "name"=""}
     * )
     * @Rest\Post("/api/admin/devis", name="devis_admin_create")
     * @Rest\View(StatusCode = 201)
     */
    public function createAction(Request $request)
    {
        $devis = new Devis();
        $data = $request->request->all();
        $form = $this->createForm(DevisType::class, $devis);
        $form->submit($data);

        if ($form->isValid()) {

            $em = $this->getDoctrine()->getManager();

            // récupération de l'auteur et du partenaire via X-Auth-Token (si présent)
            /* $authTokenHeader = $request->headers->get('X-Auth-Token');
            if ($authTokenHeader) {
                $token = $em->getRepository('SadevUserBundle:AuthToken')->findOneByValue($authTokenHeader);
                if ($token !== null) {
                    $devis->setCreateBy($token->getUser());
                    // si Devis possède un champ partner similaire, décommenter :
                    // $devis->setPartner($token->getUser());
                }
            } */

            $devis->setDatecommande(new \DateTime());
            $em->persist($devis);
            $devis->getAnswer()->getBusiness()->setDevisave($devis);

            $em->flush();
            return $devis;

        }

        return $form;
    }

    /**
     * @Doc\ApiDoc(
     *    section="Devis",
     *    description="Modification totale d'un devis",
     *    input={"class"=DevisType::class, "name"=""}
     * )
     * @Rest\Post("/api/admin/devises/{id}", name="devis_admin_update_total")
     * @Rest\View(StatusCode = 200)
     * @ParamConverter("devis")
     */
    public function updateAction(Devis $devis, Request $request)
    {
        return $this->update($devis, $request, true);
    }

    /**
     * @Rest\Patch("/api/admin/devis/{id}", name="devis_admin_update_partielle")
     * @Doc\ApiDoc(
     *    section="Devis",
     *    description="Modification partielle d'un devis",
     *    input={"class"=DevisType::class, "name"=""}
     * )
     * @Rest\View()
     */
    public function patchAction(Request $request)
    {
        $devis = $this->getDoctrine()->getManager()->getRepository('SadevBusinessModelBundle:Devis')->find($request->get('id'));
        return $this->update($devis, $request, false);
    }

    private function update(Devis $devis, Request $request, $clearMissing)
    {
        $data = $request->request->all();
        $form = $this->createForm(DevisType::class, $devis);
        $form->submit($data, $clearMissing);

        if ($form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->flush();
            return $devis;
        }

        return $form;
    }

    /**
     * @Rest\Delete("/api/admin/devis/{id}", name="devis_admin_delete")
     * @Doc\ApiDoc(
     *    section="Devis",
     *    description="Suppression d'un devis"
     * )
     * @Rest\View
     */
    public function deleteAction(Devis $devis)
    {
        $em = $this->getDoctrine()->getManager();
        $em->remove($devis);
        $em->flush();
    }

    /**
     * @Doc\ApiDoc(
     *    section="Devis",
     *    description="Récupération de la liste des devis",
     *    output= { "class"=Devis::class, "collection"=true }
     * )
     * @Rest\Get("/api/admin/devises", name="devis_admin_list")
     * @Rest\QueryParam(
     *       name="partner",
     *       nullable=true,
     *       description="id du partenaire"
     * )
     * @Rest\View
     */
    public function listAction($partner)
    {
        $repo = $this->getDoctrine()->getManager()->getRepository('SadevBusinessModelBundle:Devis');

        if ($partner == '' || $partner == null) {
            $devisList = $repo->findAll();
        } else {
            $devisList = $repo->findBy(['partner' => $partner]);
        }

        return $devisList;
    }


    /**
     * @Rest\Get("/api/devis/{devis}/payment/url", name="payment_url")
     * @Rest\QueryParam(
     *       name="montant",
     *       nullable=true,
     *       description="montant"
     * )
     * @Rest\View
    */
    public function generatePaymentURL(Devis $devis, Request $request, $montant)
    {
        // recuperation url du client (et non de l'api) de la requette depuis L'object Request
        $originHeader = $request->headers->get('origin');
        $refererHeader = $request->headers->get('referer');

        $site_url = null;

        if ($originHeader) {
            $site_url = $originHeader;
        } elseif ($refererHeader) {
            $parts = parse_url($refererHeader);
            if ($parts !== false && isset($parts['scheme'], $parts['host'])) {
                $site_url = $parts['scheme'] . '://' . $parts['host'] . (isset($parts['port']) ? ':' . $parts['port'] : '');
            }
        }

        // Sécurité : valider l'origine avant usage (optionnel mais recommandé)
        // $allowed = ['https://hashtaginvest.fr','https://dev.hashtaginvest.fr','http://localhost:4201'];
        // if ($site_url && !in_array($site_url, $allowed, true)) {
        //     $site_url = null;
        // }

        // fallback : si on ne trouve rien, utiliser le host de l'API (moins souhaitable)
        if (!$site_url) {
            $site_url = $request->getSchemeAndHttpHost();
        }

        // $site_url = 'http://localhost:4201';
        // $site_url = 'https://dev.hashtaginvest.fr';
        // $site_url = 'https://hashtaginvest.fr';
        $answer = $devis->getAnswer();

        // Set your secret key. Remember to switch to your live secret key in production.
        // See your keys here: https://dashboard.stripe.com/apikeys
        // $apiKey = 'sk_test_51SHnbR6sYrFzhqb3pA0NBJqyuQgvBpbMq4nOIzmcrd7yev5KUVXvU8gr3iwc7iSSZFqodWfW44hDsFT4ARitD69p00XjOZCUW5';

        if(strpos($site_url, 'hashtaginvest.fr') !== false) {
            $apiKey = $this->container->get('businessmodel.my_service')->getApiKey('production');
		} else {
            $apiKey = $this->container->get('businessmodel.my_service')->getApiKey('test'); 
        }

        $stripe = new \Stripe\StripeClient($apiKey);

        $session = $stripe->checkout->sessions->create([
        'line_items' => [
            [
            //'price' => $answer->getPrice(),
            'price_data' => [
                'currency'     => 'EUR',
                'product_data' => [
                    'name' => $answer->getActivity()
                ],
                // 'unit_amount'  => $answer->getPrice() * 100, // en centimes

                'unit_amount'  => $montant * 100, // en centimes
            ],
            //'quantity' => $answer->getQte(),
            'quantity' => 1, // car le montant est déjà totalisé
            ],
        ],
        'mode' => 'payment', // ou 'subscription' pour les abonnements
        'success_url' => $site_url.'/devis/'.$devis->getId().'/pay?successpay='.$montant,
        'cancel_url' => $site_url.'/devis/'.$devis->getId().'/pay?cancelpay='.$montant,
        'metadata' => [
            'devis_id' => $devis->getId(),
            'site_url' => $site_url
        ]
        ]);


        /* header("HTTP/1.1 303 See Other");
        header("Location: " . $session->url); */

        // return $this->redirect($session->url, array());

        return $session->url;

        /* $session = Session::create([
            'line_items'                  => [
                array_map(fn(array $product) => [
                    'quantity'   => 1,
                    'price_data' => [
                        'currency'     => 'EUR',
                        'product_data' => [
                            'name' => $product['name']
                        ],
                        'unit_amount'  => $product['price']
                    ]
                ], $cart->getProducts())
            ],
            'mode'                        => 'payment',
            'success_url'                 => 'http://localhost:8000/success.php',
            'cancel_url'                  => 'http://localhost:8000/',
            'billing_address_collection'  => 'required',
            'shipping_address_collection' => [
                'allowed_countries' => ['FR']
            ],
            'metadata'                    => [
                'cart_id' => $cart->getId()
            ]
        ]); */

        // return $devis;

    }

}