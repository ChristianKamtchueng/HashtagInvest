<?php

namespace Sadev\BusinessModelBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sadev\BusinessModelBundle\Entity\Business;
use Sadev\BusinessModelBundle\Form\BusinessType;
use Sadev\BusinessModelBundle\Entity\Answer;
use Sadev\BusinessModelBundle\Entity\Fichier;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\Request;
use FOS\RestBundle\Controller\Annotations as Rest;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Component\Security\Core\SecurityContext;
use FOS\RestBundle\Controller\Annotations\QueryParam;

use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

use Nelmio\ApiDocBundle\Annotation as Doc;

class BusinessController extends Controller
{
    /**
     * @Rest\Get("/api/admin/business/{id}", name="business_admin_show")
     * @Rest\View
     * @Doc\ApiDoc(
     *     section="Business",
     *     description="Récupération d'un business"
     * )
     */
    public function showAction(Business $business)
    {
        return $business;
    }

    /**
     * @Doc\ApiDoc(
     *    section="Business",
     *    description="Création d'un business",
     *    input={"class"=BusinessType::class, "name"=""}
     * )
     * @Rest\Post("/api/admin/business", name="business_admin_create")
     * @Rest\View(StatusCode = 201)
     */
    public function createAction(Request $request)
    {
        $business = new Business;

        $data = $request->request->all();
        $form = $this->createForm(BusinessType::class, $business);
        $form->submit($data);

        if ($form->isValid()) {
            $em = $this->getDoctrine()->getManager();

            // récupération de l'auteur
            $authTokenHeader = $request->headers->get('X-Auth-Token');
            $token = $em->getRepository('SadevUserBundle:AuthToken')->findOneByValue($authTokenHeader);
            if ($token !== null) {
                $business->setCreateBy($token->getUser());
                // $business->setPartner($token->getUser());
            }

            $em->persist($business);
            $em->flush();
            return $business;
        } else {
            return $form;
        }
    }

    /**
     * @Doc\ApiDoc(
     *    section="Business",
     *    description="Modification totale d'un business",
     *    input={"class"=BusinessType::class, "name"=""}
     * )
     * @Rest\Post("/api/admin/businesses/{id}", name="business_admin_update_total")
     * @Rest\View(StatusCode = 200)
     * @ParamConverter("business")
     */
    public function updateAction(Business $business, Request $request)
    {
        return $this->update($business, $request, true);
    }

    /**
     * @Rest\Patch("/api/admin/business/{id}", name="business_admin_update_partielle")
     * @Doc\ApiDoc(
     *    section="Business",
     *    description="Modification partielle d'un business",
     *    input={"class"=BusinessType::class, "name"=""}
     * )
     * @Rest\View()
     */
    public function patchAction(Business $business, Request $request)
    {
        //$business = $this->getDoctrine()->getManager()->getRepository('SadevBusinessModelBundle:Business')->find($request->get('id'));
        return $this->update($business, $request, false);
    }

    private function update(Business $business, Request $request, $clearMissing)
    {
        $data = $request->request->all();
        $form = $this->createForm(BusinessType::class, $business);
        $form->submit($data, $clearMissing);

        if ($form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->flush();
            return $business;
        } else {
            return $form;
        }
    }

    /**
     * @Rest\Delete("/api/admin/business/{id}", name="business_admin_delete")
     * @Doc\ApiDoc(
     *    section="Business",
     *    description="Suppression d'un business"
     * )
     * @Rest\View
     */
    public function deleteAction(Business $business)
    {
        $em = $this->getDoctrine()->getManager();
        $em->remove($business);
        $em->flush();
    }

    /**
     * @Doc\ApiDoc(
     *    section="Business",
     *    description="Récupération de la liste des business",
     *    output= { "class"=Business::class, "collection"=true }
     * )
     * @Rest\Get("/api/admin/businesses", name="business_admin_list")
     * @Rest\QueryParam(
     *       name="partner",
     *       nullable=true,
     *       description="id du partenaire"
     * )
     * @Rest\View
     */
    public function listAction($partner)
    {
        $em = $this->getDoctrine()->getManager();

        if($partner == '' || $partner == null){

            $businesses = $em->getRepository('SadevBusinessModelBundle:Business')->findAll();

        } else {

            $businesses = $em->getRepository('SadevBusinessModelBundle:Business')->findBy(array('createBy' => $partner));

        }

        return $businesses;
    }


    /**
     * @Rest\Post("/api/admin/business/{id}/addimage", name="business_add_image")
     * @DOC\ApiDoc(
     *    section="Business",
     *    description="Ajout image",
     *    input={"class"=FichierType::class, "name"=""}
     * )
     * @Rest\View(StatusCode = 200)
     * @ParamConverter("business")
     */
    public function addImageAction(Business $business, Request $request)
    {
        // ici pas besoin de rechercher l'entite ou de le créer car il est recuperer automatique grâce à l'info contenu dans le paramConverter
        
        /* 
        Bien que nous puissions créer ou mettre à jour une entité
        sans aucune validation, nous utiliserons néanmoins les formulaires de Symfony pour effectué cette validation.
        Dans le formType il faut obligatoirement désactiver la protection CSRF (Cross-Site Request Forgery). 
        Dans une API,  Nous n’utilisons pas de session et l’utilisateur de l’API peut appeler cette méthode sans se soucier de l’état de l’application : l’API doit rester sans état : stateless.
        */

        /* 
        En plus du système de validation l'autre avantage
        d'utiliser les formulaires est l'hydratation de l'entité avec 
        les données de la requette ce qui nous permet de gagner en productivité
        */
        
        $data = $request->request->all(); // recuperation des données qui sont automatiquement deserialiser par FosRest pour être traité par le formulaire.
        $form = $this->createForm(BusinessType::class, $business);
        
        //convertion du json reçu en objet comme le fait le paramConveter
        //L’implémentation de la mise à jour partielle avec Symfony est très proche de la mise à jour complète. Il suffit de rajouter un paramètre dans la méthode submit (clearMissing = false) et le tour est joué. Comme son nom l’indique, avec clearMissing à false, Symfony conservera tous les attributs de l’entité  qui ne sont pas présents dans les paramètres de la requête
        $form->submit($data, false);
        
        if ($form->isValid()) //validation des données avant la sauvegarde
        {
            
            $em = $this->getDoctrine()->getManager();
            // appeler le setFileData après le $form->submit() pour eviter d'ecraser avec le $form->submit()
            $result = array();

            if( isset($request->files->all()['filesdata']) ){

                if( isset( $request->files->all()['filesdata']) ){
    
                    foreach($request->files->all()['filesdata'] as $elem) {
                        $fichier = new Fichier;
                        $fichier->setFiledata($elem);
                        $fichier->setDossierRacine('business/img');
                        $em->persist($fichier);
                        $business->addPhoto($fichier);
                        $result[] = $fichier;
                    }
    
                }

                if( count($result)>0 && $business->getImagePrincipale() === null  ) {
                    $business->setImagePrincipale($result[0]);
                }

            }/*  else {

                $company->setLogo(null);
            } */

            // $user->getPhoto()->setFiledata($request->files->all()['filedata']);
            
            $em->flush();

            // $company = $this->getDoctrine()->getManager()->getRepository('SadevDefaultBundle:Company')->findOneByBaseName($tenant);

            /* foreach($result as $elem) {

                 // redimensionnement de l'image
                // $manager = $this->container->get(ImageManager::class);
                $targetPath = $elem->generatePathName('');
                // $savePath = $fichier->generatePathName('500x500_');
                $savePath = $targetPath;
                
                // $filigranePath = $this->getParameter('uri_prefix_filemanager').$company->getLogo()->path().$company->getLogo()->getName();

                // redimentionnement de l'image
                // $fichier->resize(500, 500, $targetPath, $savePath, $filigranePath); cas d'une image thumb
                $elem->resize(1025, null, $targetPath, $savePath, null);
                
            } */

            // on save la mise à jour de la taille de l'image au cas ou elle serais redimensionné et ecrasé
            $em->flush();

            return $result;

        } else {

            return $form;

        }
        
    }



    /**
     * @Rest\Delete("/api/admin/business/{id}/removeimage", name="business_remove_image")
     * @DOC\ApiDoc(
     *    section="Business",
     *    description="Suppression image",
     * )
     * @Rest\View(StatusCode = 200)
     * @ParamConverter("business")
     * @Rest\QueryParam(
     *    name="image",
     *    nullable=true,
     *    description="id de l'image à supprimer"
     * )
     */
    public function removeImageAction(Business $business, Request $request, $image)
    {
        // ici pas besoin de rechercher l'entite ou de le créer car il est recuperer automatique grâce à l'info contenu dans le paramConverter
        
        $em = $this->getDoctrine()->getManager();

        $fichier =  $em->getRepository('SadevBusinessModelBundle:Fichier')->find($image);
        $business->removePhoto($fichier);

        if( $business->getImagePrincipale() !== null &&  $business->getImagePrincipale()->getId() == $fichier->getId()) {

            if(count($business->getPhotos()) > 0)
            $business->setImagePrincipale($business->getPhotos()[0]);
            else
            $business->setImagePrincipale(null);

        }

        $em->remove($fichier);
        $em->flush();
        
    }


    /**
     * @Rest\Post("/api/admin/business/{id}/addocuments", name="business_add_documents")
     * @DOC\ApiDoc(
     *    section="Business",
     *    description="Ajout documents",
     *    input={"class"=FichierType::class, "name"=""}
     * )
     * @Rest\View(StatusCode = 200)
     * @ParamConverter("business")
     */
    public function addocumentAction(Business $business, Request $request)
    {
        // ici pas besoin de rechercher l'entite ou de le créer car il est recuperer automatique grâce à l'info contenu dans le paramConverter
        
        /* 
        Bien que nous puissions créer ou mettre à jour une entité
        sans aucune validation, nous utiliserons néanmoins les formulaires de Symfony pour effectué cette validation.
        Dans le formType il faut obligatoirement désactiver la protection CSRF (Cross-Site Request Forgery). 
        Dans une API,  Nous n’utilisons pas de session et l’utilisateur de l’API peut appeler cette méthode sans se soucier de l’état de l’application : l’API doit rester sans état : stateless.
        */

        /* 
        En plus du système de validation l'autre avantage
        d'utiliser les formulaires est l'hydratation de l'entité avec 
        les données de la requette ce qui nous permet de gagner en productivité
        */
        
        $data = $request->request->all(); // recuperation des données qui sont automatiquement deserialiser par FosRest pour être traité par le formulaire.
        $form = $this->createForm(BusinessType::class, $business);
        
        //convertion du json reçu en objet comme le fait le paramConveter
        //L’implémentation de la mise à jour partielle avec Symfony est très proche de la mise à jour complète. Il suffit de rajouter un paramètre dans la méthode submit (clearMissing = false) et le tour est joué. Comme son nom l’indique, avec clearMissing à false, Symfony conservera tous les attributs de l’entité  qui ne sont pas présents dans les paramètres de la requête
        $form->submit($data, false);
        
        if ($form->isValid()) //validation des données avant la sauvegarde
        {
            
            $em = $this->getDoctrine()->getManager();
            $result = array();
            // appeler le setFileData après le $form->submit() pour eviter d'ecraser avec le $form->submit()
            if( isset($request->files->all()['filesdata']) ){
                // $ext = pathinfo($request->files->all()['filedata'])['extension'];

                // throw new AccessDeniedHttpException("confirmation fichier envoyé");

                if( isset( $request->files->all()['filesdata']) ){
    
                    foreach($request->files->all()['filesdata'] as $elem) {

                        $fichier = new Fichier;
                        $fichier->setFiledata($elem);
                        $fichier->setLabel($elem->getClientOriginalName());
                        $fichier->setDossierRacine('business/docs');
                        $em->persist($fichier);
                        $business->addDocument($fichier);
                        $result[] = $fichier;

                    }
    
                }
                
                $em->flush(); 
                return $result;

            } else {

                throw new AccessDeniedHttpException("fichier non envoyé");

            } 

            // $user->getPhoto()->setFiledata($request->files->all()['filedata']);
            // on save la mise à jour de la taille de l'image au cas ou elle serais redimensionné et ecrasé

        } else {

            return $form;

        }
        
    }

    
    /**
     * @Rest\Delete("/api/admin/business/{id}/removedoc", name="produit_removedoc")
     * @DOC\ApiDoc(
     *    section="Business",
     *    description="Suppression un document",
     * )
     * @Rest\View(StatusCode = 200)
     * @ParamConverter("business")
     * @Rest\QueryParam(
     *    name="fichier",
     *    nullable=true,
     *    description="id du document à supprimer"
     * )
     */
    public function removeDocAction(Business $business, Request $request, $fichier)
    {
        // ici pas besoin de rechercher l'entite ou de le créer car il est recuperer automatique grâce à l'info contenu dans le paramConverter
        
        $em = $this->getDoctrine()->getManager();

        $fichier =  $em->getRepository('SadevBusinessModelBundle:Fichier')->find($fichier);
        $business->removeDocument($fichier);

        $em->remove($fichier);
        $em->flush();
        
    }


    /**
     * @Rest\Post("/api/admin/business/{id}/addocfile", name="business_add_doc")
     * @DOC\ApiDoc(
     *    section="Business",
     *    description="Ajouter un document",
     *    input={"class"=FichierType::class, "name"=""}
     * )
     * @Rest\QueryParam(
     *    name="typedoc",
     *    nullable=true,
     *    description="type de doc"
     * )
     * @Rest\View(StatusCode = 200)
     * @ParamConverter("business")
     */
    public function addocFileAction(Business $business, $typedoc, Request $request)
    {
        // ici pas besoin de rechercher l'entite ou de le créer car il est recuperer automatique grâce à l'info contenu dans le paramConverter
        
        /* 
        Bien que nous puissions créer ou mettre à jour une entité
        sans aucune validation, nous utiliserons néanmoins les formulaires de Symfony pour effectué cette validation.
        Dans le formType il faut obligatoirement désactiver la protection CSRF (Cross-Site Request Forgery). 
        Dans une API,  Nous n’utilisons pas de session et l’utilisateur de l’API peut appeler cette méthode sans se soucier de l’état de l’application : l’API doit rester sans état : stateless.
        */

        /* 
        En plus du système de validation l'autre avantage
        d'utiliser les formulaires est l'hydratation de l'entité avec 
        les données de la requette ce qui nous permet de gagner en productivité
        */
        
        $data = $request->request->all(); // recuperation des données qui sont automatiquement deserialiser par FosRest pour être traité par le formulaire.
        $form = $this->createForm(BusinessType::class, $business);
        
        //convertion du json reçu en objet comme le fait le paramConveter
        //L’implémentation de la mise à jour partielle avec Symfony est très proche de la mise à jour complète. Il suffit de rajouter un paramètre dans la méthode submit (clearMissing = false) et le tour est joué. Comme son nom l’indique, avec clearMissing à false, Symfony conservera tous les attributs de l’entité  qui ne sont pas présents dans les paramètres de la requête
        $form->submit($data, false);
        
        if ($form->isValid()) //validation des données avant la sauvegarde
        {
            
            $em = $this->getDoctrine()->getManager();
            // appeler le setFileData après le $form->submit() pour eviter d'ecraser avec le $form->submit()
            if( isset($request->files->all()['filedata']) ){

                // $ext = pathinfo($request->files->all()['filedata'])['extension'];

                // throw new AccessDeniedHttpException("confirmation fichier envoyé");
                
                $fichier = new Fichier;
                $fichier->setFiledata($request->files->all()['filedata']);

                $fichier->setDossierRacine('business/docs');

                $em->persist($fichier);

                $fichier->setLabel($fichier->getName());

                /* $produit->addOtherFile($fichier);

                if($produit->getSouscribeMode() != "download" && strtolower($fichier->ext()) != 'pdf' && strtolower($fichier->ext()) != 'mp4' && strtolower($fichier->ext()) != 'mp3') {
                    $em->remove($fichier);
                    $em->flush();
                    throw new AccessDeniedHttpException("Extension: ".$fichier->ext()." (Le mode d'accès choisie n'autorise que les fichiers aux format PDF, MP4 et MP3.)");
                }*/

                switch ($typedoc) {
                    case 'dpe':
                        $business->setDocdpe($fichier);
                        break;
                    case 'plan':
                        $business->setDocplans($fichier);
                        break;
                    case 'diagnosticstechniques':
                        $business->setDocdiagnosticstechniques($fichier);
                        break;
                    case 'compromismandat':
                        $business->setDoccompromismandat($fichier);
                        break;
                    default:
                        throw new AccessDeniedHttpException("Type de document inconnu");
                }  
                

                $em->flush();  

                // return $fichier;

                return $business;


            } else {

                throw new AccessDeniedHttpException("fichier non envoyé");
            } 

            // $user->getPhoto()->setFiledata($request->files->all()['filedata']);
                       
            // on save la mise à jour de la taille de l'image au cas ou elle serais redimensionné et ecrasé
           

        } else {

            return $form;

        }
        
    }


    /**
     * @Rest\Get("/api/admin/business/answer/{id}", name="reponse_business_admin_show")
     * @Rest\View
     * @Doc\ApiDoc(
     *     section="Business",
     *     description="Récupération choix reponse partenaire pour un business"
     * )
     */
    public function responseChoiceAction(Answer $answer)
    {
        
        $em = $this->getDoctrine()->getManager();
        $business = $answer->getBusiness();
        $business->setSelectedAnswer($answer);
        $business->setStatus('validated');

        $em->flush();
        return $business;

    }


    /**
     * @Doc\ApiDoc(
     *    section="Business",
     *    description="Récupération recherche de business",
     *    output= { "class"=Business::class, "collection"=true }
     * )
     * @Rest\Get("/api/admin/businesses/search", name="business_admin_search")
     * @Rest\QueryParam(
     *       name="domaine",
     *       nullable=true,
     *       description="Domaine d'expertise"
     * )
     * @Rest\QueryParam(
     *       name="metier",
     *       nullable=true,
     *       description="Métier"
     * )
     * @Rest\QueryParam(
     *       name="speciality",
     *       nullable=true,
     *       description="Specilaité"
     * )
     * @Rest\QueryParam(
     *       name="activity",
     *       nullable=true,
     *       description="Activité"
     * )
     * @Rest\QueryParam(
     *       name="ville",
     *       nullable=true,
     *       description="Ville"
     * )
     * @Rest\View
     */
    public function searchAction($domaine, $metier, $speciality, $activity , $ville)
    {
        $em = $this->getDoctrine()->getManager();

        

        $businesses = $em->getRepository('SadevBusinessModelBundle:Business')->getBusinessFilter(null, null, $domaine, $metier, $speciality, $activity, $ville);

        

        return $businesses;
    }



}