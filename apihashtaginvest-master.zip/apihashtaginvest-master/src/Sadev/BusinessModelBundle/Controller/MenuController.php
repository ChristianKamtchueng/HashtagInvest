<?php

namespace Sadev\BusinessModelBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sadev\BusinessModelBundle\Entity\Menu;
use Sadev\BusinessModelBundle\Form\MenuType;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\Request;
use FOS\RestBundle\Controller\Annotations as Rest;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Component\Security\Core\SecurityContext;
use FOS\RestBundle\Controller\Annotations\QueryParam;

use Nelmio\ApiDocBundle\Annotation as Doc;


class MenuController extends Controller
{
    
    /**
     * @Rest\Get("/api/admin/menus/{id}", name="menu_admin_show")
     * @Rest\View
     * @Doc\ApiDoc(
     *     section="Menu",
     *     description="Récuperation d'un menu",
     *     
     * )
     */
    public function showAction(Menu $menu)
    {

        /*
        récupération de l'entité grâce au 
        ParamConverter de Doctrine qui nous permet 
        d'aller chercher un objet en base de données.
        */
       
        return $menu;

    }

    /**
     * @DOC\ApiDoc(
     *    section="Menu",
     *    description="Création d'un menu",
     *    input={"class"=MenuType::class, "name"=""}
     * )
     *@Rest\Post("/api/admin/menus", name="menu_admin_create")
     *@Rest\View(StatusCode = 201)
     */
    public function createAction(Request $request)
    {

        $menu = new Menu;
        //$user->setCompany($company);

        /* 
        Bien que nous puissions créer ou mettre à jour une entité
        sans aucune validation, nous utiliserons néanmoins les formulaires de Symfony pour effectué cette validation.
        Dans le formType il faut obligatoirement désactiver la protection CSRF (Cross-Site Request Forgery). 
        Dans une API,  Nous n’utilisons pas de session et l’utilisateur de l’API peut appeler cette méthode sans se soucier de l’état de l’application : l’API doit rester sans état : stateless.
        */

        /* 
        En plus du système de validation l'autre avantage
        d'utiliser les formulaires est l'hydratation de l'entité avec 
        les données de la requette ce qui nous permet de gagner en productivité
        */

        $data = $request->request->all(); // recuperation des données qui sont automatiquement deserialiser par FosRest pour être traité par le formulaire.
        $form = $this->createForm(MenuType::class, $menu);

        //convertion du json reçu en objet comme le fait le paramConveter
        $form->submit($data);

        if ($form->isValid()) //validation des données avant la sauvegarde
        {

            $em = $this->getDoctrine()->getManager();

            // recuperation de l'auteur
            $authTokenHeader = $request->headers->get('X-Auth-Token');
            
            $token = $this->getDoctrine()->getManager()->getRepository('SadevUserBundle:AuthToken')->findOneByValue($authTokenHeader);
            if ($token !== null) { 
                $menu->setCreateBy($token->getUser());
            } 

            $em->persist($menu);
            $em->flush(); 
            return $menu;

        } else {

            return $form;

        }
        
        
    }

    /**
     *@DOC\ApiDoc(
     * section="Menu",
     * description="Modification totale d'un menu",
     * input={"class"=MenuType::class, "name"=""}
     *)
     *@Rest\Put("/api/admin/menus/{id}", name="menu_admin_update_total")
     *@Rest\View(StatusCode = 200)
     *@ParamConverter("menu")
     */
    public function updateAction(Menu $menu, Request $request)
    {

        return $this->update($menu, $request, true);

    }

    /**
     *@Rest\Patch("/api/admin/menus/{id}", name="menu_admin_update_partielle")
     *@DOC\ApiDoc(
     *    section="Menu",
     *    description="Modification partielle d'un menu",
     *    input={"class"=MenuType::class, "name"=""}
     *)
     *@Rest\View()
     */
    public function patchAction(Request $request)
    {
        
        $menu = $this->getDoctrine()->getManager()->getRepository('SadevBusinessModelBundle:Menu') ->find($request->get('id'));

        return $this->update($menu, $request, false);

    }

    private function update(Menu $menu, Request $request, $clearMissing)
    {
        // ici pas besoin de rechercher l'entite ou de le créer car il est recuperer automatique grâce à l'info contenu dans le paramConverter
        
        /* 
        Bien que nous puissions créer ou mettre à jour une entité
        sans aucune validation, nous utiliserons néanmoins les formulaires de Symfony pour effectué cette validation.
        Dans le formType il faut obligatoirement désactiver la protection CSRF (Cross-Site Request Forgery). 
        Dans une API,  Nous n’utilisons pas de session et l’utilisateur de l’API peut appeler cette méthode sans se soucier de l’état de l’application : l’API doit rester sans état : stateless.
        */

        /* 
        En plus du système de validation l'autre avantage
        d'utiliser les formulaires est l'hydratation de l'entité avec 
        les données de la requette ce qui nous permet de gagner en productivité
        */

        
        $data = $request->request->all(); // recuperation des données qui sont automatiquement deserialiser par FosRest pour être traité par le formulaire.
        $form = $this->createForm(MenuType::class, $menu);
        
        //convertion du json reçu en objet comme le fait le paramConveter
        //L’implémentation de la mise à jour partielle avec Symfony est très proche de la mise à jour complète. Il suffit de rajouter un paramètre dans la méthode submit (clearMissing = false) et le tour est joué. Comme son nom l’indique, avec clearMissing à false, Symfony conservera tous les attributs de l’entité  qui ne sont pas présents dans les paramètres de la requête
        $form->submit($data, $clearMissing);
        
        if ($form->isValid()) //validation des données avant la sauvegarde
        {
            $em = $this->getDoctrine()->getManager();
            $em->flush();
            return $menu;
        } else {
            return $form;
        }
        
    }

     /**
     * @Rest\Delete("/api/admin/menus/{id}", name="menu_admin_delete")
     * @DOC\ApiDoc(
     *    section="Menu",
     *    description="Supression d'un menu",
     * )
     * @Rest\View
     */
    public function deleteAction(Menu $menu)
    {

        /*
        récupération de l'entité grâce au 
        ParamConverter de Doctrine qui nous permet 
        d'aller chercher un objet en base de données.
        */
        $em = $this->getDoctrine()->getManager();
        $em->remove($menu);
        $em->flush();

    }


    /**
     * @Doc\ApiDoc(
     *    section="Menu",
     *    description="Récupération de la liste des menus",
     *    output= { "class"=Menu::class, "collection"=true }
     * )
     * @Rest\Get("/api/admin/menus", name="menu_admin_list")
     * @Rest\View
     */
    public function listAction()
    {

        $menus = $this->getDoctrine()->getManager()->getRepository('SadevBusinessModelBundle:Menu')->findAll();
        
        return $menus;

    }



}
