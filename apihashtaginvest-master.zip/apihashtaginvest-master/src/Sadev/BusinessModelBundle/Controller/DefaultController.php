<?php

namespace Sadev\BusinessModelBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use Sadev\BusinessModelBundle\Entity\Entite;
use Sadev\BusinessModelBundle\Entity\Poste;
use Sadev\BusinessModelBundle\Entity\Personnel;
use Sadev\BusinessModelBundle\Entity\DevisPayment;
use Sadev\BusinessModelBundle\Entity\SoubscriptionPayment;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\Request;
use FOS\RestBundle\Controller\Annotations as Rest;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Component\Security\Core\SecurityContext;
use FOS\RestBundle\Controller\Annotations\QueryParam;

use Nelmio\ApiDocBundle\Annotation as Doc;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;



class DefaultController extends Controller
{
   
    /**
     * @Rest\Get("/api/loaddata", name="load_data")
     * @Rest\View
    */
    public function loaddataAction()
    {
        //pour eviter l'Error: Maximum execution time of 60 seconds exceeded
        set_time_limit(1800);

        $string = file_get_contents("data/personnels.json");
        $json_a = json_decode($string, true);

        $a = array();
        foreach ($json_a as $elem) {

            /* $a[] = $elem['Matricule'];
            $a[] = $elem['Noms et prénoms'];
            $a[] = $elem['Fonction']; */
            
            $a[] = $elem['Direction'];

            // $a[] = $this->random_username($elem['Noms et prénoms']);




            /******************************************************************************
            $directions = explode('/', $elem['Direction']);

            $direction = null;
            foreach ($directions as $directelem){

                // on récupère la dernière direction crée pour affecter au personnelle
                $direction =  $this->createDirection($directelem);

            }

            $fonction = $this->createFunction($elem['Fonction'], $direction);


            $this->createPersonnel($elem['Noms et prénoms'], $elem['Matricule'], $fonction); 
            ******************************************************************************/



    
        }

        // return $json_a;
        return $a;

    }

    /**
     * @Rest\Post("/webhook/stripe", name="webhook_stripe  ")
     * @Rest\View
    */
    public function stripeWebHookAction(Request $request)
    {


        // Votre secret de signature Stripe
        // Set your secret key. Remember to switch to your live secret signature in production.
        /* $endpointSecret = "whsec_gBc85ttd9efIl8vRzmLIlV92OTV8Kl2f";
        $apiKey = 'sk_test_51SHnbR6sYrFzhqb3pA0NBJqyuQgvBpbMq4nOIzmcrd7yev5KUVXvU8gr3iwc7iSSZFqodWfW44hDsFT4ARitD69p00XjOZCUW5'; */

        $endpointSecret = $this->container->get('businessmodel.my_service')->getEndpointSecret('production');
        $apiKey = $this->container->get('businessmodel.my_service')->getApiKey('production');        


        // Récupération du payload brut
        $payload = $request->getContent();
        $sigHeader = $request->headers->get('stripe-signature');

        try {

            // on verifie avec la clé de production en premier

            \Stripe\Stripe::setApiKey($apiKey);

            // Vérification de la signature
            $event = \Stripe\Webhook::constructEvent(
                $payload,
                $sigHeader,
                $endpointSecret
            );

        } catch (\UnexpectedValueException $e) {
            // Payload invalide
            return new Response('Invalid payload', 400);

        } catch (\Stripe\Exception\SignatureVerificationException $e) {

            // on verifie avec la clé de test au cas où c'est un webhook de test
            try {

                $endpointSecret = $this->container->get('businessmodel.my_service')->getEndpointSecret('test');
                $apiKey = $this->container->get('businessmodel.my_service')->getApiKey('test');        

                \Stripe\Stripe::setApiKey($apiKey);

                // Vérification de la signature
                $event = \Stripe\Webhook::constructEvent(
                    $payload,
                    $sigHeader,
                    $endpointSecret
                );

            } catch (\UnexpectedValueException $e) {

                // Payload invalide
                return new Response('Invalid payload', 400);

            } catch (\Stripe\Exception\SignatureVerificationException $e) {

                // Signature invalide
                return new Response('Invalid signature', 400);

            }


        }

        // ---------------------
        // TRAITEMENT DES EVENTS
        // ---------------------

        switch ($event->type) {

            case 'checkout.session.completed':
                $session = $event->data->object;

                // Exemple : récupérer metadata
                $devisId = $session->metadata->devis_id;
                $amount = $session->amount_total;

                $soubscribe_formule = $session->metadata->soubscribe_formule ?? null;
                $soubscribe_period = $session->metadata->soubscribe_period ?? null;
                $userid = $session->metadata->userid ?? null;

                // Exemple : faire une mise à jour dans la base
                $em = $this->getDoctrine()->getManager();

                if($devisId != null){
                  $devis = $em->getRepository('SadevBusinessModelBundle:Devis')->find($devisId);
                  $devispayment = new DevisPayment();
                  $devispayment->setAmount($amount / 100); // montant en euros
                  $devispayment->setDevis($devis);
                  $devispayment->setMetadata(json_encode($session));
                  $em->persist($devispayment);
                  $em->flush();
                }

                if($soubscribe_formule != null && $soubscribe_period != null && $userid != null){
                    
                    $user = $this->getDoctrine()->getManager()->getRepository('SadevUserBundle:User') ->find($userid);

                    if($user != null) {

                        $soubscriptionpayment = new SoubscriptionPayment();
                        $soubscriptionpayment->setAmount($amount / 100); // montant en euros
                        $soubscriptionpayment->setFormule($soubscribe_formule);
                        $soubscriptionpayment->setPeriod($soubscribe_period);
                        $soubscriptionpayment->setMetadata(json_encode($session));
                        $soubscriptionpayment->setUser($user);

                        $em->persist($soubscriptionpayment); 
                    
                        // mise à jour des infos d'abonnement de l'utilisateur
                        if($user->getFormule() != $soubscribe_formule ) {

                            $user->setFormule($soubscribe_formule);
                            $now = new \DateTime();
                            if($soubscribe_period == 'monthly') { 
                                $now->modify('+1 month');
                            } elseif($soubscribe_period == 'yearly') {
                                $now->modify('+1 year');
                            }

                            $user->setDateExpiration($now);
                            
                        } else {

                            // si la formule est la même on prolonge la période
                            $currentDateExpiration = $user->getDateExpiration();
                            $now = new \DateTime();

                            if ($currentDateExpiration instanceof \DateTime) {
                                $expiration = clone $currentDateExpiration;
                            } else {
                                $expiration = new \DateTime($currentDateExpiration);
                            }

                            /* if($expiration > $now) {
                                $now = $expiration;
                            } */

                            // Si la date d'expiration actuelle est dans le futur, on part de là
                            if ($expiration->getTimestamp() > $now->getTimestamp()) {
                                $now = $expiration;
                            }

                            if($soubscribe_period == 'monthly') {
                                $now->modify('+1 month');
                            } elseif($soubscribe_period == 'yearly') {
                                $now->modify('+1 year');
                            }

                            $user->setDateExpiration($now);

                        }

                    }

                    $em->flush();
                  
                }
                
                
                // $devis->setPaid(true);

                break;

            case 'payment_intent.succeeded':
                $paymentIntent = $event->data->object;
                // Traitement supplémentaire si besoin
                break;

            case 'payment_intent.payment_failed':
                $paymentIntent = $event->data->object;
                // Log ou notification
                break;
        }


        return new Response('Webhook received', 200);
    
        /* 
        $em = $this->getDoctrine()->getManager();
        $devispayment = new DevisPayment();
        $devispayment->setAmount();
        $devispayment->setDevis();
        $devispayment->setMetadata();
        $em->persist($devispayment);
        $em->flush(); */

        // return $json_a;
        //return 4;

    }

    function random_username($string) {

        $username = $string;

        $string = $this->nameRewrite($string);


        $lastname = strtolower(substr($string, 0, 5));
        $nrRand = rand(0, 100);
        $username =  $lastname . $nrRand;
    
        /* $pattern = " ";
        $firstPart = strstr(strtolower($string), $pattern, true);
        $secondPart = substr(strstr(strtolower($string), $pattern, false), 0,3);
        $nrRand = rand(0, 100);
        
        $username = trim($firstPart).trim($secondPart).trim($nrRand); */


        // $username = str_replace(' ','',$string);

        // $username = mb_convert_case($string, MB_CASE_LOWER, "UTF-8");

        // $username = substr(str_replace(' ','', mb_convert_case($string, MB_CASE_LOWER, "UTF-8")), 0, 5).rand(1,3);

        return $username;

    }

    public function nameRewrite($string)
    {
        
		$accent = array('à', 'á', 'â', 'ã', 'ä', 'å', 'À', 'Á', 'Â', 'Ã', 'Ä', 'Å', 'ç', 'Ç', 'é', 'è', 'ê', 'ë', 'È', 'É', 'Ê', 'Ë', 'ì', 'í', 'î', 'ï', 'Ì', 'Í', 'Î', 'Ï', 'ò', 'ó', 'ô', 'õ', 'ö', 'Ò', 'Ó', 'Ô', 'Õ', 'Ö', 'ù', 'ú', 'û', 'ü', 'Ú', 'Ù', 'Û', 'Ü', 'Ý', 'ý', 'ÿ', 'ñ', '&#039;');
        $sans_accent = array('a', 'a', 'a', 'a', 'a', 'a', 'A', 'A', 'A', 'A', 'A', 'A', 'c', 'C', 'e', 'e', 'e', 'e', 'E', 'E', 'E', 'E', 'i', 'i', 'i', 'i', 'I', 'I', 'I', 'I', 'o', 'o', 'o', 'o', 'o', 'O', 'O', 'O', 'O', 'O', 'u', 'u', 'u', 'u', 'U', 'U', 'U', 'U', 'y', 'y', 'y', 'n', '-');      
		
        $string = str_replace($accent, $sans_accent, $string);
		$string = strtolower($string);
		
		$url = array();
	 
		for ($i = 0; $i < strlen($string); $i++) 
		array_push($url, $string[$i]);
		
		$url_aff = '';
		
		foreach($url as $string)
		{

			if(preg_match('#^[a-zA-Z0-9]$#', $string) != true)
			$string = str_replace($string, '-', $string);
			
            $url_aff .= $string;

		}
		
		return  $url_aff;
		
    }


    public function createPersonnel($name, $matricule, $poste)
    {
        
        $em = $this->getDoctrine()->getManager();
        $personnel = $em->getRepository('SadevBusinessModelBundle:Personnel') ->findOneByNom($name);

        if( $personnel === null ) {

            $personnel = new Personnel;
            $personnel->setNom($name);
            $personnel->setIsActive(false);

            $username = $this->random_username($name);
            while( $em->getRepository('SadevBusinessModelBundle:Personnel')->findOneByUsername($username) !== null ){
                //génération code couleur aleatoire
                $username = $this->random_username($name);
            }
            $personnel->setUsername($username);

            $personnel->setMatricule($matricule);
            $personnel->setPoste($poste);

            $personnel->setPlainPassword('cud2019');
            $encoder = $this->get('security.password_encoder');
            $encoded = $encoder->encodePassword($personnel, $personnel->getPlainPassword());
            $personnel->setPassword($encoded); 

            $em->persist($personnel);
            $em->flush();
    
        }

        return $personnel;

    }

    public function createDirection($directionname)
    {
        
        $em = $this->getDoctrine()->getManager();
        $entite = $em->getRepository('SadevBusinessModelBundle:Entite') ->findOneByDesignation($directionname);

        if( $entite === null ) {
            $entite = new Entite;
            $entite->setDesignation($directionname);

            $codeCouleur ='#' . str_pad(dechex(mt_rand(0, 0xFFFFFF)), 6, '0', STR_PAD_LEFT);
            while( $em->getRepository('SadevBusinessModelBundle:Entite')->findOneByCodeCouleur($codeCouleur) !== null ){
                //génération code couleur aleatoire
                $codeCouleur ='#' . str_pad(dechex(mt_rand(0, 0xFFFFFF)), 6, '0', STR_PAD_LEFT);
            }

            $entite->setCodeCouleur($codeCouleur);

            $em->persist($entite);
            $em->flush();
        }

        return $entite;

    }

    public function createFunction($functionname, $direction)
    {
    
        $poste = null;

        $em = $this->getDoctrine()->getManager();
        $postes = $em->getRepository('SadevBusinessModelBundle:Poste') ->findByDesignation($functionname);

        if( count($postes) == 0 ) {

            $poste = new Poste;
            $poste->setDesignation($functionname);
            $poste->setEntite($direction);

            $em->persist($poste);
            $em->flush();

        } else {

            // on recherche tous les postes qui ont la même qui la direction en paramètre
            $comptsearch = 0;
            foreach ($postes as $elem){

                if($elem->getEntite()->getId() == $direction->getId())
                {
                    $comptsearch++;
                    $poste = $elem;
                }

            }

            // si aucun poste n'est trouve alors le poste de la direction en question n'existe pas et on le crée
            if( $comptsearch == 0 ) {

                $poste = new Poste;
                $poste->setDesignation($functionname);
                $poste->setEntite($direction);
                $em->persist($poste);
                $em->flush();

            }

        }

        return $poste;

    }


}
