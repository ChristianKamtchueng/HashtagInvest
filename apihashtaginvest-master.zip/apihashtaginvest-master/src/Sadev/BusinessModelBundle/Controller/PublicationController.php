<?php

namespace Sadev\BusinessModelBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sadev\BusinessModelBundle\Entity\Publication;
use Sadev\BusinessModelBundle\Form\PublicationType;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\Request;
use FOS\RestBundle\Controller\Annotations as Rest;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Component\Security\Core\SecurityContext;
use FOS\RestBundle\Controller\Annotations\QueryParam;

use Nelmio\ApiDocBundle\Annotation as Doc;


class PublicationController extends Controller
{
    

    
    /**
     *@Rest\Patch("/api/admin/publication/{id}/setpublish", name="publication_setpublish_admin_update_partielle")
     *@DOC\ApiDoc(
     *    section="Publication",
     *    description="Modification publication",
     *    input={"class"=PublicationType::class, "name"=""}
     *)
     * @Rest\QueryParam(
    *     name="ispublish",
    *     nullable=true,
    *     description="Activer (ispublish=1) ou Désactiver (ispublish=0) la publication"
     * )
     *@Rest\View()
     */
    public function setpublishAction($ispublish, Request $request)
    {
        
        $em = $this->getDoctrine()->getManager();

        $publication = $em->getRepository('SadevBusinessModelBundle:Publication') ->find($request->get('id'));

        $publication->setIsPublish( $ispublish );
        
        $em->flush();
        return $publication;

    }

    /**
     * @Doc\ApiDoc(
     *    section="Publication",
     *    description="Récupération de la liste des publications",
     *    output= { "class"=Publication::class, "collection"=true }
     * )
     * @Rest\Get("/api/admin/publications", name="publication_admin_list")
     * @Rest\View
     */
    public function listAction()
    {
        $pubs = $this->getDoctrine()->getManager()->getRepository('SadevBusinessModelBundle:Publication')->findAll();
        
        return $pubs;
    }

    /**
     * @Doc\ApiDoc(
     *    section="Publication",
     *    description="Récupération d'une publication à parti du slug",
     *    output= { "class"=Publication::class, "collection"=true }
     * )
     * @Rest\Get("/api/admin/publication", name="publication_admin_recup")
     * @Rest\QueryParam(
     *     name="slug",
     *     nullable=true,
     *     description="slug la publication la publication"
     * )
     * @Rest\View
     */
    public function pubBySlugAction($slug)
    {
        $pub = $this->getDoctrine()->getManager()->getRepository('SadevBusinessModelBundle:Publication')->findBySlug($slug);
        if( count($pub) > 0 )
        return $pub[0];
        else
        return null;
    }

   



}
