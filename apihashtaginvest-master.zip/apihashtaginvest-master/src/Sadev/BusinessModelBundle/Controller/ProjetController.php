<?php

namespace Sadev\BusinessModelBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sadev\BusinessModelBundle\Entity\Project;
use Sadev\BusinessModelBundle\Form\ProjectType;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\Request;
use FOS\RestBundle\Controller\Annotations as Rest;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Component\Security\Core\SecurityContext;
use FOS\RestBundle\Controller\Annotations\QueryParam;

use Nelmio\ApiDocBundle\Annotation as Doc;


class ProjetController extends Controller
{
    
    /**
     * @Rest\Get("/api/admin/projets/{id}", name="projet_admin_show")
     * @Rest\View
     * @Doc\ApiDoc(
     *     section="Projet",
     *     description="Récuperation d'un projet",
     *     
     * )
     */
    public function showAction(Project $projet)
    {

        /*
        récupération de l'entité grâce au 
        ParamConverter de Doctrine qui nous permet 
        d'aller chercher un objet en base de données.
        */
       
        return $projet;

    }

    /**
     * @DOC\ApiDoc(
     *    section="Projet",
     *    description="Création d'un projet",
     *    input={"class"=ProjectType::class, "name"=""}
     * )
     *@Rest\Post("/api/admin/projets", name="projet_admin_create")
     *@Rest\View(StatusCode = 201)
     */
    public function createAction(Request $request)
    {

        $projet = new Project;
        //$user->setCompany($company);

        /* 
        Bien que nous puissions créer ou mettre à jour une entité
        sans aucune validation, nous utiliserons néanmoins les formulaires de Symfony pour effectué cette validation.
        Dans le formType il faut obligatoirement désactiver la protection CSRF (Cross-Site Request Forgery). 
        Dans une API,  Nous n’utilisons pas de session et l’utilisateur de l’API peut appeler cette méthode sans se soucier de l’état de l’application : l’API doit rester sans état : stateless.
        */

        /* 
        En plus du système de validation l'autre avantage
        d'utiliser les formulaires est l'hydratation de l'entité avec 
        les données de la requette ce qui nous permet de gagner en productivité
        */

        $data = $request->request->all(); // recuperation des données qui sont automatiquement deserialiser par FosRest pour être traité par le formulaire.
        $form = $this->createForm(ProjectType::class, $projet);

        //convertion du json reçu en objet comme le fait le paramConveter
        $form->submit($data);

        if ($form->isValid()) //validation des données avant la sauvegarde
        {

            $em = $this->getDoctrine()->getManager();

            // recuperation de l'auteur
            $authTokenHeader = $request->headers->get('X-Auth-Token');
            
            $token = $this->getDoctrine()->getManager()->getRepository('SadevUserBundle:AuthToken')->findOneByValue($authTokenHeader);
            if ($token !== null) { 
                $projet->setCreateBy($token->getUser());
            } 

            if($projet->photoSelected != null)
            $projet->setPhoto($projet->photoSelected);

            if($projet->imagesSelected != null) {

                $projet->setImages($projet->imagesSelected);

            }

            $em->persist($projet);
            $em->flush(); 
            return $projet;

        } else {

            return $form;

        }
        
        
    }

    /**
     *@DOC\ApiDoc(
     * section="Projet",
     * description="Modification totale d'un projet",
     * input={"class"=ProjectType::class, "name"=""}
     *)
     *@Rest\Put("/api/admin/projets/{id}", name="projet_admin_update_total")
     *@Rest\View(StatusCode = 200)
     *@ParamConverter("projet")
     */
    public function updateAction(Project $projet, Request $request)
    {

        return $this->update($projet, $request, true);

    }

    /**
     *@Rest\Patch("/api/admin/projets/{id}", name="projet_admin_update_partielle")
     *@DOC\ApiDoc(
     *    section="Projet",
     *    description="Modification partielle d'un projet",
     *    input={"class"=ProjectType::class, "name"=""}
     *)
     *@Rest\View()
     */
    public function patchAction(Request $request)
    {
        
        $projet = $this->getDoctrine()->getManager()->getRepository('SadevBusinessModelBundle:Project') ->find($request->get('id'));

        return $this->update($projet, $request, false);

    }

    private function update(Project $projet, Request $request, $clearMissing)
    {

        // ici pas besoin de rechercher l'entite ou de le créer car il est recuperer automatique grâce à l'info contenu dans le paramConverter
        
        /* 
        Bien que nous puissions créer ou mettre à jour une entité
        sans aucune validation, nous utiliserons néanmoins les formulaires de Symfony pour effectué cette validation.
        Dans le formType il faut obligatoirement désactiver la protection CSRF (Cross-Site Request Forgery). 
        Dans une API,  Nous n’utilisons pas de session et l’utilisateur de l’API peut appeler cette méthode sans se soucier de l’état de l’application : l’API doit rester sans état : stateless.
        */

        /* 
        En plus du système de validation l'autre avantage
        d'utiliser les formulaires est l'hydratation de l'entité avec 
        les données de la requette ce qui nous permet de gagner en productivité
        */
        
        $data = $request->request->all(); // recuperation des données qui sont automatiquement deserialiser par FosRest pour être traité par le formulaire.
        $form = $this->createForm(ProjectType::class, $projet);
        
        //convertion du json reçu en objet comme le fait le paramConveter
        //L’implémentation de la mise à jour partielle avec Symfony est très proche de la mise à jour complète. Il suffit de rajouter un paramètre dans la méthode submit (clearMissing = false) et le tour est joué. Comme son nom l’indique, avec clearMissing à false, Symfony conservera tous les attributs de l’entité  qui ne sont pas présents dans les paramètres de la requête
        $form->submit($data, $clearMissing);
        
        if ($form->isValid()) //validation des données avant la sauvegarde
        {

            $em = $this->getDoctrine()->getManager();

            if($projet->photoSelected != null)
            $projet->setPhoto($projet->photoSelected);

            if($projet->imagesSelected != null){

                // $projet->setImages([]);
                $projet->setImages($projet->imagesSelected);

            }

            $em->flush();
            return $projet;


        } else {

            return $form;

        }
        
    }

     /**
     * @Rest\Delete("/api/admin/projets/{id}", name="projet_admin_delete")
     * @DOC\ApiDoc(
     *    section="Projet",
     *    description="Supression d'un projet",
     * )
     * @Rest\View
     */
    public function deleteAction(Project $projet)
    {

        /*
        récupération de l'entité grâce au 
        ParamConverter de Doctrine qui nous permet 
        d'aller chercher un objet en base de données.
        */
        $em = $this->getDoctrine()->getManager();
        $em->remove($projet);
        $em->flush();

    }


    /**
     * @Doc\ApiDoc(
     *    section="Projet",
     *    description="Récupération de la liste des projets",
     *    output= { "class"=Project::class, "collection"=true }
     * )
     * @Rest\Get("/api/admin/projets", name="projet_admin_list")
     * @Rest\View
     */
    public function listAction()
    {
        $projets = $this->getDoctrine()->getManager()->getRepository('SadevBusinessModelBundle:Project')->findAll();
        
        return $projets;
    }


    /**
     * @Doc\ApiDoc(
     *    section="Projet",
     *    description="Récupération des categories contenant au moins un projet",
     *    output= { "class"=Project::class, "collection"=true }
     * )
     * @Rest\Get("/api/admin/categoriesprojets", name="categoriesprojets_admin_list")
     * @Rest\View
     */
    public function listcatAction()
    {
        $projets = $this->getDoctrine()->getManager()->getRepository('SadevBusinessModelBundle:Project')->findAll();

        $cats = array();

        foreach($projets as $elem) {

            foreach($elem->getCategories() as $catelem) {
                
                if (!in_array($catelem, $cats))
                $cats[] =  $catelem;

            }
            
        }
        
        return $cats;
    }



}
