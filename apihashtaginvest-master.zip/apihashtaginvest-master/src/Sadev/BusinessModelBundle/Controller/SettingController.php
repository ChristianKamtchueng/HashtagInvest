<?php

namespace Sadev\BusinessModelBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

// importation entités et formtype
use Sadev\BusinessModelBundle\Entity\GeneralSetting;
use Sadev\BusinessModelBundle\Form\GeneralSettingType;
use Sadev\BusinessModelBundle\Entity\NetworkSetting;
use Sadev\BusinessModelBundle\Form\NetworkSettingType;
use Sadev\BusinessModelBundle\Entity\PageSetting;
use Sadev\BusinessModelBundle\Form\PageSettingType;
use Sadev\BusinessModelBundle\Entity\StatSetting;
use Sadev\BusinessModelBundle\Form\StatSettingType;
use Sadev\BusinessModelBundle\Entity\MenuSetting;
use Sadev\BusinessModelBundle\Form\MenuSettingType;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\Request;
use FOS\RestBundle\Controller\Annotations as Rest;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Component\Security\Core\SecurityContext;
use FOS\RestBundle\Controller\Annotations\QueryParam;


use Nelmio\ApiDocBundle\Annotation as Doc;


class SettingController extends Controller
{
    
    /**
     * @DOC\ApiDoc(
     *    section="Paramètres",
     *    description="Généraux",
     *    input={"class"=GeneralSettingType::class, "name"=""}
     * )
     *@Rest\Patch("/api/settings/general", name="setting_general_update")
     *@Rest\View(StatusCode = 201)
     */
    public function updategeneralAction(Request $request)
    {
        
        $setting = new GeneralSetting;
        
        $setting = $setting->hydrate();

        //$user->setCompany($company);

        /* 
        Bien que nous puissions créer ou mettre à jour une entité
        sans aucune validation, nous utiliserons néanmoins les formulaires de Symfony pour effectué cette validation.
        Dans le formType il faut obligatoirement désactiver la protection CSRF (Cross-Site Request Forgery). 
        Dans une API,  Nous n’utilisons pas de session et l’utilisateur de l’API peut appeler cette méthode sans se soucier de l’état de l’application : l’API doit rester sans état : stateless.
        */

        /* 
        En plus du système de validation l'autre avantage
        d'utiliser les formulaires est l'hydratation de l'entité avec 
        les données de la requette ce qui nous permet de gagner en productivité
        */

        $data = $request->request->all(); // recuperation des données qui sont automatiquement deserialiser par FosRest pour être traité par le formulaire.
        $form = $this->createForm(GeneralSettingType::class, $setting);

        //convertion du json reçu en objet comme le fait le paramConveter
        //L’implémentation de la mise à jour partielle avec Symfony est très proche de la mise à jour complète. Il suffit de rajouter un paramètre dans la méthode submit (clearMissing = false) et le tour est joué. Comme son nom l’indique, avec clearMissing à false, Symfony conservera tous les attributs de l’entité  qui ne sont pas présents dans les paramètres de la requête
        $clearMissing = false;
        $form->submit($data, $clearMissing); 
        
        if ($form->isValid()) //validation des données avant la sauvegarde
        {
            
            $setting->save();
            return $setting;

        } else {
            return $form;
        }
        
        
    }

    /**
     * @Doc\ApiDoc(
     *    section="Paramètres",
     *    description="Généraux",
     *    output= { "class"=GeneralSetting::class, "collection"=false }
     * )
     * @Rest\Get("/api/settings/general", name="setting_general_list")
     * @Rest\View
     */
    public function generalAction()
    {
        $setting = new GeneralSetting;
        
        return $setting->hydrate();

        //return $this->config();
    }


    /**
     * @DOC\ApiDoc(
     *    section="Paramètres",
     *    description="Réseaux sociaux",
     *    input={"class"=NetworkSettingType::class, "name"=""}
     * )
     *@Rest\Patch("/api/settings/network", name="setting_network_update")
     *@Rest\View(StatusCode = 201)
     */
    public function updatenetworkAction(Request $request)
    {
        
        $setting = new NetworkSetting;
        
        $setting = $setting->hydrate();

        //$user->setCompany($company);

        /* 
        Bien que nous puissions créer ou mettre à jour une entité
        sans aucune validation, nous utiliserons néanmoins les formulaires de Symfony pour effectué cette validation.
        Dans le formType il faut obligatoirement désactiver la protection CSRF (Cross-Site Request Forgery). 
        Dans une API,  Nous n’utilisons pas de session et l’utilisateur de l’API peut appeler cette méthode sans se soucier de l’état de l’application : l’API doit rester sans état : stateless.
        */

        /* 
        En plus du système de validation l'autre avantage
        d'utiliser les formulaires est l'hydratation de l'entité avec 
        les données de la requette ce qui nous permet de gagner en productivité
        */

        $data = $request->request->all(); // recuperation des données qui sont automatiquement deserialiser par FosRest pour être traité par le formulaire.
        $form = $this->createForm(NetworkSettingType::class, $setting);

        //convertion du json reçu en objet comme le fait le paramConveter
        //L’implémentation de la mise à jour partielle avec Symfony est très proche de la mise à jour complète. Il suffit de rajouter un paramètre dans la méthode submit (clearMissing = false) et le tour est joué. Comme son nom l’indique, avec clearMissing à false, Symfony conservera tous les attributs de l’entité  qui ne sont pas présents dans les paramètres de la requête
        $clearMissing = false;
        $form->submit($data, $clearMissing); 
        
        if ($form->isValid()) //validation des données avant la sauvegarde
        {
            
            $setting->save();
            return $setting;

        } else {
            return $form;
        }
        
        
    }

    /**
     * @Doc\ApiDoc(
     *    section="Paramètres",
     *    description="Réseaux sociaux",
     *    output= { "class"=NetworkSetting::class, "collection"=false }
     * )
     * @Rest\Get("/api/settings/network", name="setting_network_list")
     * @Rest\View
     */
    public function networkAction()
    {
        $setting = new NetworkSetting;
        
        return $setting->hydrate();

        //return $this->config();
    }

    /**
     * @DOC\ApiDoc(
     *    section="Paramètres",
     *    description="Pages",
     *    input={"class"=PageSettingType::class, "name"=""}
     * )
     *@Rest\Patch("/api/settings/page", name="setting_page_update")
     *@Rest\View(StatusCode = 201)
     */
    public function updatepageAction(Request $request)
    {
        
        $setting = new PageSetting;
        
        $setting = $setting->hydrate();

        //$user->setCompany($company);

        /* 
        Bien que nous puissions créer ou mettre à jour une entité
        sans aucune validation, nous utiliserons néanmoins les formulaires de Symfony pour effectué cette validation.
        Dans le formType il faut obligatoirement désactiver la protection CSRF (Cross-Site Request Forgery). 
        Dans une API,  Nous n’utilisons pas de session et l’utilisateur de l’API peut appeler cette méthode sans se soucier de l’état de l’application : l’API doit rester sans état : stateless.
        */

        /* 
        En plus du système de validation l'autre avantage
        d'utiliser les formulaires est l'hydratation de l'entité avec 
        les données de la requette ce qui nous permet de gagner en productivité
        */

        $data = $request->request->all(); // recuperation des données qui sont automatiquement deserialiser par FosRest pour être traité par le formulaire.
        $form = $this->createForm(PageSettingType::class, $setting);

        //convertion du json reçu en objet comme le fait le paramConveter
        //L’implémentation de la mise à jour partielle avec Symfony est très proche de la mise à jour complète. Il suffit de rajouter un paramètre dans la méthode submit (clearMissing = false) et le tour est joué. Comme son nom l’indique, avec clearMissing à false, Symfony conservera tous les attributs de l’entité  qui ne sont pas présents dans les paramètres de la requête
        $clearMissing = false;
        $form->submit($data, $clearMissing); 
        
        if ($form->isValid()) //validation des données avant la sauvegarde
        {
            
            $setting->save();
            return $setting;

        } else {
            return $form;
        }
        
        
    }

    /**
     * @Doc\ApiDoc(
     *    section="Paramètres",
     *    description="Pages",
     *    output= { "class"=PageSetting::class, "collection"=false }
     * )
     * @Rest\Get("/api/settings/page", name="setting_page_list")
     * @Rest\View
     */
    public function pageAction()
    {
        $setting = new PageSetting;
        
        $pagesettting = $setting->hydrate();

        $em = $this->getDoctrine()->getManager();

        try{

            $pagesettting->setActionnariat( $em->getRepository('SadevBusinessModelBundle:Page')->find($pagesettting->getActionnariat()) );

        }catch(\Exception $e){
		

        }

        try{

            $pagesettting->setApropos( $em->getRepository('SadevBusinessModelBundle:Page')->find($pagesettting->getApropos()) );
        
        }catch(\Exception $e){
		

        }
        
        try{

            $pagesettting->setVision( $em->getRepository('SadevBusinessModelBundle:Page')->find($pagesettting->getVision()) );
        
        }catch(\Exception $e){
		

        }
        
        try{

            $pagesettting->setMission( $em->getRepository('SadevBusinessModelBundle:Page')->find($pagesettting->getMission()) );

        }catch(\Exception $e){
		

        }
        
        try{

            $pagesettting->setProgramme( $em->getRepository('SadevBusinessModelBundle:Page')->find($pagesettting->getProgramme()) );
        
        }catch(\Exception $e){
		

        }
        
        try{

            $pagesettting->setEgibilite( $em->getRepository('SadevBusinessModelBundle:Page')->find($pagesettting->getEgibilite()) );
        
        }catch(\Exception $e){
		

        }
        
        try{

            $pagesettting->setSouscription( $em->getRepository('SadevBusinessModelBundle:Page')->find($pagesettting->getSouscription()) );
        
        }catch(\Exception $e){
		

        }
        
        try{

            $pagesettting->setReclamation( $em->getRepository('SadevBusinessModelBundle:Page')->find($pagesettting->getReclamation()) );
        
        }catch(\Exception $e){
		

        }
        
        try{

            $pagesettting->setPromotion( $em->getRepository('SadevBusinessModelBundle:Page')->find($pagesettting->getPromotion()) );
        
        }catch(\Exception $e){
		

        }
        
        try{

            $pagesettting->setEconomie( $em->getRepository('SadevBusinessModelBundle:Page')->find($pagesettting->getEconomie()) );
        
        }catch(\Exception $e){
		

        }
        

        try{

            $pagesettting->setOrganisation( $em->getRepository('SadevBusinessModelBundle:Page')->find($pagesettting->getOrganisation()) );
        
        }catch(\Exception $e){
		

        }
        
        try{

            $pagesettting->setCreation( $em->getRepository('SadevBusinessModelBundle:Page')->find($pagesettting->getCreation()) );
        
        }catch(\Exception $e){
		

		}
        

        return $pagesettting;

        // return $setting->getActionnariat();

        //return $this->config();
    }



    /**
     * @DOC\ApiDoc(
     *    section="Paramètres",
     *    description="Stattistiques",
     *    input={"class"=StatSettingType::class, "name"=""}
     * )
     *@Rest\Patch("/api/settings/stat", name="setting_stat_update")
     *@Rest\View(StatusCode = 201)
     */
    public function updatestatAction(Request $request)
    {
        
        $setting = new StatSetting;
        
        $setting = $setting->hydrate();

        //$user->setCompany($company);

        /* 
        Bien que nous puissions créer ou mettre à jour une entité
        sans aucune validation, nous utiliserons néanmoins les formulaires de Symfony pour effectué cette validation.
        Dans le formType il faut obligatoirement désactiver la protection CSRF (Cross-Site Request Forgery). 
        Dans une API,  Nous n’utilisons pas de session et l’utilisateur de l’API peut appeler cette méthode sans se soucier de l’état de l’application : l’API doit rester sans état : stateless.
        */

        /* 
        En plus du système de validation l'autre avantage
        d'utiliser les formulaires est l'hydratation de l'entité avec 
        les données de la requette ce qui nous permet de gagner en productivité
        */

        $data = $request->request->all(); // recuperation des données qui sont automatiquement deserialiser par FosRest pour être traité par le formulaire.
        $form = $this->createForm(StatSettingType::class, $setting);

        //convertion du json reçu en objet comme le fait le paramConveter
        //L’implémentation de la mise à jour partielle avec Symfony est très proche de la mise à jour complète. Il suffit de rajouter un paramètre dans la méthode submit (clearMissing = false) et le tour est joué. Comme son nom l’indique, avec clearMissing à false, Symfony conservera tous les attributs de l’entité  qui ne sont pas présents dans les paramètres de la requête
        $clearMissing = false;
        $form->submit($data, $clearMissing); 
        
        if ($form->isValid()) //validation des données avant la sauvegarde
        {
            
            $setting->save();
            return $setting;

        } else {
            return $form;
        }
        
        
    }

    /**
     * @Doc\ApiDoc(
     *    section="Paramètres",
     *    description="Statistiques",
     *    output= { "class"=StatSetting::class, "collection"=false }
     * )
     * @Rest\Get("/api/settings/stat", name="setting_stat_list")
     * @Rest\View
     */
    public function statAction()
    {
        
        $setting = new StatSetting;
        
        return $setting->hydrate();

        //return $this->config();
    }


    /**
     * @DOC\ApiDoc(
     *    section="Paramètres",
     *    description="Menu",
     *    input={"class"= MenuSettingType::class, "name"=""}
     * )
     *@Rest\Patch("/api/settings/menu", name="setting_menu_update")
     *@Rest\View(StatusCode = 201)
     */
    public function updatemenuAction(Request $request)
    {
        
        $setting = new MenuSetting;
        
        $setting = $setting->hydrate();

        //$user->setCompany($company);

        /* 
        Bien que nous puissions créer ou mettre à jour une entité
        sans aucune validation, nous utiliserons néanmoins les formulaires de Symfony pour effectué cette validation.
        Dans le formType il faut obligatoirement désactiver la protection CSRF (Cross-Site Request Forgery). 
        Dans une API,  Nous n’utilisons pas de session et l’utilisateur de l’API peut appeler cette méthode sans se soucier de l’état de l’application : l’API doit rester sans état : stateless.
        */

        /* 
        En plus du système de validation l'autre avantage
        d'utiliser les formulaires est l'hydratation de l'entité avec 
        les données de la requette ce qui nous permet de gagner en productivité
        */

        $data = $request->request->all(); // recuperation des données qui sont automatiquement deserialiser par FosRest pour être traité par le formulaire.
        $form = $this->createForm(MenuSettingType::class, $setting);

        //convertion du json reçu en objet comme le fait le paramConveter
        //L’implémentation de la mise à jour partielle avec Symfony est très proche de la mise à jour complète. Il suffit de rajouter un paramètre dans la méthode submit (clearMissing = false) et le tour est joué. Comme son nom l’indique, avec clearMissing à false, Symfony conservera tous les attributs de l’entité  qui ne sont pas présents dans les paramètres de la requête
        $clearMissing = false;
        $form->submit($data, $clearMissing); 
        
        if ($form->isValid()) //validation des données avant la sauvegarde
        {
            
            $setting->save();
            return $setting;

        } else {
            return $form;
        }
        
        
    }

    /**
     * @Doc\ApiDoc(
     *    section="Paramètres",
     *    description="Menus",
     *    output= { "class"= MenuSetting::class, "collection"=false }
     * )
     * @Rest\Get("/api/settings/menu", name="setting_menu_list")
     * @Rest\View
     */
    public function menuAction()
    {
        $setting = new MenuSetting;

        $menusettting = $setting->hydrate();

        $em = $this->getDoctrine()->getManager();

        try{

            $menusettting->setMain( $em->getRepository('SadevBusinessModelBundle:Menu')->find($menusettting->getMain()) );
        
        }catch(\Exception $e){
		

        }
        
        try{

            $menusettting->setFooter1( $em->getRepository('SadevBusinessModelBundle:Menu')->find($menusettting->getFooter1()) );
        
        }catch(\Exception $e){
		

        }
        
        try{

            $menusettting->setFooter2( $em->getRepository('SadevBusinessModelBundle:Menu')->find($menusettting->getFooter2()) );
        
        }catch(\Exception $e){
		

        }
        
        try{

            $menusettting->setFooter3( $em->getRepository('SadevBusinessModelBundle:Menu')->find($menusettting->getFooter3()) );
        
        }catch(\Exception $e){
		

        }
        
        try{

            $menusettting->setArchive( $em->getRepository('SadevBusinessModelBundle:Menu')->find($menusettting->getArchive()) );
        
        }catch(\Exception $e){
		

		}
        
        return $menusettting;
        
        // return $setting->hydrate();

        //return $this->config();
    }


   /*  public function config()
    {
          
        $setting = new Setting;
        
        if ( file_exists($setting->file())) {
            
            $store = file_get_contents($setting->file());
            $setting = unserialize($store);
        }
        
        return $setting;
        
    } */



}
