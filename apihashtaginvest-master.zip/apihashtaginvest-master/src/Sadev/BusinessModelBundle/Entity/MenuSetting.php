<?php

namespace Sadev\BusinessModelBundle\Entity;

class MenuSetting
{
   
    private $main;

    
    private $footer1;

    
    private $footer2;

    
    private $footer3;


    private $archive;


    
    public function setMain($main)
    {
        $this->main = $main;

        return $this;
    }

    public function getMain()
    {
        return $this->main;
    }

    
    public function setFooter1($footer1)
    {
        $this->footer1 = $footer1;

        return $this;
    }

   
    public function getFooter1()
    {
        return $this->footer1;
    }

    
    public function setFooter2($footer2)
    {
        $this->footer2 = $footer2;

        return $this;
    }

    public function getFooter2()
    {
        return $this->footer2;
    }

    public function setFooter3($footer3)
    {
        $this->footer3 = $footer3;

        return $this;
    }

    public function getFooter3()
    {
        return $this->footer3;
    }

    public function setArchive($archive)
    {
        $this->archive = $archive;
        return $this;
    }

    public function getArchive()
    {
        return $this->archive;
    }

    public function file()
    {
        $dir ='settings';
        if(!is_dir($dir)) {
            mkdir($dir); // si le dossier setting n'existe pas on le créer
            chmod($dir, 0777);
        }

        $file = $dir.='/menu.txt';
    
       /* if(!is_file($file)) {
            $fp = fopen($file, 'w');
            fwrite($fp, '');
            fclose($fp);
            chmod($file, 0777);
        } */

        return $file;

    }

    public function save()
    {
		$store = serialize ($this);
		file_put_contents($this->file(), $store, true);
    }

    public function hydrate()
    {

        $setting = new MenuSetting;

        if ( file_exists($this->file())) {
            
            $store = file_get_contents($this->file());
            $setting = unserialize($store);
        }

        return  $setting;

    }
}

