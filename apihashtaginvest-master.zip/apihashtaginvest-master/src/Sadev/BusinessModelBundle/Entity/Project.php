<?php

namespace Sadev\BusinessModelBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use JMS\Serializer\Annotation as Serializer;
use JMS\Serializer\Annotation\VirtualProperty;

/**
 * Project
 *
 * @ORM\Table(name="project")
 * @ORM\Entity(repositoryClass="Sadev\BusinessModelBundle\Repository\ProjectRepository")
 * @Serializer\ExclusionPolicy("ALL")
 */
class Project extends Publication
{

    /**
     * @var array
     * @Serializer\Expose
     * @ORM\Column(name="images", type="array", nullable=true)
     */
    private $images;


    public $imagesSelected;


    /**
    * @ORM\ManyToMany(targetEntity="Sadev\BusinessModelBundle\Entity\Categorie",  cascade={"persist"})
    * @Serializer\Expose
	*/
	private $categories;

    /**
     * Set images
     *
     * @param array $images
     *
     * @return Project
     */
    public function setImages($images)
    {

        $medias = array();

        $this->images = null;
    
        foreach($images as $elem){

            $media = array();
            if($elem !== null) {
                $media['baseUrl'] = $elem->getBaseUrl();
                $media['hash'] = $elem->getHash();
                $media['mime'] = $elem->getMime();
                $media['name'] = $elem->getName();
                $media['path'] = $elem->getPath();
                $media['phash'] = $elem->getPhash();
                $media['size'] = $elem->getSize();
                $media['tmb'] = $elem->getTmb();
                $media['ts'] = $elem->getTs();
                $media['url'] = $elem->getUrl();
                $media['height'] = $elem->getHeight();
                $media['width'] = $elem->getWidth();
                $medias[] = $media;
            }
           
        }
        
        $this->images = $medias;

        return $this;
    }

    /**
     * Get images
     *
     * @return array
     */
    public function getImages()
    {
        return $this->images;
    }

    /**
     * Add category
     *
     * @param \Sadev\BusinessModelBundle\Entity\Categorie $category
     *
     * @return Project
     */
    public function addCategory(\Sadev\BusinessModelBundle\Entity\Categorie $category)
    {
        $this->categories[] = $category;

        return $this;
    }

    /**
     * Remove category
     *
     * @param \Sadev\BusinessModelBundle\Entity\Categorie $category
     */
    public function removeCategory(\Sadev\BusinessModelBundle\Entity\Categorie $category)
    {
        $this->categories->removeElement($category);
    }

    /**
     * Get categories
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getCategories()
    {
        return $this->categories;
    }
}
