<?php

namespace Sadev\BusinessModelBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use JMS\Serializer\Annotation\Type;

/**
 * FamilySouscription
 *
 * @ORM\Table(name="family_souscription")
 * @ORM\Entity(repositoryClass="Sadev\BusinessModelBundle\Repository\FamilySouscriptionRepository")
 */
class FamilySouscription extends Souscription
{
    
    /**
     * @var string
     *
     * @ORM\Column(name="familyName", type="string", length=255)
     */
    private $familyName;

    /**
     * @var string
     *
     * @ORM\Column(name="nameRep", type="string", length=255)
     */
    private $nameRep;

    /**
     * @var \DateTime
     *
     * @Assert\GreaterThanOrEqual("-120 years")
     * @ORM\Column(name="birthdayRep", type="datetime")
     * @Type("DateTime<'Y-m-d'>")
     */
    private $birthdayRep;

    /**
     * @var string
     *
     * @ORM\Column(name="birthplaceRep", type="string", length=255)
     */
    private $birthplaceRep;

    /**
     * @var string
     *
     * @ORM\Column(name="sexeRep", type="string", length=255)
     */
    private $sexeRep;

    /**
     * @var string
     *
     * @ORM\Column(name="nationalityRep", type="string", length=255)
     */
    private $nationalityRep;

    /**
     * @var string
     *
     * @ORM\Column(name="professionRep", type="string", length=255)
     */
    private $professionRep;

    /**
     * @var string
     *
     * @ORM\Column(name="residenceRep", type="string", length=255)
     */
    private $residenceRep;

    /**
     * @var string
     *
     * @ORM\Column(name="idCniOrPassRep", type="string", length=255)
     */
    private $idCniOrPassRep;

    /**
     * @var string
     *
     * @ORM\Column(name="numGrosseRep", type="string", length=255, nullable=true, unique=true)
     */
    private $numGrosseRep;

    /**
     * @var string
     *
     * @ORM\Column(name="bpRep", type="string", length=255, nullable=true)
     */
    private $bpRep;

    /**
     * @var string
     *
     * @ORM\Column(name="gsmRep", type="string", length=255, nullable=true)
     */
    private $gsmRep;

    /**
     * @var string
     *
     * @ORM\Column(name="emailRep", type="string", length=255, nullable=true, unique=true)
     */
    private $emailRep;


    /**
     * Constructor
     */
    public function __construct()
    {
		parent::__construct();
        $this->setTypeSouscription('family');
    }


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set familyName
     *
     * @param string $familyName
     *
     * @return FamilySouscription
     */
    public function setFamilyName($familyName)
    {
        $this->familyName = $familyName;

        return $this;
    }

    /**
     * Get familyName
     *
     * @return string
     */
    public function getFamilyName()
    {
        return $this->familyName;
    }

    /**
     * Set nameRep
     *
     * @param string $nameRep
     *
     * @return FamilySouscription
     */
    public function setNameRep($nameRep)
    {
        $this->nameRep = $nameRep;

        return $this;
    }

    /**
     * Get nameRep
     *
     * @return string
     */
    public function getNameRep()
    {
        return $this->nameRep;
    }

    /**
     * Set birthdayRep
     *
     * @param \DateTime $birthdayRep
     *
     * @return FamilySouscription
     */
    public function setBirthdayRep($birthdayRep)
    {
        $this->birthdayRep = $birthdayRep;

        return $this;
    }

    /**
     * Get birthdayRep
     *
     * @return \DateTime
     */
    public function getBirthdayRep()
    {
        return $this->birthdayRep;
    }

    /**
     * Set birthplaceRep
     *
     * @param string $birthplaceRep
     *
     * @return FamilySouscription
     */
    public function setBirthplaceRep($birthplaceRep)
    {
        $this->birthplaceRep = $birthplaceRep;

        return $this;
    }

    /**
     * Get birthplaceRep
     *
     * @return string
     */
    public function getBirthplaceRep()
    {
        return $this->birthplaceRep;
    }

    /**
     * Set sexeRep
     *
     * @param string $sexeRep
     *
     * @return FamilySouscription
     */
    public function setSexeRep($sexeRep)
    {
        if(in_array($sexeRep, ['homme', 'femme']))
        $this->sexeRep = $sexeRep;

        return $this;
    }

    /**
     * Get sexeRep
     *
     * @return string
     */
    public function getSexeRep()
    {
        return $this->sexeRep;
    }

    /**
     * Set nationalityRep
     *
     * @param string $nationalityRep
     *
     * @return FamilySouscription
     */
    public function setNationalityRep($nationalityRep)
    {
        $this->nationalityRep = $nationalityRep;

        return $this;
    }

    /**
     * Get nationalityRep
     *
     * @return string
     */
    public function getNationalityRep()
    {
        return $this->nationalityRep;
    }

    /**
     * Set residenceRep
     *
     * @param string $residenceRep
     *
     * @return FamilySouscription
     */
    public function setResidenceRep($residenceRep)
    {
        $this->residenceRep = $residenceRep;

        return $this;
    }

    /**
     * Get residenceRep
     *
     * @return string
     */
    public function getResidenceRep()
    {
        return $this->residenceRep;
    }

    /**
     * Set idCniOrPassRep
     *
     * @param string $idCniOrPassRep
     *
     * @return FamilySouscription
     */
    public function setIdCniOrPassRep($idCniOrPassRep)
    {
        $this->idCniOrPassRep = $idCniOrPassRep;

        return $this;
    }

    /**
     * Get idCniOrPassRep
     *
     * @return string
     */
    public function getIdCniOrPassRep()
    {
        return $this->idCniOrPassRep;
    }

    /**
     * Set numGrosseRep
     *
     * @param string $numGrosseRep
     *
     * @return FamilySouscription
     */
    public function setNumGrosseRep($numGrosseRep)
    {
        $this->numGrosseRep = $numGrosseRep;

        return $this;
    }

    /**
     * Get numGrosseRep
     *
     * @return string
     */
    public function getNumGrosseRep()
    {
        return $this->numGrosseRep;
    }

    /**
     * Set bpRep
     *
     * @param string $bpRep
     *
     * @return FamilySouscription
     */
    public function setBpRep($bpRep)
    {
        $this->bpRep = $bpRep;

        return $this;
    }

    /**
     * Get bpRep
     *
     * @return string
     */
    public function getBpRep()
    {
        return $this->bpRep;
    }

    /**
     * Set gsmRep
     *
     * @param string $gsmRep
     *
     * @return FamilySouscription
     */
    public function setGsmRep($gsmRep)
    {
        $this->gsmRep = $gsmRep;

        return $this;
    }

    /**
     * Get gsmRep
     *
     * @return string
     */
    public function getGsmRep()
    {
        return $this->gsmRep;
    }

    /**
     * Set emailRep
     *
     * @param string $emailRep
     *
     * @return FamilySouscription
     */
    public function setEmailRep($emailRep)
    {
        $this->emailRep = $emailRep;

        return $this;
    }

    /**
     * Get emailRep
     *
     * @return string
     */
    public function getEmailRep()
    {
        return $this->emailRep;
    }

    /**
     * Set professionRep
     *
     * @param string $professionRep
     *
     * @return FamilySouscription
     */
    public function setProfessionRep($professionRep)
    {
        $this->professionRep = $professionRep;

        return $this;
    }

    /**
     * Get professionRep
     *
     * @return string
     */
    public function getProfessionRep()
    {
        return $this->professionRep;
    }
}
