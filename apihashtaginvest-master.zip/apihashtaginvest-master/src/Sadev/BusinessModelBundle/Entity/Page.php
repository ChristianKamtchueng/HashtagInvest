<?php

namespace Sadev\BusinessModelBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use JMS\Serializer\Annotation as Serializer;
use JMS\Serializer\Annotation\VirtualProperty;
use JMS\Serializer\Annotation\SerializedName;
use JMS\Serializer\Annotation\Type;
use Sadev\BusinessModelBundle\Entity\PageStruct;


/**
 * Page
 *
 * @ORM\Table(name="page")
 * @ORM\Entity(repositoryClass="Sadev\BusinessModelBundle\Repository\PageRepository")
 * @Serializer\ExclusionPolicy("ALL")
 */
class Page extends Publication
{
    /**
     * @var array
     * @Serializer\Expose
     * @ORM\Column(name="fichier", type="array", nullable=true)
     */
    private $fichier;

     /**
     * @var string
     * @Serializer\Expose
     * @ORM\Column(name="videoYoutube", type="string", length=255, nullable=true)
     */
    private $videoYoutube;


    public $fichierSelected;

    /**
	* @ORM\ManyToOne(targetEntity="Sadev\BusinessModelBundle\Entity\Page", inversedBy="fils")
	* @ORM\JoinColumn(nullable=true)
	*/
	private $parent;
	
	
	/**
    * @ORM\OneToMany(targetEntity="Sadev\BusinessModelBundle\Entity\Page", mappedBy="parent")
	*/
    private $fils;  

    /**
     * @var string
     * @Serializer\Expose
     * @ORM\Column(name="shortTitle", type="string", length=50, nullable=true, unique=true)
     */
    private $shortTitle;

    /**
     * @var string
     * @Serializer\Expose
     * @ORM\Column(name="backgroundColor", type="string", length=7, nullable=true)
     */
    private $backgroundColor;

    /**
     * Constructor
     */
    public function __construct()
    {
		parent::__construct();
		
        $this->setTypeData('page');
    }

    /**
     * Set fichier
     *
     * @param array $fichier
     *
     * @return Page
     */
    public function setFichier($fichier)
    {
        $media = array();
        $media['baseUrl'] = $fichier->getBaseUrl();
        $media['hash'] = $fichier->getHash();
        $media['mime'] = $fichier->getMime();
        $media['name'] = $fichier->getName();
        $media['path'] = $fichier->getPath();
        $media['phash'] = $fichier->getPhash();
        $media['size'] = $fichier->getSize();
        $media['ts'] = $fichier->getTs();
        $media['url'] = $fichier->getUrl();
        $this->fichier =  $media;

        return $this;
    }

    /**
     * Get fichier
     *
     * @return array
     */
    public function getFichier()
    {
        return $this->fichier;
    }

    /**
     * Set videoYoutube
     *
     * @param string $videoYoutube
     *
     * @return Page
     */
    public function setVideoYoutube($videoYoutube)
    {
        $this->videoYoutube = $videoYoutube;

        return $this;
    }

    /**
     * Get videoYoutube
     *
     * @return string
     */
    public function getVideoYoutube()
    {
        return $this->videoYoutube;
    }

    /**
     * Set parent
     *
     * @param \Sadev\BusinessModelBundle\Entity\Page $parent
     *
     * @return Page
     */
    public function setParent(\Sadev\BusinessModelBundle\Entity\Page $parent = null)
    {
        $this->parent = $parent;

        return $this;
    }

    /**
     * Get parent
     *
     * @return \Sadev\BusinessModelBundle\Entity\Page
     */
    public function getParent()
    {
        return $this->parent;
    }

    /**
     * Add fil
     *
     * @param \Sadev\BusinessModelBundle\Entity\Page $fil
     *
     * @return Page
     */
    public function addFil(\Sadev\BusinessModelBundle\Entity\Page $fil)
    {
        $this->fils[] = $fil;

        return $this;
    }

    /**
     * Remove fil
     *
     * @param \Sadev\BusinessModelBundle\Entity\Page $fil
     */
    public function removeFil(\Sadev\BusinessModelBundle\Entity\Page $fil)
    {
        $this->fils->removeElement($fil);
    }

    /**
     * Get fils
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getFils()
    {
        return $this->fils;
    }

    
    /**
     * Set shortTitle
     *
     * @param string $shortTitle
     *
     * @return Page
     */
    public function setShortTitle($shortTitle)
    {
        $this->shortTitle = $shortTitle;

        return $this;
    }

    /**
     * Get shortTitle
     *
     * @return string
     */
    public function getShortTitle()
    {
        return $this->shortTitle;
    }

    

    /**
     * Set backgroundColor
     *
     * @param string $backgroundColor
     *
     * @return Page
     */
    public function setBackgroundColor($backgroundColor)
    {
        $this->backgroundColor = $backgroundColor;

        return $this;
    }

    /**
     * Get backgroundColor
     *
     * @return string
     */
    public function getBackgroundColor()
    {
        return $this->backgroundColor;
    }


    /**
     * @VirtualProperty
     * @SerializedName("parent_id")
     * @Type("integer")
    **/
    /* public function parentId()
    {
        if($this->parent !== null )
        return $this->parent->getId();
        else
        return null;
    } */

    /**
     * @VirtualProperty
     * @SerializedName("parent_page")
     * @Type("Sadev\BusinessModelBundle\Entity\PageStruct")
    **/
    public function parentPage()
    {
        $obj = null;
    
        if( $this->parent !== null) {
            $obj = new PageStruct();
            $obj->id = $this->parent->getId();
            $obj->short_title = $this->parent->getShortTitle();
            $obj->slug = $this->parent->getSlug();
        }

        return $obj;

    }

    /**
     * @VirtualProperty
     * @SerializedName("brother_page")
     * @Type("array<Sadev\BusinessModelBundle\Entity\PageStruct>")
    **/
    public function brotherPage()
    {

        $brother = array();
    
        if( $this->parent !== null) {
            
            if( $this->parent->getFils() !== null) {

                foreach( $this->parent->getFils() as $elem) {
    
                    $obj = new PageStruct();
                    $obj->id = $elem->getId();
                    $obj->short_title = $elem->getShortTitle();
                    $obj->slug = $elem->getSlug();
                    $brother[] = $obj;
    
                }
    
            }

        } else {

            // cas ou il s'agit d'une page parente

            if($this->getFils() != null)
            {
                
                foreach( $this->getFils() as $elem) {

                    $obj = new PageStruct();
                    $obj->id = $elem->getId();
                    $obj->short_title = $elem->getShortTitle();
                    $obj->slug = $elem->getSlug();
                    $brother[] = $obj;
        
                }
                
            }

        }

        return $brother;

    }

    /**
     * @VirtualProperty
     * @SerializedName("fils_page")
     * @Type("array<Sadev\BusinessModelBundle\Entity\PageStruct>")
    **/
    public function filsPage()
    {
        $chil = array();
    
        if( $this->fils !== null) {

            foreach( $this->fils as $elem) {

               
                $obj = new PageStruct();
                $obj->id = $elem->getId();
                $obj->short_title = $elem->getShortTitle();
                $obj->slug = $elem->getSlug();
                $chil[] = $obj;

            }

        }

        return $chil;

    }

    /**
     * @VirtualProperty
     * @SerializedName("descendant")
     * @Type("array")
    **/
    public function descendant()
    {

		$descendants = array();
        $this->recursivechild($this, $descendants);
		
		return $descendants;
		
    }

    public function recursivechild($page, &$descendants)
	{
		
		// $descendants[] = $elem->getId();
		
		if($page->getFils() != null)
		{
			
			foreach( $page->getFils() as $elem) {

                $obj = new PageStruct();
                $obj->id = $elem->getId();
                $obj->short_title = $elem->getShortTitle();
                $obj->slug = $elem->getSlug();

                $descendants[] = $obj;

                $this->recursivechild($elem, $descendants);
    
            }
			
        }
        
		
	}


}
