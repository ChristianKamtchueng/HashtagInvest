<?php

namespace Sadev\BusinessModelBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use JMS\Serializer\Annotation\Type;
use JMS\Serializer\Annotation as Serializer;
use JMS\Serializer\Annotation\VirtualProperty;

/**
 * Message
 *
 * @ORM\Table(name="message")
 * @ORM\Entity(repositoryClass="Sadev\BusinessModelBundle\Repository\MessageRepository")
 * @Serializer\ExclusionPolicy("ALL")
 */
class Message extends Data
{
    

    /**
     * @var string
     *
     * @ORM\Column(name="sender", type="string", length=255)
     * @Serializer\Expose
     */
    private $sender;

    /**
     * @var string
     *
     * @ORM\Column(name="email", type="string", length=255)
     * @Serializer\Expose
     */
    private $email;

    /**
     * @var string
     *
     * @ORM\Column(name="phone", type="string", length=255, nullable=true)
     * @Serializer\Expose
     */
    private $phone;

    /**
     * @var string
     *
     * @ORM\Column(name="objet", type="string", length=255, nullable=true)
     * @Serializer\Expose 
     */
    private $objet;

    /**
     * @var string
     *
     * @ORM\Column(name="content", type="text")
     * @Serializer\Expose 
     */
    private $content;


    /**
     * @ORM\ManyToMany(targetEntity="Sadev\BusinessModelBundle\Entity\Fichier", cascade={"persist", "remove"})
     * @ORM\JoinColumn(nullable=true)
     * @Serializer\Expose 
     */
    private $piecesJointes;


    public $filesdata;



    /**
     * Constructor
     */
    public function __construct()
    {
		parent::__construct();
        $this->setTypeData('message');
    }


    /**
     * Set sender
     *
     * @param string $sender
     *
     * @return Message
     */
    public function setSender($sender)
    {
        $this->sender = $sender;

        return $this;
    }

    /**
     * Get sender
     *
     * @return string
     */
    public function getSender()
    {
        return $this->sender;
    }

    /**
     * Set email
     *
     * @param string $email
     *
     * @return Message
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set phone
     *
     * @param string $phone
     *
     * @return Message
     */
    public function setPhone($phone)
    {
        $this->phone = $phone;

        return $this;
    }

    /**
     * Get phone
     *
     * @return string
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * Set objet
     *
     * @param string $objet
     *
     * @return Message
     */
    public function setObjet($objet)
    {
        $this->objet = $objet;

        return $this;
    }

    /**
     * Get objet
     *
     * @return string
     */
    public function getObjet()
    {
        return $this->objet;
    }

    /**
     * Set content
     *
     * @param string $content
     *
     * @return Message
     */
    public function setContent($content)
    {
        $this->content = $content;

        return $this;
    }

    /**
     * Get content
     *
     * @return string
     */
    public function getContent()
    {
        return $this->content;
    }

    /**
     * Add piecesJointe
     *
     * @param \Sadev\BusinessModelBundle\Entity\Fichier $piecesJointe
     *
     * @return Message
     */
    public function addPiecesJointe(\Sadev\BusinessModelBundle\Entity\Fichier $piecesJointe)
    {
        $this->piecesJointes[] = $piecesJointe;

        return $this;
    }

    /**
     * Remove piecesJointe
     *
     * @param \Sadev\BusinessModelBundle\Entity\Fichier $piecesJointe
     */
    public function removePiecesJointe(\Sadev\BusinessModelBundle\Entity\Fichier $piecesJointe)
    {
        $this->piecesJointes->removeElement($piecesJointe);
    }

    /**
     * Get piecesJointes
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getPiecesJointes()
    {
        return $this->piecesJointes;
    }
}
