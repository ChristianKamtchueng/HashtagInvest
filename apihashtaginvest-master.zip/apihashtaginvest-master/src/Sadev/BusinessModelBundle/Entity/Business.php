<?php

namespace Sadev\BusinessModelBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use JMS\Serializer\Annotation as Serializer;
use JMS\Serializer\Annotation\VirtualProperty;

/**
 * Business
 *
 * @ORM\Table(name="business")
 * @ORM\Entity(repositoryClass="Sadev\BusinessModelBundle\Repository\BusinessRepository")
 */
class Business extends Data
{
    
    /**
     * @var string
     *
     * @ORM\Column(name="domaine", type="string", length=255)
     */
    private $domaine;

    /**
     * @var string
     *
     * @ORM\Column(name="metier", type="string", length=255, nullable=true)
     */
    private $metier;

    /**
     * @var string
     *
     * @ORM\Column(name="speciality", type="string", length=255, nullable=true)
     */
    private $speciality;

    /**
     * @var string
     *
     * @ORM\Column(name="activity", type="string", length=255, nullable=true)
     */
    private $activity;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text", nullable=true)
     */
    private $description;

    /**
     * @var float
     *
     * @ORM\Column(name="budget", type="float", nullable=true)
     */
    private $budget;

    /**
     * @var string
     *
     * @ORM\Column(name="ville", type="string", length=255, nullable=true)
     */
    private $ville;

    /**
     * @var string
     *
     * @ORM\Column(name="bienType", type="string", length=255, nullable=true)
     */
    private $bienType;

    /**
     * @var string
     *
     * @ORM\Column(name="status", type="string", length=255, nullable=true)
     */
    private $status; // null, validated (lorsque l'affaire a été délégué à un partenaire), accompted (accompte payé), delivery (affaire effectué), confirmated (le client valide en éffectuant le dernier paiement)

    /**
     * @var float
     *
     * @ORM\Column(name="surface", type="float", nullable=true)
     */
    private $surface;

    /**
     * @var int
     *
     * @ORM\Column(name="pieceNbr", type="integer", nullable=true)
     */
    private $pieceNbr;

    /**
     * @var string
     *
     * @ORM\Column(name="transactionRef", type="string", length=255, nullable=true, unique=true)
     */
    private $transactionRef;

    /**
     * @var string
     *
     * @ORM\Column(name="adresse", type="string", length=255, nullable=true)
     */
    private $adresse;

    /**
     * @var float
     *
     * @ORM\Column(name="TransactionPrice", type="float", nullable=true)
     */
    private $transactionPrice;

    /**
     * @var string
     *
     * @ORM\Column(name="contact", type="string", length=255, nullable=true)
     */
    private $contact;

    

    /**
     * @var string
     *
     * @ORM\Column(name="transactionConditions", type="text", nullable=true)
     */
    private $transactionConditions;

    /**
     * @var bool
     *
     * @ORM\Column(name="withPartner", type="boolean", nullable=true)
     */
    private $withPartner;


    /**
     * @ORM\ManyToMany(targetEntity="Sadev\BusinessModelBundle\Entity\Fichier",  cascade={"persist", "remove"})
     * @ORM\JoinTable(name="business_photos")
     */
    private $photos;


    /**
     * @ORM\ManyToMany(targetEntity="Sadev\BusinessModelBundle\Entity\Fichier", cascade={"persist", "remove"})
     * @ORM\JoinTable(name="business_documents")
     */
    private $documents;


    /**
    * @ORM\OneToOne(targetEntity="Sadev\BusinessModelBundle\Entity\Fichier")
    * @ORM\JoinColumn(nullable=true)
	*/
    private $imagePrincipale; // photo principale du business


    /**
    * @ORM\OneToMany(targetEntity="Sadev\BusinessModelBundle\Entity\Answer", mappedBy="business")
    * @Serializer\Expose
	*/
    private $answers; 


    /**
	* @ORM\OneToOne(targetEntity="Sadev\BusinessModelBundle\Entity\Answer")
    * @ORM\JoinColumn(nullable=true)
    * @Serializer\Expose
	*/
	private $selectedAnswer; // la reponse selectionnee par le createur du business


    /**
     * @var string
     *
     * @ORM\Column(name="nomclient", type="string", length=255, nullable=true)
     */
    private $nomclient;

    /**
     * @var string
     *
     * @ORM\Column(name="prenomclient", type="string", length=255, nullable=true)
     */
    private $prenomclient;


    /**
     * @var string
     *
     * @ORM\Column(name="statusclient", type="string", length=255, nullable=true)
     */
    private $statusclient;

    /**
     * @var string
     *
     * @ORM\Column(name="raisonclient", type="string", length=255, nullable=true)
     */
    private $raisonclient;


    /**
     * @var string
     *
     * @ORM\Column(name="siretclient", type="string", length=255, nullable=true)
     */
    private $siretclient;


    /**
	* @ORM\OneToOne(targetEntity="Sadev\BusinessModelBundle\Entity\Devis")
    * @ORM\JoinColumn(nullable=true)
	*/
	private $devisave;

    /**
     * @var string
     *
     * @ORM\Column(name="emailclient", type="string", length=255, nullable=true)
     */
    private $emailclient;


    /**
     * @var string
     *
     * @ORM\Column(name="telclient", type="string", length=255, nullable=true)
     */
    private $telclient;

    /**
     * @var string
     *
     * @ORM\Column(name="villeclient", type="string", length=255, nullable=true)
     */
    private $villeclient;

    /**
     * @var string
     *
     * @ORM\Column(name="adresseclient", type="string", length=255, nullable=true)
     */
    private $adresseclient;


    /**
     * @var float
     *
     * @ORM\Column(name="surfacehabitable", type="float", nullable=true)
     */
    private $surfacehabitable;

    /**
     * @var float
     *
     * @ORM\Column(name="nbrpiece", type="integer", nullable=true)
     */
    private $nbrpiece;

    /**
     * @var float
     *
     * @ORM\Column(name="nbrchambre", type="integer", nullable=true)
     */
    private $nbrchambre;

    /**
     * @var float
     *
     * @ORM\Column(name="nbrsallebain", type="integer", nullable=true)
     */
    private $nbrsallebain;

    /**
     * @var float
     *
     * @ORM\Column(name="nbrwc", type="integer", nullable=true)
     */
    private $nbrwc;

    /**
     * @var float
     *
     * @ORM\Column(name="nbretage", type="integer", nullable=true)
     */
    private $nbretage;


    /**
     * @var float
     *
     * @ORM\Column(name="etagebien", type="integer", nullable=true)
     */
    private $etagebien;

    /**
     * @var bool
     *
     * @ORM\Column(name="rez_de_chaussee", type="boolean", nullable=true)
     */
    private $rez_de_chaussee;

    /**
     * @var bool
     *
     * @ORM\Column(name="dernieretage", type="boolean", nullable=true)
     */
    private $dernieretage;

    /**
     * @var bool
     *
     * @ORM\Column(name="ascenseur", type="boolean", nullable=true)
     */
    private $ascenseur;

    /**
     * @var bool
     *
     * @ORM\Column(name="anneeconstruction", type="integer", nullable=true)
     */
    private $anneeconstruction;

    /**
     * @var bool
     *
     * @ORM\Column(name="previsiontravaux", type="boolean", nullable=true)
     */
    private $previsiontravaux;

    /**
     * @var array
     * @ORM\Column(name="typexterieur", type="array", nullable=true)
     */
    private $typexterieur;

    /**
     * @var bool
     *
     * @ORM\Column(name="normepmr", type="boolean", nullable=true)
     */
    private $normepmr;

    /**
     * @var string
     *
     * @ORM\Column(name="classedpe", type="string", length=255, nullable=true)
     */
    private $classedpe;

    /**
     * @var string
     *
     * @ORM\Column(name="classeges", type="string", length=255, nullable=true)
     */
    private $classeges;

    /**
     * @var string
     *
     * @ORM\Column(name="descriptionbiensynthetique", type="text", nullable=true)
     */
    private $descriptionbiensynthetique;

    /**
     * @var string
     *
     * @ORM\Column(name="statusoccupation", type="string", length=255, nullable=true)
     */
    private $statusoccupation;


    /**
     * @var float
     *
     * @ORM\Column(name="loyermensuelle", type="float", nullable=true)
     */
    private $loyermensuelle;

    /**
     * @var float
     *
     * @ORM\Column(name="chargesrecuperables", type="float", nullable=true)
     */
    private $chargesrecuperables;

    /**
     * @var float
     *
     * @ORM\Column(name="chargesnonrecuperables", type="float", nullable=true)
     */
    private $chargesnonrecuperables;

    /**
     * @var string
     *
     * @ORM\Column(name="typbail", type="string", length=255, nullable=true)
     */
    private $typbail;

    /**
     * @var \Date
     *
     * @ORM\Column(name="datedebutbail", type="date", nullable=true)
     */
    protected $datedebutbail;

    /**
     * @var \Date
     *
     * @ORM\Column(name="datefinbail", type="date", nullable=true)
     */
    protected $datefinbail;


    /**
     * @var string
     *
     * @ORM\Column(name="locataireajourdesloyer", type="string", length=255, nullable=true)
     */
    private $locataireajourdesloyer;

    /**
     * @var string
     *
     * @ORM\Column(name="typeviager", type="string", length=255, nullable=true)
     */
    private $typeviager;

    /**
     * @var float
     *
     * @ORM\Column(name="bouquetviager", type="float", nullable=true)
     */
    private $bouquetviager;    

    /**
     * @var float
     *
     * @ORM\Column(name="rentemensuelleviager", type="float", nullable=true)
     */
    private $rentemensuelleviager;

    /**
     * @var bool
     *
     * @ORM\Column(name="indexationviager", type="boolean", nullable=true)
     */
    private $indexationviager;

    /**
     * @var bool
     *
     * @ORM\Column(name="ageviager", type="integer", nullable=true)
     */
    private $ageviager;


    /**
     * @var bool
     *
     * @ORM\Column(name="nbrcredirentiersviager", type="integer", nullable=true)
     */
    private $nbrcredirentiersviager;

    /**
     * @var string
     *
     * @ORM\Column(name="methodeindexationviager", type="string", length=255, nullable=true)
     */
    private $methodeindexationviager;

    /**
     * @var string
     *
     * @ORM\Column(name="statusconjugalviager", type="string", length=255, nullable=true)
     */
    private $statusconjugalviager;

    /**
     * @var bool
     *
     * @ORM\Column(name="duhviager", type="boolean", nullable=true)
     */
    private $duhviager;


    /**
     * @var bool
     *
     * @ORM\Column(name="vendeuroccupantviager", type="boolean", nullable=true)
     */
    private $vendeuroccupantviager;


    /**
     * @var string
     *
     * @ORM\Column(name="repartitionchargesviager", type="string", length=255, nullable=true)
     */
    private $repartitionchargesviager;


    /**
     * @var bool
     *
     * @ORM\Column(name="inclushonoraires", type="boolean", nullable=true)
     */
    private $inclushonoraires;


    /**
     * @var string
     *
     * @ORM\Column(name="modecalculhonoraire", type="string", length=255, nullable=true)
     */
    private $modecalculhonoraire; // fixe, varible


    /**
     * @var float
     *
     * @ORM\Column(name="montanthonoraires", type="float", nullable=true)
     */
    private $montanthonoraires;

    /**
     * @var float
     *
     * @ORM\Column(name="chargecopropriete", type="float", nullable=true)
     */
    private $chargecopropriete; //(€ / mois)

    /**
     * @var float
     *
     * @ORM\Column(name="taxefonciere", type="float", nullable=true)
     */
    private $taxefonciere; //(€ / ans)

    /**
     * @ORM\OneToOne(targetEntity="Sadev\BusinessModelBundle\Entity\Fichier", cascade={"remove", "persist"})
     * @ORM\JoinColumn(nullable=true)
     */
    private $docdpe;

    /**
     * @ORM\OneToOne(targetEntity="Sadev\BusinessModelBundle\Entity\Fichier", cascade={"remove", "persist"})
     * @ORM\JoinColumn(nullable=true)
     */
    private $docplans;

    /**
     * @ORM\OneToOne(targetEntity="Sadev\BusinessModelBundle\Entity\Fichier", cascade={"remove", "persist"})
     * @ORM\JoinColumn(nullable=true)
     */
    private $docdiagnosticstechniques;


    /**
     * @ORM\OneToOne(targetEntity="Sadev\BusinessModelBundle\Entity\Fichier", cascade={"remove", "persist"})
     * @ORM\JoinColumn(nullable=true)
     */
    private $doccompromismandat;


    /**
     * @var bool
     *
     * @ORM\Column(name="nummandat", type="integer", nullable=true)
     */
    private $nummandat;

    /**
     * Constructor
     */
    public function __construct()
    {
		parent::__construct();
        $this->setTypeData('business');

    }

    /**
     * Set domaine
     *
     * @param string $domaine
     *
     * @return Business
     */
    public function setDomaine($domaine)
    {
        $this->domaine = $domaine;

        return $this;
    }

    /**
     * Get domaine
     *
     * @return string
     */
    public function getDomaine()
    {
        return $this->domaine;
    }

    /**
     * Set metier
     *
     * @param string $metier
     *
     * @return Business
     */
    public function setMetier($metier)
    {
        $this->metier = $metier;

        return $this;
    }

    /**
     * Get metier
     *
     * @return string
     */
    public function getMetier()
    {
        return $this->metier;
    }

    /**
     * Set speciality
     *
     * @param string $speciality
     *
     * @return Business
     */
    public function setSpeciality($speciality)
    {
        $this->speciality = $speciality;

        return $this;
    }

    /**
     * Get speciality
     *
     * @return string
     */
    public function getSpeciality()
    {
        return $this->speciality;
    }

    /**
     * Set activity
     *
     * @param string $activity
     *
     * @return Business
     */
    public function setActivity($activity)
    {
        $this->activity = $activity;

        return $this;
    }

    /**
     * Get activity
     *
     * @return string
     */
    public function getActivity()
    {
        return $this->activity;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return Business
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set budget
     *
     * @param float $budget
     *
     * @return Business
     */
    public function setBudget($budget)
    {
        $this->budget = $budget;

        return $this;
    }

    /**
     * Get budget
     *
     * @return float
     */
    public function getBudget()
    {
        return $this->budget;
    }

    /**
     * Set ville
     *
     * @param string $ville
     *
     * @return Business
     */
    public function setVille($ville)
    {
        $this->ville = $ville;

        return $this;
    }

    /**
     * Get ville
     *
     * @return string
     */
    public function getVille()
    {
        return $this->ville;
    }

    /**
     * Set bienType
     *
     * @param string $bienType
     *
     * @return Business
     */
    public function setBienType($bienType)
    {
        $this->bienType = $bienType;

        return $this;
    }

    /**
     * Get bienType
     *
     * @return string
     */
    public function getBienType()
    {
        return $this->bienType;
    }

    /**
     * Set status
     *
     * @param string $status
     *
     * @return Business
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status
     *
     * @return string
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Set surface
     *
     * @param float $surface
     *
     * @return Business
     */
    public function setSurface($surface)
    {
        $this->surface = $surface;

        return $this;
    }

    /**
     * Get surface
     *
     * @return float
     */
    public function getSurface()
    {
        return $this->surface;
    }

    /**
     * Set pieceNbr
     *
     * @param integer $pieceNbr
     *
     * @return Business
     */
    public function setPieceNbr($pieceNbr)
    {
        $this->pieceNbr = $pieceNbr;

        return $this;
    }

    /**
     * Get pieceNbr
     *
     * @return int
     */
    public function getPieceNbr()
    {
        return $this->pieceNbr;
    }

    /**
     * Set transactionRef
     *
     * @param string $transactionRef
     *
     * @return Business
     */
    public function setTransactionRef($transactionRef)
    {
        $this->transactionRef = $transactionRef;

        return $this;
    }

    /**
     * Get transactionRef
     *
     * @return string
     */
    public function getTransactionRef()
    {
        return $this->transactionRef;
    }

    /**
     * Set adresse
     *
     * @param string $adresse
     *
     * @return Business
     */
    public function setAdresse($adresse)
    {
        $this->adresse = $adresse;

        return $this;
    }

    /**
     * Get adresse
     *
     * @return string
     */
    public function getAdresse()
    {
        return $this->adresse;
    }

    /**
     * Set transactionPrice
     *
     * @param float $transactionPrice
     *
     * @return Business
     */
    public function setTransactionPrice($transactionPrice)
    {
        $this->transactionPrice = $transactionPrice;

        return $this;
    }

    /**
     * Get transactionPrice
     *
     * @return float
     */
    public function getTransactionPrice()
    {
        return $this->transactionPrice;
    }

    /**
     * Set contact
     *
     * @param string $contact
     *
     * @return Business
     */
    public function setContact($contact)
    {
        $this->contact = $contact;

        return $this;
    }

    /**
     * Get contact
     *
     * @return string
     */
    public function getContact()
    {
        return $this->contact;
    }

    
    /**
     * Set transactionConditions
     *
     * @param string $transactionConditions
     *
     * @return Business
     */
    public function setTransactionConditions($transactionConditions)
    {
        $this->transactionConditions = $transactionConditions;

        return $this;
    }

    /**
     * Get transactionConditions
     *
     * @return string
     */
    public function getTransactionConditions()
    {
        return $this->transactionConditions;
    }

    /**
     * Set withPartner
     *
     * @param boolean $withPartner
     *
     * @return Business
     */
    public function setWithPartner($withPartner)
    {
        $this->withPartner = $withPartner;

        return $this;
    }

    /**
     * Get withPartner
     *
     * @return bool
     */
    public function getWithPartner()
    {
        return $this->withPartner;
    }


    /**
     * Add photo
     *
     * @param \Sadev\BusinessModelBundle\Entity\Fichier $photo
     *
     * @return Business
     */
    public function addPhoto(\Sadev\BusinessModelBundle\Entity\Fichier $photo)
    {
        $this->photos[] = $photo;

        return $this;
    }

    /**
     * Remove photo
     *
     * @param \Sadev\BusinessModelBundle\Entity\Fichier $photo
     */
    public function removePhoto(\Sadev\BusinessModelBundle\Entity\Fichier $photo)
    {
        $this->photos->removeElement($photo);
    }

    /**
     * Get photos
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getPhotos()
    {
        return $this->photos;
    }

    /**
     * Add document
     *
     * @param \Sadev\BusinessModelBundle\Entity\Fichier $document
     *
     * @return Business
     */
    public function addDocument(\Sadev\BusinessModelBundle\Entity\Fichier $document)
    {
        $this->documents[] = $document;

        return $this;
    }

    /**
     * Remove document
     *
     * @param \Sadev\BusinessModelBundle\Entity\Fichier $document
     */
    public function removeDocument(\Sadev\BusinessModelBundle\Entity\Fichier $document)
    {
        $this->documents->removeElement($document);
    }

    /**
     * Get documents
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getDocuments()
    {
        return $this->documents;
    }

    /**
     * Set imagePrincipale
     *
     * @param \Sadev\BusinessModelBundle\Entity\Fichier $imagePrincipale
     *
     * @return Business
     */
    public function setImagePrincipale(\Sadev\BusinessModelBundle\Entity\Fichier $imagePrincipale = null)
    {
        $this->imagePrincipale = $imagePrincipale;

        return $this;
    }

    /**
     * Get imagePrincipale
     *
     * @return \Sadev\BusinessModelBundle\Entity\Fichier
     */
    public function getImagePrincipale()
    {
        return $this->imagePrincipale;
    }

    



    /**
     * Add answer
     *
     * @param \Sadev\BusinessModelBundle\Entity\Answer $answer
     *
     * @return Business
     */
    public function addAnswer(\Sadev\BusinessModelBundle\Entity\Answer $answer)
    {
        $this->answers[] = $answer;

        return $this;
    }

    /**
     * Remove answer
     *
     * @param \Sadev\BusinessModelBundle\Entity\Answer $answer
     */
    public function removeAnswer(\Sadev\BusinessModelBundle\Entity\Answer $answer)
    {
        $this->answers->removeElement($answer);
    }

    /**
     * Get answers
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getAnswers()
    {
        return $this->answers;
    }

    /**
     * Set selectedAnswer
     *
     * @param \Sadev\BusinessModelBundle\Entity\Answer $selectedAnswer
     *
     * @return Business
     */
    public function setSelectedAnswer(\Sadev\BusinessModelBundle\Entity\Answer $selectedAnswer = null)
    {
        $this->selectedAnswer = $selectedAnswer;

        return $this;
    }

    /**
     * Get selectedAnswer
     *
     * @return \Sadev\BusinessModelBundle\Entity\Answer
     */
    public function getSelectedAnswer()
    {
        return $this->selectedAnswer;
    }

    /**
     * Set nomclient
     *
     * @param string $nomclient
     *
     * @return Business
     */
    public function setNomclient($nomclient)
    {
        $this->nomclient = $nomclient;

        return $this;
    }

    /**
     * Get nomclient
     *
     * @return string
     */
    public function getNomclient()
    {
        return $this->nomclient;
    }

    /**
     * Set prenomclient
     *
     * @param string $prenomclient
     *
     * @return Business
     */
    public function setPrenomclient($prenomclient)
    {
        $this->prenomclient = $prenomclient;

        return $this;
    }

    /**
     * Get prenomclient
     *
     * @return string
     */
    public function getPrenomclient()
    {
        return $this->prenomclient;
    }

    /**
     * Set statusclient
     *
     * @param string $statusclient
     *
     * @return Business
     */
    public function setStatusclient($statusclient)
    {
        $this->statusclient = $statusclient;

        return $this;
    }

    /**
     * Get statusclient
     *
     * @return string
     */
    public function getStatusclient()
    {
        return $this->statusclient;
    }

    /**
     * Set raisonclient
     *
     * @param string $raisonclient
     *
     * @return Business
     */
    public function setRaisonclient($raisonclient)
    {
        $this->raisonclient = $raisonclient;

        return $this;
    }

    /**
     * Get raisonclient
     *
     * @return string
     */
    public function getRaisonclient()
    {
        return $this->raisonclient;
    }

    /**
     * Set siretclient
     *
     * @param string $siretclient
     *
     * @return Business
     */
    public function setSiretclient($siretclient)
    {
        $this->siretclient = $siretclient;

        return $this;
    }

    /**
     * Get siretclient
     *
     * @return string
     */
    public function getSiretclient()
    {
        return $this->siretclient;
    }

    
       

    

    /**
     * Set devisave
     *
     * @param \Sadev\BusinessModelBundle\Entity\Devis $devisave
     *
     * @return Business
     */
    public function setDevisave(\Sadev\BusinessModelBundle\Entity\Devis $devisave = null)
    {
        $this->devisave = $devisave;

        return $this;
    }

    /**
     * Get devisave
     *
     * @return \Sadev\BusinessModelBundle\Entity\Devis
     */
    public function getDevisave()
    {
        return $this->devisave;
    }

    /**
     * Set emailclient
     *
     * @param string $emailclient
     *
     * @return Business
     */
    public function setEmailclient($emailclient)
    {
        $this->emailclient = $emailclient;

        return $this;
    }

    /**
     * Get emailclient
     *
     * @return string
     */
    public function getEmailclient()
    {
        return $this->emailclient;
    }

    /**
     * Set telclient
     *
     * @param string $telclient
     *
     * @return Business
     */
    public function setTelclient($telclient)
    {
        $this->telclient = $telclient;

        return $this;
    }

    /**
     * Get telclient
     *
     * @return string
     */
    public function getTelclient()
    {
        return $this->telclient;
    }

    /**
     * Set villeclient
     *
     * @param string $villeclient
     *
     * @return Business
     */
    public function setVilleclient($villeclient)
    {
        $this->villeclient = $villeclient;

        return $this;
    }

    /**
     * Get villeclient
     *
     * @return string
     */
    public function getVilleclient()
    {
        return $this->villeclient;
    }

    /**
     * Set adresseclient
     *
     * @param string $adresseclient
     *
     * @return Business
     */
    public function setAdresseclient($adresseclient)
    {
        $this->adresseclient = $adresseclient;

        return $this;
    }

    /**
     * Get adresseclient
     *
     * @return string
     */
    public function getAdresseclient()
    {
        return $this->adresseclient;
    }

    /**
     * Set surfacehabitable
     *
     * @param float $surfacehabitable
     *
     * @return Business
     */
    public function setSurfacehabitable($surfacehabitable)
    {
        $this->surfacehabitable = $surfacehabitable;

        return $this;
    }

    /**
     * Get surfacehabitable
     *
     * @return float
     */
    public function getSurfacehabitable()
    {
        return $this->surfacehabitable;
    }

    /**
     * Set nbrpiece
     *
     * @param integer $nbrpiece
     *
     * @return Business
     */
    public function setNbrpiece($nbrpiece)
    {
        $this->nbrpiece = $nbrpiece;

        return $this;
    }

    /**
     * Get nbrpiece
     *
     * @return integer
     */
    public function getNbrpiece()
    {
        return $this->nbrpiece;
    }

    /**
     * Set nbrchambre
     *
     * @param integer $nbrchambre
     *
     * @return Business
     */
    public function setNbrchambre($nbrchambre)
    {
        $this->nbrchambre = $nbrchambre;

        return $this;
    }

    /**
     * Get nbrchambre
     *
     * @return integer
     */
    public function getNbrchambre()
    {
        return $this->nbrchambre;
    }

    /**
     * Set nbrsallebain
     *
     * @param integer $nbrsallebain
     *
     * @return Business
     */
    public function setNbrsallebain($nbrsallebain)
    {
        $this->nbrsallebain = $nbrsallebain;

        return $this;
    }

    /**
     * Get nbrsallebain
     *
     * @return integer
     */
    public function getNbrsallebain()
    {
        return $this->nbrsallebain;
    }

    /**
     * Set nbrwc
     *
     * @param integer $nbrwc
     *
     * @return Business
     */
    public function setNbrwc($nbrwc)
    {
        $this->nbrwc = $nbrwc;

        return $this;
    }

    /**
     * Get nbrwc
     *
     * @return integer
     */
    public function getNbrwc()
    {
        return $this->nbrwc;
    }

    /**
     * Set nbretage
     *
     * @param integer $nbretage
     *
     * @return Business
     */
    public function setNbretage($nbretage)
    {
        $this->nbretage = $nbretage;

        return $this;
    }

    /**
     * Get nbretage
     *
     * @return integer
     */
    public function getNbretage()
    {
        return $this->nbretage;
    }

    /**
     * Set rezDeChaussee
     *
     * @param boolean $rezDeChaussee
     *
     * @return Business
     */
    public function setRezDeChaussee($rezDeChaussee)
    {
        $this->rez_de_chaussee = $rezDeChaussee;

        return $this;
    }

    /**
     * Get rezDeChaussee
     *
     * @return boolean
     */
    public function getRezDeChaussee()
    {
        return $this->rez_de_chaussee;
    }

    /**
     * Set dernieretage
     *
     * @param boolean $dernieretage
     *
     * @return Business
     */
    public function setDernieretage($dernieretage)
    {
        $this->dernieretage = $dernieretage;

        return $this;
    }

    /**
     * Get dernieretage
     *
     * @return boolean
     */
    public function getDernieretage()
    {
        return $this->dernieretage;
    }

    /**
     * Set ascenseur
     *
     * @param boolean $ascenseur
     *
     * @return Business
     */
    public function setAscenseur($ascenseur)
    {
        $this->ascenseur = $ascenseur;

        return $this;
    }

    /**
     * Get ascenseur
     *
     * @return boolean
     */
    public function getAscenseur()
    {
        return $this->ascenseur;
    }

    /**
     * Set anneeconstruction
     *
     * @param integer $anneeconstruction
     *
     * @return Business
     */
    public function setAnneeconstruction($anneeconstruction)
    {
        $this->anneeconstruction = $anneeconstruction;

        return $this;
    }

    /**
     * Get anneeconstruction
     *
     * @return integer
     */
    public function getAnneeconstruction()
    {
        return $this->anneeconstruction;
    }

    /**
     * Set previsiontravaux
     *
     * @param boolean $previsiontravaux
     *
     * @return Business
     */
    public function setPrevisiontravaux($previsiontravaux)
    {
        $this->previsiontravaux = $previsiontravaux;

        return $this;
    }

    /**
     * Get previsiontravaux
     *
     * @return boolean
     */
    public function getPrevisiontravaux()
    {
        return $this->previsiontravaux;
    }

    /**
     * Set typexterieur
     *
     * @param array $typexterieur
     *
     * @return Business
     */
    public function setTypexterieur($typexterieur)
    {
        $this->typexterieur = $typexterieur;

        return $this;
    }

    /**
     * Get typexterieur
     *
     * @return array
     */
    public function getTypexterieur()
    {
        return $this->typexterieur;
    }

    /**
     * Set normepmr
     *
     * @param boolean $normepmr
     *
     * @return Business
     */
    public function setNormepmr($normepmr)
    {
        $this->normepmr = $normepmr;

        return $this;
    }

    /**
     * Get normepmr
     *
     * @return boolean
     */
    public function getNormepmr()
    {
        return $this->normepmr;
    }

    /**
     * Set classedpe
     *
     * @param string $classedpe
     *
     * @return Business
     */
    public function setClassedpe($classedpe)
    {
        $this->classedpe = $classedpe;

        return $this;
    }

    /**
     * Get classedpe
     *
     * @return string
     */
    public function getClassedpe()
    {
        return $this->classedpe;
    }

    /**
     * Set classeges
     *
     * @param string $classeges
     *
     * @return Business
     */
    public function setClasseges($classeges)
    {
        $this->classeges = $classeges;

        return $this;
    }

    /**
     * Get classeges
     *
     * @return string
     */
    public function getClasseges()
    {
        return $this->classeges;
    }

    /**
     * Set descriptionbiensynthetique
     *
     * @param string $descriptionbiensynthetique
     *
     * @return Business
     */
    public function setDescriptionbiensynthetique($descriptionbiensynthetique)
    {
        $this->descriptionbiensynthetique = $descriptionbiensynthetique;

        return $this;
    }

    /**
     * Get descriptionbiensynthetique
     *
     * @return string
     */
    public function getDescriptionbiensynthetique()
    {
        return $this->descriptionbiensynthetique;
    }

    /**
     * Set statusoccupation
     *
     * @param string $statusoccupation
     *
     * @return Business
     */
    public function setStatusoccupation($statusoccupation)
    {
        $this->statusoccupation = $statusoccupation;

        return $this;
    }

    /**
     * Get statusoccupation
     *
     * @return string
     */
    public function getStatusoccupation()
    {
        return $this->statusoccupation;
    }

    /**
     * Set loyermensuelle
     *
     * @param float $loyermensuelle
     *
     * @return Business
     */
    public function setLoyermensuelle($loyermensuelle)
    {
        $this->loyermensuelle = $loyermensuelle;

        return $this;
    }

    /**
     * Get loyermensuelle
     *
     * @return float
     */
    public function getLoyermensuelle()
    {
        return $this->loyermensuelle;
    }

    /**
     * Set chargesrecuperables
     *
     * @param float $chargesrecuperables
     *
     * @return Business
     */
    public function setChargesrecuperables($chargesrecuperables)
    {
        $this->chargesrecuperables = $chargesrecuperables;

        return $this;
    }

    /**
     * Get chargesrecuperables
     *
     * @return float
     */
    public function getChargesrecuperables()
    {
        return $this->chargesrecuperables;
    }

    /**
     * Set chargesnonrecuperables
     *
     * @param float $chargesnonrecuperables
     *
     * @return Business
     */
    public function setChargesnonrecuperables($chargesnonrecuperables)
    {
        $this->chargesnonrecuperables = $chargesnonrecuperables;

        return $this;
    }

    /**
     * Get chargesnonrecuperables
     *
     * @return float
     */
    public function getChargesnonrecuperables()
    {
        return $this->chargesnonrecuperables;
    }

    /**
     * Set typbail
     *
     * @param string $typbail
     *
     * @return Business
     */
    public function setTypbail($typbail)
    {
        $this->typbail = $typbail;

        return $this;
    }

    /**
     * Get typbail
     *
     * @return string
     */
    public function getTypbail()
    {
        return $this->typbail;
    }

    /**
     * Set datedebutbail
     *
     * @param \DateTime $datedebutbail
     *
     * @return Business
     */
    public function setDatedebutbail($datedebutbail)
    {
        $this->datedebutbail = $datedebutbail;

        return $this;
    }

    /**
     * Get datedebutbail
     *
     * @return \DateTime
     */
    public function getDatedebutbail()
    {
        return $this->datedebutbail;
    }

    /**
     * Set datefinbail
     *
     * @param \DateTime $datefinbail
     *
     * @return Business
     */
    public function setDatefinbail($datefinbail)
    {
        $this->datefinbail = $datefinbail;

        return $this;
    }

    /**
     * Get datefinbail
     *
     * @return \DateTime
     */
    public function getDatefinbail()
    {
        return $this->datefinbail;
    }

    /**
     * Set locataireajourdesloyer
     *
     * @param string $locataireajourdesloyer
     *
     * @return Business
     */
    public function setLocataireajourdesloyer($locataireajourdesloyer)
    {
        $this->locataireajourdesloyer = $locataireajourdesloyer;

        return $this;
    }

    /**
     * Get locataireajourdesloyer
     *
     * @return string
     */
    public function getLocataireajourdesloyer()
    {
        return $this->locataireajourdesloyer;
    }

    /**
     * Set typeviager
     *
     * @param string $typeviager
     *
     * @return Business
     */
    public function setTypeviager($typeviager)
    {
        $this->typeviager = $typeviager;

        return $this;
    }

    /**
     * Get typeviager
     *
     * @return string
     */
    public function getTypeviager()
    {
        return $this->typeviager;
    }

    /**
     * Set bouquetviager
     *
     * @param float $bouquetviager
     *
     * @return Business
     */
    public function setBouquetviager($bouquetviager)
    {
        $this->bouquetviager = $bouquetviager;

        return $this;
    }

    /**
     * Get bouquetviager
     *
     * @return float
     */
    public function getBouquetviager()
    {
        return $this->bouquetviager;
    }

    /**
     * Set rentemensuelleviager
     *
     * @param float $rentemensuelleviager
     *
     * @return Business
     */
    public function setRentemensuelleviager($rentemensuelleviager)
    {
        $this->rentemensuelleviager = $rentemensuelleviager;

        return $this;
    }

    /**
     * Get rentemensuelleviager
     *
     * @return float
     */
    public function getRentemensuelleviager()
    {
        return $this->rentemensuelleviager;
    }

    /**
     * Set indexationviager
     *
     * @param boolean $indexationviager
     *
     * @return Business
     */
    public function setIndexationviager($indexationviager)
    {
        $this->indexationviager = $indexationviager;

        return $this;
    }

    /**
     * Get indexationviager
     *
     * @return boolean
     */
    public function getIndexationviager()
    {
        return $this->indexationviager;
    }

    /**
     * Set ageviager
     *
     * @param integer $ageviager
     *
     * @return Business
     */
    public function setAgeviager($ageviager)
    {
        $this->ageviager = $ageviager;

        return $this;
    }

    /**
     * Get ageviager
     *
     * @return integer
     */
    public function getAgeviager()
    {
        return $this->ageviager;
    }

    /**
     * Set nbrcredirentiersviager
     *
     * @param integer $nbrcredirentiersviager
     *
     * @return Business
     */
    public function setNbrcredirentiersviager($nbrcredirentiersviager)
    {
        $this->nbrcredirentiersviager = $nbrcredirentiersviager;

        return $this;
    }

    /**
     * Get nbrcredirentiersviager
     *
     * @return integer
     */
    public function getNbrcredirentiersviager()
    {
        return $this->nbrcredirentiersviager;
    }

    /**
     * Set methodeindexationviager
     *
     * @param string $methodeindexationviager
     *
     * @return Business
     */
    public function setMethodeindexationviager($methodeindexationviager)
    {
        $this->methodeindexationviager = $methodeindexationviager;

        return $this;
    }

    /**
     * Get methodeindexationviager
     *
     * @return string
     */
    public function getMethodeindexationviager()
    {
        return $this->methodeindexationviager;
    }

    /**
     * Set statusconjugalviager
     *
     * @param string $statusconjugalviager
     *
     * @return Business
     */
    public function setStatusconjugalviager($statusconjugalviager)
    {
        $this->statusconjugalviager = $statusconjugalviager;

        return $this;
    }

    /**
     * Get statusconjugalviager
     *
     * @return string
     */
    public function getStatusconjugalviager()
    {
        return $this->statusconjugalviager;
    }

    /**
     * Set duhviager
     *
     * @param boolean $duhviager
     *
     * @return Business
     */
    public function setDuhviager($duhviager)
    {
        $this->duhviager = $duhviager;

        return $this;
    }

    /**
     * Get duhviager
     *
     * @return boolean
     */
    public function getDuhviager()
    {
        return $this->duhviager;
    }

    /**
     * Set vendeuroccupantviager
     *
     * @param boolean $vendeuroccupantviager
     *
     * @return Business
     */
    public function setVendeuroccupantviager($vendeuroccupantviager)
    {
        $this->vendeuroccupantviager = $vendeuroccupantviager;

        return $this;
    }

    /**
     * Get vendeuroccupantviager
     *
     * @return boolean
     */
    public function getVendeuroccupantviager()
    {
        return $this->vendeuroccupantviager;
    }

    /**
     * Set repartitionchargesviager
     *
     * @param string $repartitionchargesviager
     *
     * @return Business
     */
    public function setRepartitionchargesviager($repartitionchargesviager)
    {
        $this->repartitionchargesviager = $repartitionchargesviager;

        return $this;
    }

    /**
     * Get repartitionchargesviager
     *
     * @return string
     */
    public function getRepartitionchargesviager()
    {
        return $this->repartitionchargesviager;
    }

    /**
     * Set inclushonoraires
     *
     * @param boolean $inclushonoraires
     *
     * @return Business
     */
    public function setInclushonoraires($inclushonoraires)
    {
        $this->inclushonoraires = $inclushonoraires;

        return $this;
    }

    /**
     * Get inclushonoraires
     *
     * @return boolean
     */
    public function getInclushonoraires()
    {
        return $this->inclushonoraires;
    }

    /**
     * Set modecalculhonoraire
     *
     * @param string $modecalculhonoraire
     *
     * @return Business
     */
    public function setModecalculhonoraire($modecalculhonoraire)
    {
        $this->modecalculhonoraire = $modecalculhonoraire;

        return $this;
    }

    /**
     * Get modecalculhonoraire
     *
     * @return string
     */
    public function getModecalculhonoraire()
    {
        return $this->modecalculhonoraire;
    }

    /**
     * Set montanthonoraires
     *
     * @param float $montanthonoraires
     *
     * @return Business
     */
    public function setMontanthonoraires($montanthonoraires)
    {
        $this->montanthonoraires = $montanthonoraires;

        return $this;
    }

    /**
     * Get montanthonoraires
     *
     * @return float
     */
    public function getMontanthonoraires()
    {
        return $this->montanthonoraires;
    }

    /**
     * Set chargecopropriete
     *
     * @param float $chargecopropriete
     *
     * @return Business
     */
    public function setChargecopropriete($chargecopropriete)
    {
        $this->chargecopropriete = $chargecopropriete;

        return $this;
    }

    /**
     * Get chargecopropriete
     *
     * @return float
     */
    public function getChargecopropriete()
    {
        return $this->chargecopropriete;
    }

    /**
     * Set taxefonciere
     *
     * @param float $taxefonciere
     *
     * @return Business
     */
    public function setTaxefonciere($taxefonciere)
    {
        $this->taxefonciere = $taxefonciere;

        return $this;
    }

    /**
     * Get taxefonciere
     *
     * @return float
     */
    public function getTaxefonciere()
    {
        return $this->taxefonciere;
    }

    /**
     * Set docdpe
     *
     * @param \Sadev\BusinessModelBundle\Entity\Fichier $docdpe
     *
     * @return Business
     */
    public function setDocdpe(\Sadev\BusinessModelBundle\Entity\Fichier $docdpe = null)
    {
        $this->docdpe = $docdpe;

        return $this;
    }

    /**
     * Get docdpe
     *
     * @return \Sadev\BusinessModelBundle\Entity\Fichier
     */
    public function getDocdpe()
    {
        return $this->docdpe;
    }

    /**
     * Set docplans
     *
     * @param \Sadev\BusinessModelBundle\Entity\Fichier $docplans
     *
     * @return Business
     */
    public function setDocplans(\Sadev\BusinessModelBundle\Entity\Fichier $docplans = null)
    {
        $this->docplans = $docplans;

        return $this;
    }

    /**
     * Get docplans
     *
     * @return \Sadev\BusinessModelBundle\Entity\Fichier
     */
    public function getDocplans()
    {
        return $this->docplans;
    }

    /**
     * Set docdiagnosticstechniques
     *
     * @param \Sadev\BusinessModelBundle\Entity\Fichier $docdiagnosticstechniques
     *
     * @return Business
     */
    public function setDocdiagnosticstechniques(\Sadev\BusinessModelBundle\Entity\Fichier $docdiagnosticstechniques = null)
    {
        $this->docdiagnosticstechniques = $docdiagnosticstechniques;

        return $this;
    }

    /**
     * Get docdiagnosticstechniques
     *
     * @return \Sadev\BusinessModelBundle\Entity\Fichier
     */
    public function getDocdiagnosticstechniques()
    {
        return $this->docdiagnosticstechniques;
    }

    /**
     * Set doccompromismandat
     *
     * @param \Sadev\BusinessModelBundle\Entity\Fichier $doccompromismandat
     *
     * @return Business
     */
    public function setDoccompromismandat(\Sadev\BusinessModelBundle\Entity\Fichier $doccompromismandat = null)
    {
        $this->doccompromismandat = $doccompromismandat;

        return $this;
    }

    /**
     * Get doccompromismandat
     *
     * @return \Sadev\BusinessModelBundle\Entity\Fichier
     */
    public function getDoccompromismandat()
    {
        return $this->doccompromismandat;
    }


    /**
     * @VirtualProperty
    **/
    public function dpeFile()
    {
        if($this->docdpe)
            return $this->docdpe->url();
        
        return null;

    }

    /**
     * @VirtualProperty
    **/
    public function plansFile()
    {
        if($this->docplans)
            return $this->docplans->url();
        
        return null;

    }

    /**
     * @VirtualProperty
    **/
    public function diagnosticstechniquesFile()
    {
        if($this->docdiagnosticstechniques)
            return $this->docdiagnosticstechniques->url();
        
        return null;
        
    }


    /**
     * @VirtualProperty
    **/
    public function compromismandatFile()
    {
        if($this->doccompromismandat)
            return $this->doccompromismandat->url();
        
        return null;

    }



    /**
     * Set nummandat
     *
     * @param integer $nummandat
     *
     * @return Business
     */
    public function setNummandat($nummandat)
    {
        $this->nummandat = $nummandat;

        return $this;
    }

    /**
     * Get nummandat
     *
     * @return integer
     */
    public function getNummandat()
    {
        return $this->nummandat;
    }

    /**
     * Set etagebien
     *
     * @param integer $etagebien
     *
     * @return Business
     */
    public function setEtagebien($etagebien)
    {
        $this->etagebien = $etagebien;

        return $this;
    }

    /**
     * Get etagebien
     *
     * @return integer
     */
    public function getEtagebien()
    {
        return $this->etagebien;
    }
}
