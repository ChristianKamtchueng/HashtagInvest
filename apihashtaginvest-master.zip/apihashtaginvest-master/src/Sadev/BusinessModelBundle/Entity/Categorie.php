<?php

namespace Sadev\BusinessModelBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

use JMS\Serializer\Annotation as Serializer;
use JMS\Serializer\Annotation\VirtualProperty;
use JMS\Serializer\Annotation\SerializedName;
use JMS\Serializer\Annotation\Type;


/**
 * Categorie
 *
 * @ORM\Table(name="categorie")
 * @ORM\Entity(repositoryClass="Sadev\BusinessModelBundle\Repository\CategorieRepository")
 * @ORM\HasLifecycleCallbacks()
 * @Serializer\ExclusionPolicy("ALL")
 */
class Categorie extends Data
{
    

    /**
     * @var string
     * @Serializer\Expose
     * @ORM\Column(name="nom", type="string", length=255)
     */
    private $nom;

    

    /**
     * @var string
     * @Serializer\Expose 
     * @ORM\Column(name="description", type="text", nullable=true)
     */
    private $description;

    /**
	* @ORM\ManyToOne(targetEntity="Sadev\BusinessModelBundle\Entity\Categorie", inversedBy="fils")
    * @ORM\JoinColumn(nullable=true)
    * @Serializer\Expose
	*/
	private $parent;
	
	
	// private $chemin;
	
	
	/**
    * @ORM\OneToMany(targetEntity="Sadev\BusinessModelBundle\Entity\Categorie", mappedBy="parent")
    * @Serializer\Expose
	*/
    private $fils; 


    /**
     * @var string
     * @Serializer\Expose
     * @ORM\Column(name="typeContent", type="string", length=255, nullable=false)
     */
    private $typeContent;
    

     /**
     * Constructor
     */
    public function __construct()
    {
		parent::__construct();
		
        $this->setTypeData('categorie');
    }


    /**
     * Set nom
     *
     * @param string $nom
     *
     * @return Categorie
     */
    public function setNom($nom)
    {
        $this->nom = $nom;

        return $this;
    }

    /**
     * Get nom
     *
     * @return string
     */
    public function getNom()
    {
        return $this->nom;
    }

    
    /**
     * Set description
     *
     * @param string $description
     *
     * @return Categorie
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set parent
     *
     * @param \Sadev\BusinessModelBundle\Entity\Categorie $parent
     *
     * @return Categorie
     */
    public function setParent(\Sadev\BusinessModelBundle\Entity\Categorie $parent = null)
    {
        if($parent != null && $parent->getId() != $this->id)
        $this->parent = $parent;
        else
        $this->parent = null;

        return $this;
    }

    /**
     * Get parent
     *
     * @return \Sadev\BusinessModelBundle\Entity\Categorie
     */
    public function getParent()
    {
        return $this->parent;
    }
	
	
    /**
    * @ORM\PrePersist
    */
    public function createChemin()
    {
		
		/* $nom = $this->getNom();
        $parent = $this->parent;
		
		while ($parent != null)
		{
			$nom = $parent->getNom().' / '.$nom ;
			$parent = $parent->getParent();
			// instructions à exécuter dans la boucle
        }
    
        $this->chemin = $nom;
		
		// return $nom; */
		
    }

    /**
    * @ORM\PreUpdate
    */
    public function updateChemin()
    {
       /*  //  Attention, l'évènement update n'est pas déclenché à la création d'une entité, mais seulement à sa modification : c'est parfaitement ce qu'on veut dans notre cas.
        //  il faut que vous ayez modifié au moins un attribut pour que l'EntityManager génère une requête et donc déclenche cet évènement.

		$nom = $this->getNom();
        $parent = $this->parent;
		
		while ($parent != null)
		{
			$nom = $parent->getNom().' / '.$nom ;
			$parent = $parent->getParent();
			// instructions à exécuter dans la boucle
        }
    
        $this->chemin = $nom;
		
		// return $nom; */
		
    }
	
    

    /**
     * Add fil
     *
     * @param \Sadev\BusinessModelBundle\Entity\Categorie $fil
     *
     * @return Categorie
     */
    public function addFil(\Sadev\BusinessModelBundle\Entity\Categorie $fil)
    {
        $this->fils[] = $fil;

        return $this;
    }

    /**
     * Remove fil
     *
     * @param \Sadev\BusinessModelBundle\Entity\Categorie $fil
     */
    public function removeFil(\Sadev\BusinessModelBundle\Entity\Categorie $fil)
    {
        $this->fils->removeElement($fil);
    }

    /**
     * Get fils
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getFils()
    {
        return $this->fils;
    }

    /**
     * @VirtualProperty
     * @SerializedName("chemin")
     * @Type("string")
    **/
    public function chemin()
    {
        //  Attention, l'évènement update n'est pas déclenché à la création d'une entité, mais seulement à sa modification : c'est parfaitement ce qu'on veut dans notre cas.
        //  il faut que vous ayez modifié au moins un attribut pour que l'EntityManager génère une requête et donc déclenche cet évènement.

		$nom = $this->getNom();
        $parent = $this->parent;
		
		while ($parent != null)
		{
			$nom = $parent->getNom().' / '.$nom ;
			$parent = $parent->getParent();
			// instructions à exécuter dans la boucle
        }
    
		
		return $nom;
		
    }

    /**
     * @VirtualProperty
     * @SerializedName("descendant")
     * @Type("array")
    **/
    public function descendant()
    {

		$descendants = array();
        $this->recursivechild($this, $descendants);
		
		return $descendants;
		
    }

    public function recursivechild($cat, &$descendants)
	{
		
		// $descendants[] = $elem->getId();
		
		if($cat->getFils() != null)
		{
			
			foreach( $cat->getFils() as $elem) {

                $descendants[] = $elem->getId();
                $this->recursivechild($elem, $descendants);
    
            }
			
        }
        
		
	}

    

    /**
     * Set typeContent
     *
     * @param string $typeContent
     *
     * @return Categorie
     */
    public function setTypeContent($typeContent)
    {

        if( in_array($typeContent, ['article', 'projet']))
        $this->typeContent = $typeContent;

        return $this;
    
    }

    /**
     * Get typeContent
     *
     * @return string
     */
    public function getTypeContent()
    {
        return $this->typeContent;
    }
}
