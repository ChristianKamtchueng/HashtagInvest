<?php

namespace Sadev\BusinessModelBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Vich\UploaderBundle\Mapping\Annotation as Vich;
use Symfony\Component\HttpFoundation\File\File;
use JMS\Serializer\Annotation\VirtualProperty;
use JMS\Serializer\Annotation as Serializer;
use Intervention\Image\ImageManager;

const URI_PREFIX = "uploadfiles/filemanager/"; // cette valeur doit être pareil uri_prefix   de  vich_uploader dans le fichier de configuration 

/**
 * Fichier
 *
 * @ORM\Table(name="fichier")
 * @ORM\Entity(repositoryClass="Sadev\BusinessModelBundle\Repository\FichierRepository")
 * @Vich\Uploadable
 * @ORM\HasLifecycleCallbacks
 * @Serializer\ExclusionPolicy("ALL")
 */
class Fichier
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * @Serializer\Expose
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255, unique=true, nullable=false)
     * @Serializer\Expose
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="mimeType", type="string", length=255, nullable=true)
     * @Serializer\Expose
     */
    private $mimeType;

    /**
     * @Vich\UploadableField(mapping="filemanager", fileNameProperty="name")
     * 
     * @var File
     *
     */
    private $filedata;

    /**
     * @var string
     *
     * @ORM\Column(name="size", type="decimal", precision=10, scale=0, nullable=true)
     * @Serializer\Expose
     */
    private $size;


    /**
     * @ORM\Column(type="datetime")
     *
     * @var \DateTime
    */
    private $createdAt;


    /**
    * @ORM\ManyToOne(targetEntity="Sadev\UserBundle\Entity\User", cascade={"persist"})
    * @ORM\JoinColumn(nullable=true)
    * @Serializer\Expose
    */
    protected $createBy;

    /**
     * @var string
     *
     * @ORM\Column(name="dossierRacine", type="string", length=255, nullable=true)
     */
    private $dossierRacine;


    /**
     * @var string
     *
     * @ORM\Column(name="label", type="string", length=255, nullable=true)
     * @Serializer\Expose
     */
    private $label;




    /**
    * Constructor
    */
    public function __construct()
    {
		// $this->createdAt = new \DateTime();
    }


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return Fichier
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set mimeType
     *
     * @param string $mimeType
     *
     * @return Fichier
     */
    public function setMimeType($mimeType)
    {
        $this->mimeType = $mimeType;

        return $this;
    }

    /**
     * Get mimeType
     *
     * @return string
     */
    public function getMimeType()
    {
        return $this->mimeType;
    }

    /**
     * @param File|\Symfony\Component\HttpFoundation\File\UploadedFile $filedata
     *
     * @return Fichier
     */
    public function setFiledata(File $filedata = null)
    {
        $this->filedata = $filedata;

        if ($filedata) {
            $this->size = $filedata->getSize();
            $this->mimeType = $filedata->getMimeType();
            $this->createdAt = new \DateTime();
        }

        return $this;
    }

    /**
     * @return File|null
     */
    public function getFiledata()
    {
        return $this->filedata;
    }

    /**
     * Set size
     *
     * @param string $size
     *
     * @return Fichier
     */
    public function setSize($size)
    {
        $this->size = $size;

        return $this;
    }

    /**
     * Get size
     *
     * @return string
     */
    public function getSize()
    {
        return $this->size;
    }

   
    


    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     *
     * @return Fichier
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    
    /**
     *
     * @return string
     */
    public function path()
    {
        $path = $this->createdAt->format('Y')."/"
        .$this->createdAt->format('m')."/"
        .$this->createdAt->format('d')."/"
        .$this->createdAt->format('H')."/"
        .$this->createdAt->format('i')."/";
        //.'dgrhryh'.$this->filedata->getExtension();

        if($this->dossierRacine === null)
        return $path;
        else
        return $this->dossierRacine.'/'.$path;

    }

    private function host()
    {
        if( isset($_SERVER['HTTP_HOST'])) {
            // $protocol = ( strstr($_SERVER['HTTP_HOST'],"127.0.0.1") || strstr($_SERVER['HTTP_HOST'],"localhost") ) ? 'http://' : 'https://';
            $protocol = ( strstr($_SERVER['HTTP_HOST'],"127.0.0.1") || strstr($_SERVER['HTTP_HOST'],"localhost") ) ? 'http://' : 'https://';
            return $protocol.$_SERVER['HTTP_HOST'].'/';
        } else 
        return "";
    }


    /**
     * @VirtualProperty
    **/
    public function url()
    {
        // $protocol = stripos($_SERVER['SERVER_PROTOCOL'],'https') === 0 ? 'https://' : 'http://';
        
        return $this->host().$this->generatePathName('');
    }

  

    public function generatePathName($prefixName)
    {
        return URI_PREFIX.$this->path().$prefixName.$this->name;
    }

    /**
     * @VirtualProperty
    **/
    public function thumb()
    {
    
        $dimension = 100;
        $targetPath = $this->generatePathName('');

        
        if(@is_array(getimagesize($targetPath))){
            $is_image = true;
        } else {
            $is_image = false;
        }

        // on se rassure que le fichier est une image
        if(!$is_image)
        return null;


        $folder = URI_PREFIX.'thumbs/'.$dimension.'x'.$dimension.'/';
        
        if (!is_dir($folder))
        mkdir($folder, 0777, true);
        
        $savePath = $folder.$this->name;
        

        // if( !file_exists ($targetPath)  ) {
        // $this->generateThumb(500, $folder, $targetPath, $savePath);
        $this->resize($dimension, $dimension, $targetPath, $savePath, '');
        // }

        return $this->host().$savePath;

    }



    public function resize($width, $heigth, $targetPath, $savePath, $filigranePath)
    {
       
        if(@is_array(getimagesize($targetPath))){
            $is_image = true;
        } else {
            $is_image = false;
        }

        // on se rassure que le fichier est une image valide
        //if(!$is_image || $this->ext() === 'jfif')
        if(!$is_image)
        return;

        $manager = new ImageManager(['driver' => 'gd']);
        
        if($filigranePath === '' || $filigranePath === null) {


            if($width !== $heigth) {

                $manager->make($targetPath)->resize($width, null, function ($constraint) {
                    $constraint->aspectRatio(); // Conserve le ratio largeur / hauteur
                    $constraint->upsize();
                })->save($savePath);

            } else {
                // cas d'une image pleine redimension sans tenir compte du ratio mais sans etirer l'image utiliser fit
                $manager->make($targetPath)->fit($width, $width)->save($savePath);
            }


        } else {

            /****************** combinaison de plusieurs images par exemple ajout du logo à l'image *********************/ 

            if($width !== $heigth) {

                 // On commence par générer l'instance correspondant à notre watermark
                $watermark = $manager->make($filigranePath)->fit(50, 50)->opacity(50);

                // On peut alors utiliser cette instance pour notre fonction insert
                $manager->make($targetPath)->resize(1025, null, function($constraint){
                    $constraint->aspectRatio(); // Conserve le ratio largeur / hauteur
                    $constraint->upsize(); // empêche l'image d'être agrandie
                })->insert($watermark, 'bottom-left', 10, 10)->save($savePath);

            } else {

                // cas d'une image pleine redimension sans tenir compte du ratio mais sans etirer l'image utiliser fit
                // On commence par générer l'instance correspondant à notre watermark
                $watermark = $manager->make($filigranePath)->fit(100, 100)->opacity(100); // plus l'opacité est petite plus elle se vera

                // On peut alors utiliser cette instance pour notre fonction insert
                $manager->make($targetPath)->fit($width, $width)->insert($watermark, 'bottom-right', 10, 10)->save($savePath);

            }

            /****************** combinaison de plusieurs images par expleme ajout du logo à l'image *********************/ 
        }

        // mise à jour de la taille du fichier après redimensionnement
        if($width !== $heigth)
        $this->size = filesize($savePath);

    }

    /**
     * @VirtualProperty
    **/
    public function ext()
    {
        return pathinfo($this->name, PATHINFO_EXTENSION);
    }

    /**
     * Set createBy
     *
     * @param \Sadev\UserBundle\Entity\User $createBy
     *
     * @return Date
     */
    public function setCreateBy(\Sadev\UserBundle\Entity\User $createBy = null)
    {
        $this->createBy = $createBy;

        return $this;
    }

    /**
     * Get createBy
     *
     * @return \Sadev\UserBundle\Entity\User
     */
    public function getCreateBy()
    {
        return $this->createBy;
    }



    /**
     * Set dossierRacine
     *
     * @param string $dossierRacine
     *
     * @return Fichier
     */
    public function setDossierRacine($dossierRacine)
    {
        $this->dossierRacine = $dossierRacine;

        return $this;
    }

    /**
     * Get dossierRacine
     *
     * @return string
     */
    public function getDossierRacine()
    {
        return $this->dossierRacine;
    }

    /**
     * Set label
     *
     * @param string $label
     *
     * @return Fichier
     */
    public function setLabel($label)
    {
        $this->label = $label;

        return $this;
    }

    /**
     * Get label
     *
     * @return string
     */
    public function getLabel()
    {
        return $this->label;
    }

   
}
