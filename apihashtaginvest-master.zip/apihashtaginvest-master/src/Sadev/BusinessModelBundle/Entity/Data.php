<?php

namespace Sadev\BusinessModelBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use JMS\Serializer\Annotation\Type;
use JMS\Serializer\Annotation as Serializer;

/**
 * Data
 *
 * @ORM\Table(name="data")
 * @ORM\Entity(repositoryClass="Sadev\BusinessModelBundle\Repository\DataRepository")
 * @ORM\HasLifecycleCallbacks()
 * @ORM\InheritanceType("JOINED")
 * @ORM\DiscriminatorColumn(name="discriminator", type="string")
 * @ORM\DiscriminatorMap({"data"="Data", "categorie"="Sadev\BusinessModelBundle\Entity\Categorie", "publication"="Sadev\BusinessModelBundle\Entity\Publication", "comment"="Sadev\BusinessModelBundle\Entity\Comment", "menu"="Sadev\BusinessModelBundle\Entity\Menu", "page"="Sadev\BusinessModelBundle\Entity\Page",  "article"="Sadev\BusinessModelBundle\Entity\Article",  "project"="Sadev\BusinessModelBundle\Entity\Project",  "message"="Sadev\BusinessModelBundle\Entity\Message", "activity"="Sadev\BusinessModelBundle\Entity\Activity", "business"="Sadev\BusinessModelBundle\Entity\Business", "answer"="Sadev\BusinessModelBundle\Entity\Answer", "devis"="Sadev\BusinessModelBundle\Entity\Devis", "devispayment"="Sadev\BusinessModelBundle\Entity\DevisPayment", "soubscriptionpayment"="Sadev\BusinessModelBundle\Entity\SoubscriptionPayment"})
 * @Serializer\ExclusionPolicy("ALL")
 */
class Data 
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * @Serializer\Expose
     */
    protected $id;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="dateCreate", type="datetime", nullable=true)
     * @Type("DateTime<'Y-m-d H:i'>")
     * @Serializer\Expose
     */
    protected $dateCreate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="dateModif", type="datetime", nullable=true)
     * @Type("DateTime<'Y-m-d H:i'>")
     * @Serializer\Expose
     */
    protected $dateModif;

    /**
    * @ORM\ManyToOne(targetEntity="Sadev\UserBundle\Entity\User", cascade={"persist"})
    * @ORM\JoinColumn(nullable=true)
    * @Serializer\Expose
    */
    protected $createBy;

    /** 
     * @var string
     *
     * @ORM\Column(name="TypeData", type="string", length=255)
     * 
     */
    private $typeData;


    /**
     * Constructor
     */
    public function __construct()
    {
		$this->dateCreate = new \DateTime();
    }

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set dateCreate
     *
     * @param \DateTime $dateCreate
     *
     * @return Data
     */
    public function setDateCreate($dateCreate)
    {
        $this->dateCreate = $dateCreate;

        return $this;
    }

    /**
     * Get dateCreate
     *
     * @return \DateTime
     */
    public function getDateCreate()
    {
        return $this->dateCreate;
    }

    /**
     * Set dateModif
     *
     * @param \DateTime $dateModif
     *
     * @return Data
     */
    public function setDateModif($dateModif)
    {
        $this->dateModif = $dateModif;

        return $this;
    }

    /**
     * Get dateModif
     *
     * @return \DateTime
     */
    public function getDateModif()
    {
        return $this->dateModif;
    }


    /**
     * Set createBy
     *
     * @param \Sadev\UserBundle\Entity\User $createBy
     *
     * @return Date
     */
    public function setCreateBy(\Sadev\UserBundle\Entity\User $createBy = null)
    {
        $this->createBy = $createBy;

        return $this;
    }

    /**
     * Get createBy
     *
     * @return \Sadev\UserBundle\Entity\User
     */
    public function getCreateBy()
    {
        return $this->createBy;
    }

    /**
     * Set typeData
     *
     * @param string $typeData
     *
     * @return Data
     */
    public function setTypeData($typeData)
    {
        $this->typeData = $typeData;

        return $this;
    }

    /**
     * Get typeData
     *
     * @return string
     */
    public function getTypeData()
    {
        return $this->typeData;
    }


    /**
    * @ORM\PreUpdate
    */
    public function updateDate()
    {
		//  Attention, l'évènement update n'est pas déclenché à la création d'une entité, mais seulement à sa modification : c'est parfaitement ce qu'on veut dans notre cas.
        //  il faut que vous ayez modifié au moins un attribut pour que l'EntityManager génère une requête et donc déclenche cet évènement.
        $this->dateModif = new \Datetime();
		
		// return $nom;
		
    }

}

