<?php

namespace Sadev\BusinessModelBundle\Entity;


/**
 * Setting
 *
 */
class Setting //la suppression d'un champ entraine une erreur lors de la deserialization car la propriete est introuvable donc eviter de supprimer les propriete deja serialize
{
    

    private $deleguePoste;

    private $executiveEntity;

    private $departmentEntity;

    private $mulatoPersonnelAccount;
	
	/**
     * Constructor
     */
    public function __construct()
    {
		
    }
	
   
    public function setDeleguePoste($deleguePoste)
    {
        $this->deleguePoste = $deleguePoste;

        return $this;
    }

    
    public function getDeleguePoste()
    {
        return $this->deleguePoste;
    }


    
    public function setExecutiveEntity($executiveEntity)
    {
        $this->executiveEntity = $executiveEntity;

        return $this;
    }

  
    public function getExecutiveEntity()
    {
        return $this->executiveEntity;
    }


    public function setDepartmentEntity($departmentEntity)
    {
        $this->departmentEntity = $departmentEntity;

        return $this;
    }

  
    public function getDepartmentEntity()
    {
        return $this->departmentEntity;
    }


    public function setMulatoPersonnelAccount($mulatoPersonnelAccount)
    {
        $this->mulatoPersonnelAccount = $mulatoPersonnelAccount;

        return $this;
    }

    
    public function getMulatoPersonnelAccount()
    {
        return $this->mulatoPersonnelAccount;
    }


    


    public function file()
    {
        return "setting/general.txt";
    }

    public function save()
    {
		$store = serialize ($this);
		file_put_contents($this->file(), $store);
    }
	
	
	
}

