<?php

namespace Sadev\BusinessModelBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * SoubscriptionPayment
 *
 * @ORM\Table(name="soubscription_payment")
 * @ORM\Entity(repositoryClass="Sadev\BusinessModelBundle\Repository\SoubscriptionPaymentRepository")
 */
class SoubscriptionPayment extends Data
{
    
    

    /**
     * @var float
     *
     * @ORM\Column(name="amount", type="float")
     */
    private $amount;

    /**
     * @var string
     *
     * @ORM\Column(name="formule", type="string", length=255)
     */
    private $formule;

    /**
     * @var string
     *
     * @ORM\Column(name="period", type="string", length=255)
     */
    private $period;

    /**
     * @var string
     *
     * @ORM\Column(name="metadata", type="text", nullable=true)
     */
    private $metadata;


    /**
	* @ORM\ManyToOne(targetEntity="Sadev\UserBundle\Entity\User", inversedBy="soubscriptionpayment")
    * @ORM\JoinColumn(nullable=false)
	*/
	private $user;

    
    /**
     * Constructor
     */
    public function __construct()
    {
		parent::__construct();
        $this->setTypeData('soubscriptionpayment');
    }

    /**
     * Set amount
     *
     * @param float $amount
     *
     * @return SoubscriptionPayment
     */
    public function setAmount($amount)
    {
        $this->amount = $amount;

        return $this;
    }

    /**
     * Get amount
     *
     * @return float
     */
    public function getAmount()
    {
        return $this->amount;
    }

    /**
     * Set formule
     *
     * @param string $formule
     *
     * @return SoubscriptionPayment
     */
    public function setFormule($formule)
    {
        $this->formule = $formule;

        return $this;
    }

    /**
     * Get formule
     *
     * @return string
     */
    public function getFormule()
    {
        return $this->formule;
    }

    /**
     * Set period
     *
     * @param string $period
     *
     * @return SoubscriptionPayment
     */
    public function setPeriod($period)
    {
        $this->period = $period;

        return $this;
    }

    /**
     * Get period
     *
     * @return string
     */
    public function getPeriod()
    {
        return $this->period;
    }

    /**
     * Set metadata
     *
     * @param string $metadata
     *
     * @return SoubscriptionPayment
     */
    public function setMetadata($metadata)
    {
        $this->metadata = $metadata;

        return $this;
    }

    /**
     * Get metadata
     *
     * @return string
     */
    public function getMetadata()
    {
        return $this->metadata;
    }

    /**
     * Set user
     *
     * @param \Sadev\UserBundle\Entity\User $user
     *
     * @return SoubscriptionPayment
     */
    public function setUser(\Sadev\UserBundle\Entity\User $user)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user
     *
     * @return \Sadev\UserBundle\Entity\User
     */
    public function getUser()
    {
        return $this->user;
    }
}
