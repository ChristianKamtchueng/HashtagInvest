<?php

namespace Sadev\BusinessModelBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use JMS\Serializer\Annotation\VirtualProperty;
use JMS\Serializer\Annotation as Serializer;

/**
 * Menu
 *
 * @ORM\Table(name="menu")
 * @ORM\Entity(repositoryClass="Sadev\BusinessModelBundle\Repository\MenuRepository")
 * @Serializer\ExclusionPolicy("ALL")
 */
class Menu extends Data
{
  
    /**
     * @var string
     *
     * @ORM\Column(name="nom", type="string", length=255, unique=true)
     * @Serializer\Expose
     */
    private $nom;

    /**
     * @var string
     *
     * @ORM\Column(name="items", type="text", nullable=true)
     * @Serializer\Expose
     */
    private $items;




     /**
     * Constructor
     */
    public function __construct()
    {
		parent::__construct();
		
        $this->setTypeData('menu');
    }

    /**
     * Set nom
     *
     * @param string $nom
     *
     * @return Menu
     */
    public function setNom($nom)
    {
        $this->nom = $nom;

        return $this;
    }

    /**
     * Get nom
     *
     * @return string
     */
    public function getNom()
    {
        return $this->nom;
    }



    

    

    /**
     * Set items
     *
     * @param string $items
     *
     * @return Menu
     */
    public function setItems($items)
    {
        $this->items = $items;

        return $this;
    }

    /**
     * Get items
     *
     * @return string
     */
    public function getItems()
    {
        return $this->items;
    }
}
