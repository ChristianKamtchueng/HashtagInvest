<?php

namespace Sadev\BusinessModelBundle\Entity;


class MenuItem
{
    
    
    private $name;
    
    private $id;

    private $childrens;

    private $options;


    

    /**
     * Set name
     *
     * @param string $name
     *
     * @return MenuItem
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }


    /**
     * Set id
     *
     * @param string $id
     *
     * @return MenuItem
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get id
     *
     * @return string
     */
    public function getId()
    {
        return $this->id;
    }

   
    /**
     * Set options
     *
     * @param string $options
     *
     * @return MenuItem
     */
    public function setOptions($options)
    {
        $this->options = $options;

        return $this;
    }

    /**
     * Get options
     *
     * @return string
     */
    public function getOptions()
    {
        return $this->options;
    }

    /**
     * Set childrens
     *
     * @param string $childrens
     *
     * @return MenuItem
     */
    public function setChildrens($childrens)
    {
        $this->childrens = $childrens;

        return $this;
    }

    /**
     * Get childrens
     *
     * @return string
     */
    public function getChildrens()
    {
        return $this->childrens;
    }
}

