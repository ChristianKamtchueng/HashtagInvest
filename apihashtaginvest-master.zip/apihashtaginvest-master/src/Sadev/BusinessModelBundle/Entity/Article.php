<?php

namespace Sadev\BusinessModelBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use JMS\Serializer\Annotation\Type;
use JMS\Serializer\Annotation as Serializer;
use JMS\Serializer\Annotation\VirtualProperty;

/**
 * Article
 *
 * @ORM\Table(name="article")
 * @ORM\Entity(repositoryClass="Sadev\BusinessModelBundle\Repository\ArticleRepository")
 * @Serializer\ExclusionPolicy("ALL")
 */
class Article extends Publication
{
    
    
   
    /**
    * @ORM\ManyToMany(targetEntity="Sadev\BusinessModelBundle\Entity\Categorie",  cascade={"persist"})
    * @Serializer\Expose
	*/
	private $categories;
	  
      
    /**
     * @ORM\OneToMany(targetEntity="Sadev\BusinessModelBundle\Entity\Comment", mappedBy="article")
     * @Serializer\Expose
    */
    private $comments; 

     /**
     * @var string
     * @Serializer\Expose
     * @ORM\Column(name="videoYoutube", type="string", length=255, nullable=true)
     */
    private $videoYoutube;


    /**
     * Constructor
     */
    public function __construct()
    {
		parent::__construct();
		
        $this->setTypeData('article');
    }


    /**
     * Add category
     *
     * @param \Sadev\BusinessModelBundle\Entity\Categorie $category
     *
     * @return Publication
     */
    public function addCategory(\Sadev\BusinessModelBundle\Entity\Categorie $category)
    {
        $this->categories[] = $category;

        return $this;
    }

    /**
     * Remove category
     *
     * @param \Sadev\BusinessModelBundle\Entity\Categorie $category
     */
    public function removeCategory(\Sadev\BusinessModelBundle\Entity\Categorie $category)
    {
        $this->categories->removeElement($category);
    }

    /**
     * Get categories
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getCategories()
    {
		return $this->categories;
    }

	

    /**
     * Add comment
     *
     * @param \Sadev\BusinessModelBundle\Entity\Comment $comment
     *
     * @return Publication
     */
    public function addComment(\Sadev\BusinessModelBundle\Entity\Comment $comment)
    {
        $this->comments[] = $comment;

        return $this;
    }

    /**
     * Remove comment
     *
     * @param \Sadev\BusinessModelBundle\Entity\Comment $comment
     */
    public function removeComment(\Sadev\BusinessModelBundle\Entity\Comment $comment)
    {
        $this->comments->removeElement($comment);
    }

    /**
     * Get comments
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getComments()
    {
	    return $this->comments;
    }


    /**
     * Set videoYoutube
     *
     * @param string $videoYoutube
     *
     * @return Article
     */
    public function setVideoYoutube($videoYoutube)
    {
        $this->videoYoutube = $videoYoutube;

        return $this;
    }

    /**
     * Get videoYoutube
     *
     * @return string
     */
    public function getVideoYoutube()
    {
        return $this->videoYoutube;
    }


}
