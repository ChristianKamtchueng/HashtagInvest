<?php

namespace Sadev\BusinessModelBundle\Entity;


class PageSetting
{
    
    private $apropos;

   
    private $vision;

   
    private $mission;

    
    private $actionnariat;

    private $programme;

    
    private $egibilite;

    private $souscription;

    private $reclamation;

    private $promotion;

    private $economie;

    private $organisation;

    private $creation;


    

    
    public function setApropos($apropos)
    {
        $this->apropos = $apropos;

        return $this;
    }

   
    public function getApropos()
    {
        return $this->apropos;
    }

    
    public function setVision($vision)
    {
        $this->vision = $vision;

        return $this;
    }

    
    public function getVision()
    {
        return $this->vision;
    }

    
    public function setMission($mission)
    {
        $this->mission = $mission;

        return $this;
    }

    
    public function getMission()
    {
        return $this->mission;
    }

   
    public function setActionnariat($actionnariat)
    {
        $this->actionnariat = $actionnariat;

        return $this;
    }

   
    public function getActionnariat()
    {
        return $this->actionnariat;
    }

    
    public function setProgramme($programme)
    {
        $this->programme = $programme;

        return $this;
    }

    public function getProgramme()
    {
        return $this->programme;
    }

   
    public function setEgibilite($egibilite)
    {
        $this->egibilite = $egibilite;

        return $this;
    }

    
    public function getEgibilite()
    {
        return $this->egibilite;
    }

    
    public function setSouscription($souscription)
    {
        $this->souscription = $souscription;

        return $this;
    }

    
    public function getSouscription()
    {
        return $this->souscription;
    }

    
    public function setReclamation($reclamation)
    {
        $this->reclamation = $reclamation;

        return $this;
    }

    
    public function getReclamation()
    {
        return $this->reclamation;
    }

    public function setPromotion($promotion)
    {
        $this->promotion = $promotion;

        return $this;
    }

    
    public function getPromotion()
    {
        return $this->promotion;
    }

    public function setEconomie($economie)
    {
        $this->economie = $economie;

        return $this;
    }


    
    public function getEconomie()
    {
        return $this->economie;
    }


    public function setOrganisation($organisation)
    {
        $this->organisation = $organisation;

        return $this;
    }

    public function getOrganisation()
    {
        return $this->organisation;
    }


    public function setCreation($creation)
    {
        $this->creation = $creation;

        return $this;
    }

    public function getCreation()
    {
        return $this->creation;
    }

   


    public function file()
    {
        $dir ='settings';
        if(!is_dir($dir)) {
            mkdir($dir); // si le dossier setting n'existe pas on le créer
            chmod($dir, 0777);
        }

        $file = $dir.='/page.txt';
    
       /* if(!is_file($file)) {
            $fp = fopen($file, 'w');
            fwrite($fp, '');
            fclose($fp);
            chmod($file, 0777);
        } */

        return $file;

    }

    public function save()
    {
		$store = serialize ($this);
		file_put_contents($this->file(), $store, true);
    }

    public function hydrate()
    {

        $setting = new PageSetting;

        if ( file_exists($this->file())) {
            
            $store = file_get_contents($this->file());
            $setting = unserialize($store);
        }

        return  $setting;

    }
}

