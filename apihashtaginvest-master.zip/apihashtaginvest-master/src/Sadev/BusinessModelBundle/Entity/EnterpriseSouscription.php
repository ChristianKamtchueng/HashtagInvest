<?php

namespace Sadev\BusinessModelBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * EnterpriseSouscription
 *
 * @ORM\Table(name="enterprise_souscription")
 * @ORM\Entity(repositoryClass="Sadev\BusinessModelBundle\Repository\EnterpriseSouscriptionRepository")
 */
class EnterpriseSouscription extends Souscription
{
    
    /**
     * @var string
     *
     * @ORM\Column(name="nameEnterprise", type="string", length=255)
     */
    private $nameEnterprise;

    /**
     * @var string
     *
     * @ORM\Column(name="status", type="string", length=255)
     */
    private $status;

    /**
     * @var string
     *
     * @ORM\Column(name="niu", type="string", length=255, nullable=true, unique=true)
     */
    private $niu;

    /**
     * @var string
     *
     * @ORM\Column(name="irccm", type="string", length=255, unique=true)
     */
    private $irccm;

    /**
     * @var string
     *
     * @ORM\Column(name="secteur", type="string", length=255)
     */
    private $secteur;

    /**
     * @var string
     *
     * @ORM\Column(name="nameRep", type="string", length=255)
     */
    private $nameRep;

    /**
     * @var string
     *
     * @ORM\Column(name="sexeRep", type="string", length=255)
     */
    private $sexeRep;

    /**
     * @var string
     *
     * @ORM\Column(name="nationalityRep", type="string", length=255)
     */
    private $nationalityRep;

    /**
     * @var string
     *
     * @ORM\Column(name="residenceRep", type="string", length=255)
     */
    private $residenceRep;

    /**
     * @var string
     *
     * @ORM\Column(name="localisationRep", type="string", length=255)
     */
    private $localisationRep;

    /**
     * @var string
     *
     * @ORM\Column(name="bpRep", type="string", length=255, nullable=true)
     */
    private $bpRep;

    /**
     * @var string
     *
     * @ORM\Column(name="gsmRep", type="string", length=255, nullable=true)
     */
    private $gsmRep;

    /**
     * @var string
     *
     * @ORM\Column(name="emailRep", type="string", length=255, nullable=true)
     */
    private $emailRep;


    /**
     * Constructor
     */
    public function __construct()
    {
		parent::__construct();
        $this->setTypeSouscription('enterprise');
    }


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nameEnterprise
     *
     * @param string $nameEnterprise
     *
     * @return EnterpriseSouscription
     */
    public function setNameEnterprise($nameEnterprise)
    {
        $this->nameEnterprise = $nameEnterprise;

        return $this;
    }

    /**
     * Get nameEnterprise
     *
     * @return string
     */
    public function getNameEnterprise()
    {
        return $this->nameEnterprise;
    }

    /**
     * Set status
     *
     * @param string $status
     *
     * @return EnterpriseSouscription
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status
     *
     * @return string
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Set niu
     *
     * @param string $niu
     *
     * @return EnterpriseSouscription
     */
    public function setNiu($niu)
    {
        $this->niu = $niu;

        return $this;
    }

    /**
     * Get niu
     *
     * @return string
     */
    public function getNiu()
    {
        return $this->niu;
    }

    /**
     * Set irccm
     *
     * @param string $irccm
     *
     * @return EnterpriseSouscription
     */
    public function setIrccm($irccm)
    {
        $this->irccm = $irccm;

        return $this;
    }

    /**
     * Get irccm
     *
     * @return string
     */
    public function getIrccm()
    {
        return $this->irccm;
    }

    /**
     * Set secteur
     *
     * @param string $secteur
     *
     * @return EnterpriseSouscription
     */
    public function setSecteur($secteur)
    {
        $this->secteur = $secteur;

        return $this;
    }

    /**
     * Get secteur
     *
     * @return string
     */
    public function getSecteur()
    {
        return $this->secteur;
    }

    /**
     * Set nameRep
     *
     * @param string $nameRep
     *
     * @return EnterpriseSouscription
     */
    public function setNameRep($nameRep)
    {
        $this->nameRep = $nameRep;

        return $this;
    }

    /**
     * Get nameRep
     *
     * @return string
     */
    public function getNameRep()
    {
        return $this->nameRep;
    }

    /**
     * Set sexeRep
     *
     * @param string $sexeRep
     *
     * @return EnterpriseSouscription
     */
    public function setSexeRep($sexeRep)
    {
        if(in_array($sexeRep, ['homme', 'femme']))
        $this->sexeRep = $sexeRep;

        return $this;
    }

    /**
     * Get sexeRep
     *
     * @return string
     */
    public function getSexeRep()
    {
        return $this->sexeRep;
    }

    /**
     * Set nationalityRep
     *
     * @param string $nationalityRep
     *
     * @return EnterpriseSouscription
     */
    public function setNationalityRep($nationalityRep)
    {
        $this->nationalityRep = $nationalityRep;

        return $this;
    }

    /**
     * Get nationalityRep
     *
     * @return string
     */
    public function getNationalityRep()
    {
        return $this->nationalityRep;
    }

    /**
     * Set residenceRep
     *
     * @param string $residenceRep
     *
     * @return EnterpriseSouscription
     */
    public function setResidenceRep($residenceRep)
    {
        $this->residenceRep = $residenceRep;

        return $this;
    }

    /**
     * Get residenceRep
     *
     * @return string
     */
    public function getResidenceRep()
    {
        return $this->residenceRep;
    }

    /**
     * Set localisationRep
     *
     * @param string $localisationRep
     *
     * @return EnterpriseSouscription
     */
    public function setLocalisationRep($localisationRep)
    {
        $this->localisationRep = $localisationRep;

        return $this;
    }

    /**
     * Get localisationRep
     *
     * @return string
     */
    public function getLocalisationRep()
    {
        return $this->localisationRep;
    }

    /**
     * Set bpRep
     *
     * @param string $bpRep
     *
     * @return EnterpriseSouscription
     */
    public function setBpRep($bpRep)
    {
        $this->bpRep = $bpRep;

        return $this;
    }

    /**
     * Get bpRep
     *
     * @return string
     */
    public function getBpRep()
    {
        return $this->bpRep;
    }

    /**
     * Set gsmRep
     *
     * @param string $gsmRep
     *
     * @return EnterpriseSouscription
     */
    public function setGsmRep($gsmRep)
    {
        $this->gsmRep = $gsmRep;

        return $this;
    }

    /**
     * Get gsmRep
     *
     * @return string
     */
    public function getGsmRep()
    {
        return $this->gsmRep;
    }

    /**
     * Set emailRep
     *
     * @param string $emailRep
     *
     * @return EnterpriseSouscription
     */
    public function setEmailRep($emailRep)
    {
        $this->emailRep = $emailRep;

        return $this;
    }

    /**
     * Get emailRep
     *
     * @return string
     */
    public function getEmailRep()
    {
        return $this->emailRep;
    }
}

