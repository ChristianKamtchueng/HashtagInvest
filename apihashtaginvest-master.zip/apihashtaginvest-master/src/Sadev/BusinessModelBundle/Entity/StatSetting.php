<?php

namespace Sadev\BusinessModelBundle\Entity;


class StatSetting
{
    

    private $investisseurs;

    private $programmes;

    private $projets;


    public function setInvestisseurs($investisseurs)
    {
        $this->investisseurs = $investisseurs;

        return $this;
    }

    
    public function getInvestisseurs()
    {
        return $this->investisseurs;
    }

   
    public function setProgrammes($programmes)
    {
        $this->programmes = $programmes;

        return $this;
    }

    
    public function getProgrammes()
    {
        return $this->programmes;
    }

   
    public function setProjets($projets)
    {
        $this->projets = $projets;

        return $this;
    }

   
    public function getProjets()
    {
        return $this->projets;
    }

    public function file()
    {
        $dir ='settings';
        if(!is_dir($dir)) {
            mkdir($dir); // si le dossier setting n'existe pas on le créer
            chmod($dir, 0777);
        }

        $file = $dir.='/state.txt';
    
       /* if(!is_file($file)) {
            $fp = fopen($file, 'w');
            fwrite($fp, '');
            fclose($fp);
            chmod($file, 0777);
        } */

        return $file;

    }

    public function save()
    {
		$store = serialize ($this);
		file_put_contents($this->file(), $store, true);
    }

    public function hydrate()
    {

        $setting = new StatSetting;

        if ( file_exists($this->file())) {
            
            $store = file_get_contents($this->file());
            $setting = unserialize($store);
        }

        return  $setting;

    }

}

