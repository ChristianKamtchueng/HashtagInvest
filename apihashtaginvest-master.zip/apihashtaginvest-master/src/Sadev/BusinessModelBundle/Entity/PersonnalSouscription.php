<?php

namespace Sadev\BusinessModelBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use JMS\Serializer\Annotation\Type;

/**
 * PersonnalSouscription
 *
 * @ORM\Table(name="personnal_souscription")
 * @ORM\Entity(repositoryClass="Sadev\BusinessModelBundle\Repository\PersonnalSouscriptionRepository")
 */
class PersonnalSouscription extends Souscription
{
    
    /**
     * @var string
     *
     * @ORM\Column(name="nom", type="string", length=255)
     */
    private $nom;

    /**
     * @var string
     *
     * @ORM\Column(name="prenom", type="string", length=255)
     */
    private $prenom;

    /**
     * @var \DateTime
     * @Assert\GreaterThanOrEqual("-120 years")
     * @ORM\Column(name="birthday", type="datetime")
     * @Type("DateTime<'Y-m-d'>")
     */
    private $birthday;

    /**
     * @var string
     *
     * @ORM\Column(name="birthplace", type="string", length=255)
     */
    private $birthplace;

    /**
     * @var string
     *
     * @ORM\Column(name="sexe", type="string", length=255)
     */
    private $sexe;

    /**
     * @var string
     *
     * @ORM\Column(name="nationality", type="string", length=255)
     */
    private $nationality;

    /**
     * @var string
     *
     * @ORM\Column(name="profession", type="string", length=255)
     */
    private $profession;

    /**
     * @var string
     *
     * @ORM\Column(name="residence", type="string", length=255)
     */
    private $residence;

    /**
     * @var string
     *
     * @ORM\Column(name="idCniOrPass", type="string", length=255, unique=true)
     */
    private $idCniOrPass;

    /**
     * @var string
     *
     * @ORM\Column(name="bp", type="string", length=255, nullable=true)
     */
    private $bp;

    /**
     * @var string
     *
     * @ORM\Column(name="gsm", type="string", length=255, nullable=true)
     */
    private $gsm;

    /**
     * @var string
     *
     * @ORM\Column(name="email", type="string", length=255, nullable=true, unique=true)
     */
    private $email;

    /**
     * @var string
     *
     * @ORM\Column(name="nameCo", type="string", length=255, nullable=true)
     */
    private $nameCo;

    /**
     * @var string
     *
     * @ORM\Column(name="professionCo", type="string", length=255, nullable=true)
     */
    private $professionCo;

    /**
     * @var string
     *
     * @ORM\Column(name="numCniOrPassCo", type="string", length=255, nullable=true, unique=true)
     */
    private $numCniOrPassCo;

    /**
     * @var string
     *
     * @ORM\Column(name="residenceCo", type="string", length=255, nullable=true)
     */
    private $residenceCo;

    /**
     * @var string
     *
     * @ORM\Column(name="bpCo", type="string", length=255, nullable=true)
     */
    private $bpCo;

    /**
     * @var string
     *
     * @ORM\Column(name="gsmCo", type="string", length=255, nullable=true)
     */
    private $gsmCo;

    /**
     * @var string
     *
     * @ORM\Column(name="emailCo", type="string", length=255, nullable=true)
     */
    private $emailCo;


    /**
     * Constructor
     */
    public function __construct()
    {
		parent::__construct();
        $this->setTypeSouscription('personnal');
    }


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nom
     *
     * @param string $nom
     *
     * @return PersonnalSouscription
     */
    public function setNom($nom)
    {
        $this->nom = $nom;

        return $this;
    }

    /**
     * Get nom
     *
     * @return string
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Set prenom
     *
     * @param string $prenom
     *
     * @return PersonnalSouscription
     */
    public function setPrenom($prenom)
    {
        $this->prenom = $prenom;

        return $this;
    }

    /**
     * Get prenom
     *
     * @return string
     */
    public function getPrenom()
    {
        return $this->prenom;
    }

    /**
     * Set birthday
     *
     * @param \DateTime $birthday
     *
     * @return PersonnalSouscription
     */
    public function setBirthday($birthday)
    {
        $this->birthday = $birthday;

        return $this;
    }

    /**
     * Get birthday
     *
     * @return \DateTime
     */
    public function getBirthday()
    {
        return $this->birthday;
    }

    /**
     * Set birthplace
     *
     * @param string $birthplace
     *
     * @return PersonnalSouscription
     */
    public function setBirthplace($birthplace)
    {
        $this->birthplace = $birthplace;

        return $this;
    }

    /**
     * Get birthplace
     *
     * @return string
     */
    public function getBirthplace()
    {
        return $this->birthplace;
    }

    /**
     * Set sexe
     *
     * @param string $sexe
     *
     * @return PersonnalSouscription
     */
    public function setSexe($sexe)
    {

        if(in_array($sexe, ['homme', 'femme']))
        $this->sexe = $sexe;

        return $this;

    }

    /**
     * Get sexe
     *
     * @return string
     */
    public function getSexe()
    {
        return $this->sexe;
    }

    /**
     * Set nationality
     *
     * @param string $nationality
     *
     * @return PersonnalSouscription
     */
    public function setNationality($nationality)
    {
        $this->nationality = $nationality;

        return $this;
    }

    /**
     * Get nationality
     *
     * @return string
     */
    public function getNationality()
    {
        return $this->nationality;
    }

    /**
     * Set profession
     *
     * @param string $profession
     *
     * @return PersonnalSouscription
     */
    public function setProfession($profession)
    {
        $this->profession = $profession;

        return $this;
    }

    /**
     * Get profession
     *
     * @return string
     */
    public function getProfession()
    {
        return $this->profession;
    }

    /**
     * Set residence
     *
     * @param string $residence
     *
     * @return PersonnalSouscription
     */
    public function setResidence($residence)
    {
        $this->residence = $residence;

        return $this;
    }

    /**
     * Get residence
     *
     * @return string
     */
    public function getResidence()
    {
        return $this->residence;
    }

    /**
     * Set idCniOrPass
     *
     * @param string $idCniOrPass
     *
     * @return PersonnalSouscription
     */
    public function setIdCniOrPass($idCniOrPass)
    {
        $this->idCniOrPass = $idCniOrPass;

        return $this;
    }

    /**
     * Get idCniOrPass
     *
     * @return string
     */
    public function getIdCniOrPass()
    {
        return $this->idCniOrPass;
    }

    /**
     * Set bp
     *
     * @param string $bp
     *
     * @return PersonnalSouscription
     */
    public function setBp($bp)
    {
        $this->bp = $bp;

        return $this;
    }

    /**
     * Get bp
     *
     * @return string
     */
    public function getBp()
    {
        return $this->bp;
    }

    /**
     * Set gsm
     *
     * @param string $gsm
     *
     * @return PersonnalSouscription
     */
    public function setGsm($gsm)
    {
        $this->gsm = $gsm;

        return $this;
    }

    /**
     * Get gsm
     *
     * @return string
     */
    public function getGsm()
    {
        return $this->gsm;
    }

    /**
     * Set email
     *
     * @param string $email
     *
     * @return PersonnalSouscription
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set nameCo
     *
     * @param string $nameCo
     *
     * @return PersonnalSouscription
     */
    public function setNameCo($nameCo)
    {
        $this->nameCo = $nameCo;

        return $this;
    }

    /**
     * Get nameCo
     *
     * @return string
     */
    public function getNameCo()
    {
        return $this->nameCo;
    }

    /**
     * Set professionCo
     *
     * @param string $professionCo
     *
     * @return PersonnalSouscription
     */
    public function setProfessionCo($professionCo)
    {
        $this->professionCo = $professionCo;

        return $this;
    }

    /**
     * Get professionCo
     *
     * @return string
     */
    public function getProfessionCo()
    {
        return $this->professionCo;
    }

    /**
     * Set numCniOrPassCo
     *
     * @param string $numCniOrPassCo
     *
     * @return PersonnalSouscription
     */
    public function setNumCniOrPassCo($numCniOrPassCo)
    {
        $this->numCniOrPassCo = $numCniOrPassCo;

        return $this;
    }

    /**
     * Get numCniOrPassCo
     *
     * @return string
     */
    public function getNumCniOrPassCo()
    {
        return $this->numCniOrPassCo;
    }

    /**
     * Set residenceCo
     *
     * @param string $residenceCo
     *
     * @return PersonnalSouscription
     */
    public function setResidenceCo($residenceCo)
    {
        $this->residenceCo = $residenceCo;

        return $this;
    }

    /**
     * Get residenceCo
     *
     * @return string
     */
    public function getResidenceCo()
    {
        return $this->residenceCo;
    }

    /**
     * Set bpCo
     *
     * @param string $bpCo
     *
     * @return PersonnalSouscription
     */
    public function setBpCo($bpCo)
    {
        $this->bpCo = $bpCo;

        return $this;
    }

    /**
     * Get bpCo
     *
     * @return string
     */
    public function getBpCo()
    {
        return $this->bpCo;
    }

    /**
     * Set gsmCo
     *
     * @param string $gsmCo
     *
     * @return PersonnalSouscription
     */
    public function setGsmCo($gsmCo)
    {
        $this->gsmCo = $gsmCo;

        return $this;
    }

    /**
     * Get gsmCo
     *
     * @return string
     */
    public function getGsmCo()
    {
        return $this->gsmCo;
    }

    /**
     * Set emailCo
     *
     * @param string $emailCo
     *
     * @return PersonnalSouscription
     */
    public function setEmailCo($emailCo)
    {
        $this->emailCo = $emailCo;

        return $this;
    }

    /**
     * Get emailCo
     *
     * @return string
     */
    public function getEmailCo()
    {
        return $this->emailCo;
    }
}

