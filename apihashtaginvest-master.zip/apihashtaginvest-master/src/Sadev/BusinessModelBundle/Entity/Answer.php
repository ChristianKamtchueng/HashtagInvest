<?php

namespace Sadev\BusinessModelBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use JMS\Serializer\Annotation as Serializer;
use JMS\Serializer\Annotation\VirtualProperty;

/**
 * Answer
 *
 * @ORM\Table(name="answer")
 * @ORM\Entity(repositoryClass="Sadev\BusinessModelBundle\Repository\AnswerRepository")
 */
class Answer extends Data
{
    

    /**
     * @var string
     *
     * @ORM\Column(name="activity", type="string", length=255)
     */
    private $activity;

    /**
     * @var float
     *
     * @ORM\Column(name="price", type="float")
     */
    private $price;

    /**
     * @var int
     *
     * @ORM\Column(name="qte", type="integer")
     */
    private $qte;

    /**
     * @var float
     *
     * @ORM\Column(name="accompte", type="float")
     */
    private $accompte;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text", nullable=true)
     */
    private $description;


    /**
	* @ORM\ManyToOne(targetEntity="Sadev\BusinessModelBundle\Entity\Business", inversedBy="answers")
    * @Serializer\Expose
	*/
	private $business;

    /**
	* @ORM\OneToOne(targetEntity="Sadev\BusinessModelBundle\Entity\Devis", inversedBy="answer")
	*/
	private $devis;


    /**
     * @var float
     *
     * @ORM\Column(name="tva", type="float", nullable=true)
     */
    private $tva;

    /**
     * Constructor
     */
    public function __construct()
    {
		parent::__construct();
        $this->setTypeData('answer');
    }

    /**
     * Set activity
     *
     * @param string $activity
     *
     * @return Answer
     */
    public function setActivity($activity)
    {
        $this->activity = $activity;

        return $this;
    }

    /**
     * Get activity
     *
     * @return string
     */
    public function getActivity()
    {
        return $this->activity;
    }

    /**
     * Set price
     *
     * @param float $price
     *
     * @return Answer
     */
    public function setPrice($price)
    {
        $this->price = $price;

        return $this;
    }

    /**
     * Get price
     *
     * @return float
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     * Set qte
     *
     * @param integer $qte
     *
     * @return Answer
     */
    public function setQte($qte)
    {
        $this->qte = $qte;

        return $this;
    }

    /**
     * Get qte
     *
     * @return int
     */
    public function getQte()
    {
        return $this->qte;
    }

    /**
     * Set accompte
     *
     * @param float $accompte
     *
     * @return Answer
     */
    public function setAccompte($accompte)
    {
        $this->accompte = $accompte;

        return $this;
    }

    /**
     * Get accompte
     *
     * @return float
     */
    public function getAccompte()
    {
        return $this->accompte;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return Answer
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set business
     *
     * @param \Sadev\BusinessModelBundle\Entity\Business $business
     *
     * @return Answer
     */
    public function setBusiness(\Sadev\BusinessModelBundle\Entity\Business $business = null)
    {
        $this->business = $business;

        return $this;
    }

    /**
     * Get business
     *
     * @return \Sadev\BusinessModelBundle\Entity\Business
     */
    public function getBusiness()
    {
        return $this->business;
    }

    /**
     * Set devis
     *
     * @param \Sadev\BusinessModelBundle\Entity\Devis $devis
     *
     * @return Answer
     */
    public function setDevis(\Sadev\BusinessModelBundle\Entity\Devis $devis = null)
    {
        $this->devis = $devis;

        return $this;
    }

    /**
     * Get devis
     *
     * @return \Sadev\BusinessModelBundle\Entity\Devis
     */
    public function getDevis()
    {
        return $this->devis;
    }

    /**
     * Set tva
     *
     * @param float $tva
     *
     * @return Answer
     */
    public function setTva($tva)
    {
        $this->tva = $tva;

        return $this;
    }

    /**
     * Get tva
     *
     * @return float
     */
    public function getTva()
    {
        return $this->tva;
    }
}
