<?php

namespace Sadev\BusinessModelBundle\Entity;

class PageStruct {
    /**
     * @var integer
     */
    public $id;

    /**
     * @var string
     */
    public $short_title;

    /**
     * @var string
     */
    public $slug;
}