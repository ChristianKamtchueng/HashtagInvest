<?php

namespace Sadev\BusinessModelBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use JMS\Serializer\Annotation as Serializer;
use JMS\Serializer\Annotation\VirtualProperty;
use JMS\Serializer\Annotation\SerializedName;
use JMS\Serializer\Annotation\Type;

/**
 * Publication
 *
 * @ORM\Table(name="publication")
 * @ORM\Entity(repositoryClass="Sadev\BusinessModelBundle\Repository\PublicationRepository")
 * @ORM\HasLifecycleCallbacks
 * @ORM\InheritanceType("JOINED")
 * @ORM\DiscriminatorColumn(name="discriminator", type="string")
 * @ORM\DiscriminatorMap({"publication"="Publication", "page"="Sadev\BusinessModelBundle\Entity\Page",  "article"="Sadev\BusinessModelBundle\Entity\Article"})
 * @Serializer\ExclusionPolicy("ALL")
 */
class Publication extends Data
{
   
    /**
     * @var string
     * @Serializer\Expose
     * @ORM\Column(name="titre", type="string", length=255, unique=true)
     */
    private $titre;

    /**
     * @var string
     * @Serializer\Expose
     * @ORM\Column(name="slug", type="string", length=255, unique=true)
     */
    private $slug;

    /**
     * @var string
     * @Serializer\Expose
     * @ORM\Column(name="description", type="text", nullable=true)
     */
    private $description;

    /**
     * @var int
     * @Serializer\Expose
     * @ORM\Column(name="nbrVue", type="integer")
     */
    private $nbrVue;

    /**
     * @var bool
     * @Serializer\Expose
     * @ORM\Column(name="isPublish", type="boolean")
     */
    private $isPublish;

    /**
     * @var \DateTime
     * @Serializer\Expose
     * @Type("DateTime<'Y-m-d H:i'>")
     * @ORM\Column(name="datePublish", type="datetime")
     */
    private $datePublish;

    
    public $publicationsSimilaires;



    /**
     * @var array
     * @Serializer\Expose
     * @ORM\Column(name="photo", type="array", nullable=true)
     */
    private $photo;


    public $photoSelected;



    /**
     * Constructor
     */
    public function __construct()
    {
		parent::__construct();
		
		$this->nbrVue = 0;
		$this->publier = false;
        $this->datePublish = new \DateTime();
        $this->setTypeData('publication');
    }


    /**
     * Set titre
     *
     * @param string $titre
     *
     * @return Publication
     */
    public function setTitre($titre)
    {
        $this->titre = $titre;

        return $this;
    }

    /**
     * Get titre
     *
     * @return string
     */
    public function getTitre()
    {
        return $this->titre;
    }

    /**
     * Set slug
     *
     * @param string $slug
     *
     * @return Publication
     */
    public function setSlug($slug)
    {
        $this->slug = $slug;

        return $this;
    }

    /**
     * Get slug
     *
     * @return string
     */
    public function getSlug()
    {
        return $this->slug;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return Publication
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set nbrVue
     *
     * @param integer $nbrVue
     *
     * @return Publication
     */
    public function setNbrVue($nbrVue)
    {
        $this->nbrVue = $nbrVue;

        return $this;
    }

    /**
     * Get nbrVue
     *
     * @return int
     */
    public function getNbrVue()
    {
        return $this->nbrVue;
    }

    /**
     * Set isPublish
     *
     * @param boolean $isPublish
     *
     * @return Publication
     */
    public function setIsPublish($isPublish)
    {
        $this->isPublish = $isPublish;

        return $this;
    }

    /**
     * Get isPublish
     *
     * @return bool
     */
    public function getIsPublish()
    {
        return $this->isPublish;
    }

    /**
     * Set datePublish
     *
     * @param \DateTime $datePublish
     *
     * @return Publication
     */
    public function setDatePublish($datePublish)
    {
        $this->datePublish = $datePublish;

        return $this;
    }

    /**
     * Get datePublish
     *
     * @return \DateTime
     */
    public function getDatePublish()
    {
        return $this->datePublish;
    }

   

    /**
     * Set photo
     *
     * @param array $photo
     *
     * @return Publication
     */
    public function setPhoto(\Sadev\BusinessModelBundle\Entity\Media $photo)
    {

        $media = array();
        $media['baseUrl'] = $photo->getBaseUrl();
        $media['hash'] = $photo->getHash();
        $media['mime'] = $photo->getMime();
        $media['name'] = $photo->getName();
        $media['path'] = $photo->getPath();
        $media['phash'] = $photo->getPhash();
        $media['size'] = $photo->getSize();
        $media['tmb'] = $photo->getTmb();
        $media['ts'] = $photo->getTs();
        $media['url'] = $photo->getUrl();
        $media['height'] = $photo->getHeight();
        $media['width'] = $photo->getWidth();
        $this->photo = $media;

        return $this;
    }

    /**
     * Get photo
     *
     * @return array
     */
    public function getPhoto()
    {
        return $this->photo;
    }

    /**
     * @VirtualProperty
     * @SerializedName("description_strip_tags")
     * @Type("string")
    **/
    public function descriptionStripTags()
    {
        return strip_tags( $this->description );
    }

    /**
     * @VirtualProperty
     * @SerializedName("publications_similaires")
     * @Type("array")
    **/
    public function getPublicationsSimilaires()
    {
        return   $this->publicationsSimilaires;
    }

}
