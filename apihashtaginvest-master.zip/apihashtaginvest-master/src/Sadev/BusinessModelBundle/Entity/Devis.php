<?php

namespace Sadev\BusinessModelBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Devis
 *
 * @ORM\Table(name="devis")
 * @ORM\Entity(repositoryClass="Sadev\BusinessModelBundle\Repository\DevisRepository")
 */
class Devis extends Data
{
    

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="datecommande", type="datetime")
     */
    private $datecommande;

    /**
	* @ORM\OneToOne(targetEntity="Sadev\BusinessModelBundle\Entity\Answer", mappedBy="devis")
    * @ORM\JoinColumn(nullable=false)
	*/
	private $answer; // la reponse selectionnee par le createur du business


    /**
    * @ORM\OneToMany(targetEntity="Sadev\BusinessModelBundle\Entity\DevisPayment", mappedBy="devis")
	*/
    private $devispayment;


    /**
     * Constructor
     */
    public function __construct()
    {
		parent::__construct();
        $this->setTypeData('devis');
    }

    /**
     * Set datecommande
     *
     * @param \DateTime $datecommande
     *
     * @return Devis
     */
    public function setDatecommande($datecommande)
    {
        $this->datecommande = $datecommande;

        return $this;
    }

    /**
     * Get datecommande
     *
     * @return \DateTime
     */
    public function getDatecommande()
    {
        return $this->datecommande;
    }

    /**
     * Set answer
     *
     * @param \Sadev\BusinessModelBundle\Entity\Answer $answer
     *
     * @return Devis
     */
    public function setAnswer(\Sadev\BusinessModelBundle\Entity\Answer $answer = null)
    {
        $this->answer = $answer;

        return $this;
    }

    /**
     * Get answer
     *
     * @return \Sadev\BusinessModelBundle\Entity\Answer
     */
    public function getAnswer()
    {
        return $this->answer;
    }

}
