<?php

namespace Sadev\BusinessModelBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use JMS\Serializer\Annotation as Serializer;
use JMS\Serializer\Annotation\VirtualProperty;

/**
 * Activity
 *
 * @ORM\Table(name="activity")
 * @ORM\Entity(repositoryClass="Sadev\BusinessModelBundle\Repository\ActivityRepository")
 */
class Activity extends Data
{
    

    /**
     * @var string
     *
     * @ORM\Column(name="designation", type="string", length=255, unique=true)
     */
    private $designation;

    /**
     * @var float
     *
     * @ORM\Column(name="cout", type="float")
     */
    private $cout;

    /**
     * @var bool
     *
     * @ORM\Column(name="coutChangeable", type="boolean")
     */
    private $coutChangeable;

    /**
     * @var int
     *
     * @ORM\Column(name="commission", type="integer")
     */
    private $commission;

    /**
     * @var bool
     *
     * @ORM\Column(name="commissionChangeable", type="boolean")
     */
    private $commissionChangeable;


    /**
     * @ORM\ManyToOne(targetEntity="Sadev\UserBundle\Entity\User")
     * @ORM\JoinColumn(nullable=true)
     */
    private $partner;


    /**
     * @var array|null|string
     *
     * @ORM\Column(name="commission_data", type="text", nullable=true)
     */
    private $commissionData;

        /**
     * @var string
     *
     * @ORM\Column(name="commission_type", type="string", length=255, nullable=false)
     */
    private $commissionType; // 'fixe' | 'pourcentage' | 'grille';


    /**
     * Constructor
     */
    public function __construct()
    {
		parent::__construct();
		
        $this->setTypeData('activity');
        $this->setCommissionType('pourcentage');
    }

    /**
     * Set designation
     *
     * @param string $designation
     *
     * @return Activity
     */
    public function setDesignation($designation)
    {
        $this->designation = $designation;

        return $this;
    }

    /**
     * Get designation
     *
     * @return string
     */
    public function getDesignation()
    {
        return $this->designation;
    }

    /**
     * Set cout
     *
     * @param float $cout
     *
     * @return Activity
     */
    public function setCout($cout)
    {
        $this->cout = $cout;

        return $this;
    }

    /**
     * Get cout
     *
     * @return float
     */
    public function getCout()
    {
        return $this->cout;
    }

    /**
     * Set coutChangeable
     *
     * @param boolean $coutChangeable
     *
     * @return Activity
     */
    public function setCoutChangeable($coutChangeable)
    {
        $this->coutChangeable = $coutChangeable;

        return $this;
    }

    /**
     * Get coutChangeable
     *
     * @return bool
     */
    public function getCoutChangeable()
    {
        return $this->coutChangeable;
    }

    /**
     * Set commission
     *
     * @param integer $commission
     *
     * @return Activity
     */
    public function setCommission($commission)
    {
        $this->commission = $commission;

        return $this;
    }

    /**
     * Get commission
     *
     * @return int
     */
    public function getCommission()
    {
        return $this->commission;
    }

    /**
     * Set commissionChangeable
     *
     * @param boolean $commissionChangeable
     *
     * @return Activity
     */
    public function setCommissionChangeable($commissionChangeable)
    {
        $this->commissionChangeable = $commissionChangeable;

        return $this;
    }

    /**
     * Get commissionChangeable
     *
     * @return bool
     */
    public function getCommissionChangeable()
    {
        return $this->commissionChangeable;
    }

    /**
     * Set partner
     *
     * @param \Sadev\UserBundle\Entity\User $partner
     *
     * @return Activity
     */
    public function setPartner(\Sadev\UserBundle\Entity\User $partner = null)
    {
        $this->partner = $partner;

        return $this;
    }

    /**
     * Get partner
     *
     * @return \Sadev\UserBundle\Entity\User
     */
    public function getPartner()
    {
        return $this->partner;
    }



    /**
     * Set commissionData
     *
     * @param array|null $commissionData
     *
     * @return Activity
     */
    public function setCommissionData($commissionData)
    {
        $this->commissionData = $commissionData;

        return $this;
    }

    /**
     * Get commissionData
     *
     * @return array|null
     */
    public function getCommissionData()
    {
        return $this->commissionData;
    }

    /**
     * Set commissionType
     *
     * @param string $commissionType
     *
     * @return Activity
     */
    public function setCommissionType($commissionType)
    {
        $this->commissionType = $commissionType;

        return $this;
    }

    /**
     * Get commissionType
     *
     * @return string
     */
    public function getCommissionType()
    {
        return $this->commissionType;
    }


    

    
}
