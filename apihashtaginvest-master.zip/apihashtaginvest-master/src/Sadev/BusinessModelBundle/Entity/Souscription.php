<?php

namespace Sadev\BusinessModelBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use JMS\Serializer\Annotation\Type;
use JMS\Serializer\Annotation as Serializer;

/**
 * Souscription
 *
 * @ORM\Table(name="souscription")
 * @ORM\Entity(repositoryClass="Sadev\BusinessModelBundle\Repository\SouscriptionRepository")
 * @ORM\HasLifecycleCallbacks()
 * @ORM\InheritanceType("JOINED")
 * @ORM\DiscriminatorColumn(name="discriminator", type="string")
 * @ORM\DiscriminatorMap({ "souscription"="Souscription", "personnal"="Sadev\BusinessModelBundle\Entity\PersonnalSouscription", "family"="Sadev\BusinessModelBundle\Entity\FamilySouscription", "enterprise"="Sadev\BusinessModelBundle\Entity\EnterpriseSouscription"})
 * @Serializer\ExclusionPolicy("ALL")
 */
class Souscription
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * @Serializer\Expose
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="numTitreFoncier", type="string", length=255, unique=true)
     * @Serializer\Expose
     */
    private $numTitreFoncier;

    /**
     * @var float
     *
     * @ORM\Column(name="superficie", type="float")
     * @Serializer\Expose
     */
    private $superficie;

    /**
     * @var string
     *
     * @ORM\Column(name="localisation", type="text")
     * @Serializer\Expose
     */
    private $localisation;

    /**
     * @var string
     *
     * @ORM\Column(name="numCertPro", type="string", length=255, unique=true)
     * @Serializer\Expose
     */
    private $numCertPro;

    /**
     * @var string
     *
     * @ORM\Column(name="numCertUrb", type="string", length=255, unique=true)
     * @Serializer\Expose
     */
    private $numCertUrb;

    /**
     * @var array
     *
     * @ORM\Column(name="description", type="array")
     * @Serializer\Expose
     */
    private $description;

    /**
     * @var string
     *
     * @ORM\Column(name="commentDescription", type="text", nullable=true)
     * @Serializer\Expose
     */
    private $commentDescription;

    /**
     * @var array
     *
     * @ORM\Column(name="projet", type="array")
     * @Serializer\Expose
     */
    private $projet;

    /**
     * @var float
     *
     * @ORM\Column(name="budgetDispo", type="float", nullable=true)
     * @Serializer\Expose
     */
    private $budgetDispo;

    /**
     * @var array
     *
     * @ORM\Column(name="financement", type="array")
     * @Serializer\Expose
     */
    private $financement;

    /**
     * @var array
     *
     * @ORM\Column(name="service", type="array")
     * @Serializer\Expose
     */
    private $service;

    /**
     * @var string
     *
     * @ORM\Column(name="commentService", type="text", nullable=true)
     * @Serializer\Expose
     */
    private $commentService;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="dateSouscription", type="datetime")
     * @Type("DateTime<'Y-m-d H:i'>")
     * @Serializer\Expose
     */
    private $dateSouscription;

    /**
     * @var string
     *
     * @ORM\Column(name="typeSouscription", type="string", length=255)
     * @Serializer\Expose
     */
    private $typeSouscription;

    /**
     * @var string
     *
     * @ORM\Column(name="paymentStatus", type="string", length=255, nullable=true)
     * @Serializer\Expose
     */
    private $paymentStatus;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="dateCreate", type="datetime", nullable=true)
     * @Type("DateTime<'Y-m-d H:i'>")
     * @Serializer\Expose
     */
    protected $dateCreate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="dateModif", type="datetime", nullable=true)
     * @Type("DateTime<'Y-m-d H:i'>")
     * @Serializer\Expose
     */
    protected $dateModif;

    /**
    * @ORM\ManyToOne(targetEntity="Sadev\UserBundle\Entity\User", cascade={"persist"})
    * @ORM\JoinColumn(nullable=true)
    * @Serializer\Expose
    */
    protected $createBy;

    /**
    * @ORM\ManyToOne(targetEntity="Sadev\UserBundle\Entity\User", cascade={"persist"})
    * @ORM\JoinColumn(nullable=true)
    * @Serializer\Expose
    */
    protected $user;


    /**
     * Constructor
     */
    public function __construct()
    {
        $this->dateCreate = new \DateTime();
    }


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set numTitreFoncier
     *
     * @param string $numTitreFoncier
     *
     * @return Souscription
     */
    public function setNumTitreFoncier($numTitreFoncier)
    {
        $this->numTitreFoncier = $numTitreFoncier;

        return $this;
    }

    /**
     * Get numTitreFoncier
     *
     * @return string
     */
    public function getNumTitreFoncier()
    {
        return $this->numTitreFoncier;
    }

    /**
     * Set superficie
     *
     * @param float $superficie
     *
     * @return Souscription
     */
    public function setSuperficie($superficie)
    {
        $this->superficie = $superficie;

        return $this;
    }

    /**
     * Get superficie
     *
     * @return float
     */
    public function getSuperficie()
    {
        return $this->superficie;
    }

    /**
     * Set localisation
     *
     * @param string $localisation
     *
     * @return Souscription
     */
    public function setLocalisation($localisation)
    {
        $this->localisation = $localisation;

        return $this;
    }

    /**
     * Get localisation
     *
     * @return string
     */
    public function getLocalisation()
    {
        return $this->localisation;
    }

    /**
     * Set numCertPro
     *
     * @param string $numCertPro
     *
     * @return Souscription
     */
    public function setNumCertPro($numCertPro)
    {
        $this->numCertPro = $numCertPro;

        return $this;
    }

    /**
     * Get numCertPro
     *
     * @return string
     */
    public function getNumCertPro()
    {
        return $this->numCertPro;
    }

    /**
     * Set numCertUrb
     *
     * @param string $numCertUrb
     *
     * @return Souscription
     */
    public function setNumCertUrb($numCertUrb)
    {
        $this->numCertUrb = $numCertUrb;

        return $this;
    }

    /**
     * Get numCertUrb
     *
     * @return string
     */
    public function getNumCertUrb()
    {
        return $this->numCertUrb;
    }

    /**
     * Set description
     *
     * @param array $description
     *
     * @return Souscription
     */
    public function setDescription($description)
    {

        $result = array();

        foreach($description as $elem) {

            if(in_array($elem, ['occupe', 'non_occupe', 'fin_exploitation']))
            $result[] = $elem;

        }
        
        $this->description = $result;

        return $this;

    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set commentDescription
     *
     * @param string $commentDescription
     *
     * @return Souscription
     */
    public function setCommentDescription($commentDescription)
    {
        $this->commentDescription = $commentDescription;

        return $this;
    }

    /**
     * Get commentDescription
     *
     * @return string
     */
    public function getCommentDescription()
    {
        return $this->commentDescription;
    }

    /**
     * Set projet
     *
     * @param array $projet
     *
     * @return Souscription
     */
    public function setProjet($projet)
    {

        $result = array();

        foreach($projet as $elem) {

            if(in_array($elem, ['habitations', 'appartements_meubles', 'commerces', 'bureaux']))
            $result[] = $elem;

        }
        
       
        $this->projet = $result;

        return $this;
    }

    /**
     * Get projet
     *
     * @return string
     */
    public function getProjet()
    {
        return $this->projet;
    }

    /**
     * Set budgetDispo
     *
     * @param float $budgetDispo
     *
     * @return Souscription
     */
    public function setBudgetDispo($budgetDispo)
    {
        $this->budgetDispo = $budgetDispo;

        return $this;
    }

    /**
     * Get budgetDispo
     *
     * @return float
     */
    public function getBudgetDispo()
    {
        return $this->budgetDispo;
    }

    /**
     * Set financement
     *
     * @param string $financement
     *
     * @return Souscription
     */
    public function setFinancement($financement)
    {

        $result = array();

        foreach($financement as $elem) {

            if(in_array($elem, ['salaire', 'emprunt_bancaire', 'tontines', 'heritage', 'economies']))
            $result[] = $elem;

        }

        $this->financement = $result;

        return $this;
    }

    /**
     * Get financement
     *
     * @return string
     */
    public function getFinancement()
    {
        return $this->financement;
    }

    /**
     * Set service
     *
     * @param string $service
     *
     * @return Souscription
     */
    public function setService($service)
    {

        $result = array();

        foreach($service as $elem) {

            if(in_array($elem, ['vente', 'location']))
            $result[] = $elem;

        }

        $this->service = $result;

        return $this;
    }

    /**
     * Get service
     *
     * @return string
     */
    public function getService()
    {
        return $this->service;
    }

    /**
     * Set commentService
     *
     * @param string $commentService
     *
     * @return Souscription
     */
    public function setCommentService($commentService)
    {
        $this->commentService = $commentService;

        return $this;
    }

    /**
     * Get commentService
     *
     * @return string
     */
    public function getCommentService()
    {
        return $this->commentService;
    }

    /**
     * Set dateSouscription
     *
     * @param \DateTime $dateSouscription
     *
     * @return Souscription
     */
    public function setDateSouscription($dateSouscription)
    {
        $this->dateSouscription = $dateSouscription;

        return $this;
    }

    /**
     * Get dateSouscription
     *
     * @return \DateTime
     */
    public function getDateSouscription()
    {
        return $this->dateSouscription;
    }

    /**
     * Set typeSouscription
     *
     * @param string $typeSouscription
     *
     * @return Souscription
     */
    public function setTypeSouscription($typeSouscription)
    {
        $this->typeSouscription = $typeSouscription;

        return $this;
    }

    /**
     * Get typeSouscription
     *
     * @return string
     */
    public function getTypeSouscription()
    {
        return $this->typeSouscription;
    }

    /**
     * Set paymentStatus
     *
     * @param string $paymentStatus
     *
     * @return Souscription
     */
    public function setPaymentStatus($paymentStatus)
    {
        $this->paymentStatus = $paymentStatus;

        return $this;
    }

    /**
     * Get paymentStatus
     *
     * @return string
     */
    public function getPaymentStatus()
    {
        return $this->paymentStatus;
    }

    /**
     * Set dateCreate
     *
     * @param \DateTime $dateCreate
     *
     * @return Souscription
     */
    public function setDateCreate($dateCreate)
    {
        $this->dateCreate = $dateCreate;

        return $this;
    }

    /**
     * Get dateCreate
     *
     * @return \DateTime
     */
    public function getDateCreate()
    {
        return $this->dateCreate;
    }

    /**
     * Set dateModif
     *
     * @param \DateTime $dateModif
     *
     * @return Souscription
     */
    public function setDateModif($dateModif)
    {
        $this->dateModif = $dateModif;

        return $this;
    }

    /**
     * Get dateModif
     *
     * @return \DateTime
     */
    public function getDateModif()
    {
        return $this->dateModif;
    }

    /**
     * Set createBy
     *
     * @param \Sadev\UserBundle\Entity\User $createBy
     *
     * @return Souscription
     */
    public function setCreateBy(\Sadev\UserBundle\Entity\User $createBy = null)
    {
        $this->createBy = $createBy;

        return $this;
    }

    /**
     * Get createBy
     *
     * @return \Sadev\UserBundle\Entity\User
     */
    public function getCreateBy()
    {
        return $this->createBy;
    }

    /**
    * @ORM\PreUpdate
    */
    public function updateDate()
    {
		//  Attention, l'évènement update n'est pas déclenché à la création d'une entité, mais seulement à sa modification : c'est parfaitement ce qu'on veut dans notre cas.
        //  il faut que vous ayez modifié au moins un attribut pour que l'EntityManager génère une requête et donc déclenche cet évènement.
        $this->dateModif = new \Datetime();
    }


    /**
     * Set user
     *
     * @param \Sadev\UserBundle\Entity\User $user
     *
     * @return Souscription
     */
    public function setUser(\Sadev\UserBundle\Entity\User $user = null)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user
     *
     * @return \Sadev\UserBundle\Entity\User
     */
    public function getUser()
    {
        return $this->user;
    }
}
