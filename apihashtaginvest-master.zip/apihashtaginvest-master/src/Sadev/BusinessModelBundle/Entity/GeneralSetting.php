<?php

namespace Sadev\BusinessModelBundle\Entity;


class GeneralSetting
{
   

    private $slogan;

   
    private $description;

   
    private $titre;


    private $logo;

    
    private $email;

    private $telephone;

   
    private $adresse;

   
    private $map;

    private $partenaire;



    public function setSlogan($slogan)
    {
        $this->slogan = $slogan;

        return $this;
    }

   
    public function getSlogan()
    {
        return $this->slogan;
    }

    
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    
    public function getDescription()
    {
        return $this->description;
    }

    
    public function setTitre($titre)
    {
        $this->titre = $titre;

        return $this;
    }

   
    public function getTitre()
    {
        return $this->titre;
    }

   
    public function setLogo($logo)
    {
        $this->logo = $logo;

        return $this;
    }

    
    public function getLogo()
    {
        return $this->logo;
    }

   
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    
    public function getEmail()
    {
        return $this->email;
    }

    
    public function setTelephone($telephone)
    {
        $this->telephone = $telephone;

        return $this;
    }

    
    public function getTelephone()
    {
        return $this->telephone;
    }

    
    public function setAdresse($adresse)
    {
        $this->adresse = $adresse;

        return $this;
    }

    
    public function getAdresse()
    {
        return $this->adresse;
    }

    
    public function setMap($map)
    {
        $this->map = $map;

        return $this;
    }

    
    public function getMap()
    {
        return $this->map;
    }

    public function setPartenaire($partenaire)
    {
        $this->partenaire = $partenaire;

        return $this;
    }

    
    public function getPartenaire()
    {
        return $this->partenaire;
    }

    
    public function file()
    {
        $dir ='settings';
        if(!is_dir($dir)) {
            mkdir($dir); // si le dossier setting n'existe pas on le créer
            chmod($dir, 0777);
        }

        $file = $dir.='/general.txt';
    
       /* if(!is_file($file)) {
            $fp = fopen($file, 'w');
            fwrite($fp, '');
            fclose($fp);
            chmod($file, 0777);
        } */

        return $file;

    }

    public function save()
    {
		$store = serialize ($this);
		file_put_contents($this->file(), $store, true);
    }

    public function hydrate()
    {

        $setting = new GeneralSetting;

        if ( file_exists($this->file())) {
            
            $store = file_get_contents($this->file());
            $setting = unserialize($store);
        }

        return  $setting;

    }
	
}

