<?php

namespace Sadev\BusinessModelBundle\Entity;


class Media
{
   
    private $baseUrl;

    private $hash;

    private $mime;

    private $name;

    private $path;

    private $phash;

    private $size;

    private $tmb;

    private $ts;

    private $url;

    private $width;

    private $height;

   
    /**
     * Set baseUrl
     *
     * @param string $baseUrl
     *
     * @return Media
     */
    public function setBaseUrl($baseUrl)
    {
        $this->baseUrl = $baseUrl;

        return $this;
    }

    /**
     * Get baseUrl
     *
     * @return string
     */
    public function getBaseUrl()
    {
        return $this->baseUrl;
    }

    /**
     * Set hash
     *
     * @param string $hash
     *
     * @return Media
     */
    public function setHash($hash)
    {
        $this->hash = $hash;

        return $this;
    }

    /**
     * Get hash
     *
     * @return string
     */
    public function getHash()
    {
        return $this->hash;
    }

    /**
     * Set mime
     *
     * @param string $mime
     *
     * @return Media
     */
    public function setMime($mime)
    {
        $this->mime = $mime;

        return $this;
    }

    /**
     * Get mime
     *
     * @return string
     */
    public function getMime()
    {
        return $this->mime;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return Media
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set path
     *
     * @param string $path
     *
     * @return Media
     */
    public function setPath($path)
    {
        $this->path = $path;

        return $this;
    }

    /**
     * Get path
     *
     * @return string
     */
    public function getPath()
    {
        return $this->path;
    }

    /**
     * Set phash
     *
     * @param string $phash
     *
     * @return Media
     */
    public function setPhash($phash)
    {
        $this->phash = $phash;

        return $this;
    }

    /**
     * Get phash
     *
     * @return string
     */
    public function getPhash()
    {
        return $this->phash;
    }


    /**
     * Set size
     *
     * @param integer $size
     *
     * @return Media
     */
    public function setSize($size)
    {
        $this->size = $size;

        return $this;
    }

    /**
     * Get size
     *
     * @return int
     */
    public function getSize()
    {
        return $this->size;
    }

    /**
     * Set tmb
     *
     * @param string $tmb
     *
     * @return Media
     */
    public function setTmb($tmb)
    {
        $this->tmb = $tmb;

        return $this;
    }

    /**
     * Get tmb
     *
     * @return string
     */
    public function getTmb()
    {
        return $this->tmb;
    }

    /**
     * Set ts
     *
     * @param integer $ts
     *
     * @return Media
     */
    public function setTs($ts)
    {
        $this->ts = $ts;

        return $this;
    }

    /**
     * Get ts
     *
     * @return int
     */
    public function getTs()
    {
        return $this->ts;
    }

    /**
     * Set url
     *
     * @param string $url
     *
     * @return Media
     */
    public function setUrl($url)
    {
        $this->url = $url;

        return $this;
    }

    /**
     * Get url
     *
     * @return string
     */
    public function getUrl()
    {
        return $this->url;
    }

    /**
     * Set width
     *
     * @param integer $width
     *
     * @return Media
     */
    public function setWidth($width)
    {
        $this->width = $width;

        return $this;
    }

    /**
     * Get width
     *
     * @return int
     */
    public function getWidth()
    {
        return $this->width;
    }

    /**
     * Set height
     *
     * @param integer $height
     *
     * @return Media
     */
    public function setHeight($height)
    {
        $this->height = $height;

        return $this;
    }

    /**
     * Get height
     *
     * @return int
     */
    public function getHeight()
    {
        return $this->height;
    }


}

