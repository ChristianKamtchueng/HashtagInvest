<?php

namespace Sadev\BusinessModelBundle\Entity;


class NetworkSetting
{
   

    
    private $facebook;

   
    private $twitter;

   
    private $linkedin;

   
    private $instagram;

   
    private $youtube;

   
    private $viadeo;

   
    private $pinterest;



    
    public function setFacebook($facebook)
    {
        $this->facebook = $facebook;

        return $this;
    }

    
    public function getFacebook()
    {
        return $this->facebook;
    }

    
    public function setTwitter($twitter)
    {
        $this->twitter = $twitter;

        return $this;
    }

   
    public function getTwitter()
    {
        return $this->twitter;
    }

    
    public function setLinkedin($linkedin)
    {
        $this->linkedin = $linkedin;

        return $this;
    }

   
    public function getLinkedin()
    {
        return $this->linkedin;
    }

    
    public function setInstagram($instagram)
    {
        $this->instagram = $instagram;

        return $this;
    }

   
    public function getInstagram()
    {
        return $this->instagram;
    }

    
    public function setYoutube($youtube)
    {
        $this->youtube = $youtube;

        return $this;
    }

   
    public function getYoutube()
    {
        return $this->youtube;
    }

    
    public function setViadeo($viadeo)
    {
        $this->viadeo = $viadeo;

        return $this;
    }

  
    public function getViadeo()
    {
        return $this->viadeo;
    }

    
    public function setPinterest($pinterest)
    {
        $this->pinterest = $pinterest;

        return $this;
    }

    
    public function getPinterest()
    {
        return $this->pinterest;
    }

    public function file()
    {
        $dir ='settings';
        if(!is_dir($dir)) {
            mkdir($dir); // si le dossier setting n'existe pas on le créer
            chmod($dir, 0777);
        }

        $file = $dir.='/network.txt';
    
       /* if(!is_file($file)) {
            $fp = fopen($file, 'w');
            fwrite($fp, '');
            fclose($fp);
            chmod($file, 0777);
        } */

        return $file;

    }

    public function save()
    {
		$store = serialize ($this);
		file_put_contents($this->file(), $store, true);
    }

    public function hydrate()
    {

        $setting = new NetworkSetting;

        if ( file_exists($this->file())) {
            
            $store = file_get_contents($this->file());
            $setting = unserialize($store);
        }

        return  $setting;

    }
}

