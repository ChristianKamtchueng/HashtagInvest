<?php

namespace Sadev\BusinessModelBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * DevisPayment
 *
 * @ORM\Table(name="devis_payment")
 * @ORM\Entity(repositoryClass="Sadev\BusinessModelBundle\Repository\DevisPaymentRepository")
 */
class DevisPayment extends Data
{
    

    /**
     * @var float
     *
     * @ORM\Column(name="amount", type="float")
     */
    private $amount;

    /**
     * @var string
     *
     * @ORM\Column(name="metadata", type="text", nullable=true)
     */
    private $metadata;

    /**
	* @ORM\ManyToOne(targetEntity="Sadev\BusinessModelBundle\Entity\Devis", inversedBy="devispayment")
    * @ORM\JoinColumn(nullable=false)
	*/
	private $devis; 


   /**
     * Constructor
     */
    public function __construct()
    {
		parent::__construct();
        $this->setTypeData('devispayment');
    }

    /**
     * Set amount
     *
     * @param float $amount
     *
     * @return DevisPayment
     */
    public function setAmount($amount)
    {
        $this->amount = $amount;

        return $this;
    }

    /**
     * Get amount
     *
     * @return float
     */
    public function getAmount()
    {
        return $this->amount;
    }

    /**
     * Set metadata
     *
     * @param string $metadata
     *
     * @return DevisPayment
     */
    public function setMetadata($metadata)
    {
        $this->metadata = $metadata;

        return $this;
    }

    /**
     * Get metadata
     *
     * @return string
     */
    public function getMetadata()
    {
        return $this->metadata;
    }

    /**
     * Set devis
     *
     * @param \Sadev\BusinessModelBundle\Entity\Devis $devis
     *
     * @return DevisPayment
     */
    public function setDevis(\Sadev\BusinessModelBundle\Entity\Devis $devis)
    {
        $this->devis = $devis;

        return $this;
    }

    /**
     * Get devis
     *
     * @return \Sadev\BusinessModelBundle\Entity\Devis
     */
    public function getDevis()
    {
        return $this->devis;
    }
}
