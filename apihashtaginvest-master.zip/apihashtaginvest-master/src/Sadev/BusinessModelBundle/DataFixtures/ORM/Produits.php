<?php
// src/Sadev\BusinessModelBundle/DataFixtures/ORM/Produits.php

namespace Sadev\BusinessModelBundle\DataFixtures\ORM;
use Doctrine\Common\DataFixtures\FixtureInterface;
use Doctrine\Common\Persistence\ObjectManager;
use Sadev\BusinessModelBundle\Entity\Produit;
class Produits implements FixtureInterface
{
  // Dans l'argument de la méthode load, l'objet $manager est l'EntityManager
  public function load(ObjectManager $manager)
  {
    // Liste des noms de catégorie à ajouter

    /*
    $noms = array('Symfony2', 'Doctrine2', 'Tutoriel', 'Évènement');
    foreach($noms as $i => $nom)
    {
      $liste_produit[$i] = new Categorie();
      $liste_produit[$i]->setNom($nom);
      $manager->persist($liste_produit[$i]);
    } 
    */

    $produit = new Produit();
    $produit->setFrss('sp');
    $produit->setType('CAN PLAN');
    $produit->setFamille('BG');
    $produit->setDesignation('Can. Buble Up Lemon');
    $produit->setPrixAchat(5600);
    $produit->setPrixIntermediaire(6000);
    $produit->setPrixDetail(8000);
    $produit->setPrixDeGros(5800);
    $manager->persist($produit);
    // On déclenche l'enregistrement
    $manager->flush();


  }

}