<?php

namespace Sadev\BusinessModelBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;

class MediaType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
        ->add('baseUrl')
        ->add('hash')
        ->add('mime')
        ->add('name')
        ->add('path')
        ->add('phash')
        ->add('size', IntegerType::class)
        ->add('tmb')
        ->add('width')
        ->add('height')
        ->add('ts', IntegerType::class)
        ->add('url');
    }
    
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Sadev\BusinessModelBundle\Entity\Media'
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'sadev_businessmodelbundle_media';
    }


}
