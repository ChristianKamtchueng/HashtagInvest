<?php

namespace Sadev\BusinessModelBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;

class MenuItemType extends AbstractType
{

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
        ->add('name')
        ->add('id')
        /* ->add('icon')
        ->add('title')
        ->add('typeTarget')
        ->add('target', IntegerType::class)
        ->add('href') */
        ->add('childrens', CollectionType::class, [
            'entry_type' => CopyMenuItemType::class,
            'allow_add' => true,
            'allow_delete'=>true,
            'error_bubbling' => false,
        ])
        ->add('options', CollectionType::class, [
            //'entry_type' => MenuItemType::class,
            'allow_add' => true,
            'allow_delete'=>true,
            'error_bubbling' => false,
        ]);
    }
    
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Sadev\BusinessModelBundle\Entity\MenuItem'
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'sadev_businessmodelbundle_menuitem';
    }


}
