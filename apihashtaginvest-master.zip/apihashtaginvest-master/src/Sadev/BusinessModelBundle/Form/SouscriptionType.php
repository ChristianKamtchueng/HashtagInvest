<?php

namespace Sadev\BusinessModelBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

use Symfony\Component\Form\Extension\Core\Type\CollectionType;

class SouscriptionType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
        ->add('numTitreFoncier')
        ->add('superficie')
        ->add('localisation')
        ->add('numCertPro')
        ->add('numCertUrb')
        ->add('description', CollectionType::Class, [
              'description' => " Valeurs possibles: 'occupe'; 'non_occupe'; 'fin_exploitation' ",
              'allow_add' => true,
              'allow_delete'=>true,
              'error_bubbling' => false,])
        ->add('commentDescription')
        ->add('projet', CollectionType::Class, [
            'description' => " Valeurs possibles: 'habitations', 'appartements_meubles', 'commerces', 'bureaux' ",
            'allow_add' => true,
            'allow_delete'=>true,
            'error_bubbling' => false,])
        ->add('budgetDispo')
        ->add('financement', CollectionType::Class, [
            'description' => " Valeurs possibles: 'salaire', 'emprunt_bancaire', 'tontines', 'heritage', 'economies' ",
            'allow_add' => true,
            'allow_delete'=>true,
            'error_bubbling' => false,])
        ->add('service', CollectionType::Class, [
            'description' => " Valeurs possibles: 'vente', 'location' ",
            'allow_add' => true,
            'allow_delete'=>true,
            'error_bubbling' => false,])
        ->add('commentService')
        ->add('dateSouscription')
        ->add('user')
        //->add('typeSouscription')
        //->add('paymentStatus')
        ;
        /* ->add('dateCreate')
        ->add('dateModif')
        ->add('createBy') */
    }
    
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Sadev\BusinessModelBundle\Entity\Souscription',
            'csrf_protection' => false,
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'sadev_businessmodelbundle_souscription';
    }


}
