<?php

namespace Sadev\BusinessModelBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\BirthdayType;


class FamilySouscriptionType extends SouscriptionType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {

        // On fait appel à la méthode buildForm du parent, qui va ajouter tous les champs à $builder
        parent::buildForm($builder, $options);

        $builder
        ->add('familyName')
        ->add('nameRep')
        ->add('birthdayRep', BirthdayType::class, [
            'description' => " date de naissance "])
        ->add('birthplaceRep')
        ->add('sexeRep', TextType::Class, [
            'description' => " 2 valeurs possibles: 'homme', 'femme', "])
        ->add('nationalityRep')
        ->add('residenceRep')
        ->add('idCniOrPassRep')
        ->add('numGrosseRep')
        ->add('bpRep')
        ->add('gsmRep')
        ->add('emailRep')
        ;

    }
    
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Sadev\BusinessModelBundle\Entity\FamilySouscription',
            'csrf_protection' => false,
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'sadev_businessmodelbundle_familysouscription';
    }


}
