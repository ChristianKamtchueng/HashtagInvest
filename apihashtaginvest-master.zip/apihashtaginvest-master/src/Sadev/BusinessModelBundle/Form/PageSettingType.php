<?php

namespace Sadev\BusinessModelBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class PageSettingType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
        ->add('apropos')
        ->add('vision')
        ->add('mission')
        ->add('actionnariat')
        ->add('programme')
        ->add('egibilite')
        ->add('souscription')
        ->add('reclamation')
        ->add('promotion')
        ->add('economie')
        ->add('organisation')
        ->add('creation')
        ;
    }
    
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Sadev\BusinessModelBundle\Entity\PageSetting',
            'csrf_protection' => false,
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'sadev_businessmodelbundle_pagesetting';
    }


}
