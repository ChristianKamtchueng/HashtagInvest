<?php

namespace Sadev\BusinessModelBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;

class MessageType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
        ->add('sender')
        ->add('email')
        ->add('phone')
        ->add('objet')
        ->add('content')
        ->add('filesdata', CollectionType::class, [
            'entry_type' => FichierType::class,
            'description' => " Tableau de fichiers representant les pièces jointes du message",
            'required' => false,
        ])
        ;
    }
    
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Sadev\BusinessModelBundle\Entity\Message',
            'csrf_protection' => false,
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'sadev_businessmodelbundle_message';
    }


}
