<?php

namespace Sadev\BusinessModelBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

use Symfony\Component\Form\Extension\Core\Type\NumberType;


class SettingType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
		
        $builder
        ->add('deleguePoste', NumberType::Class, [
            'description' => " sauvegarde l'id du poste du délégué "
        ])
        ->add('executiveEntity', NumberType::Class, [
            'description' => " sauvegarde l'id de l'entité exécutif "
        ])
        ->add('departmentEntity', NumberType::Class, [
            'description' => " sauvegarde l'id de l'entité parent de tous les déparatements "
        ])
        ->add('mulatoPersonnelAccount', NumberType::Class, [
            'description' => " sauvegarde l'id du personnel mulato"
        ]);

        
        
    }
    
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Sadev\BusinessModelBundle\Entity\Setting',
            'csrf_protection' => false
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'sadev_businessmodelbundle_setting';
    }

	
	
}
