<?php

namespace Sadev\BusinessModelBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class NetworkSettingType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
        ->add('facebook')
        ->add('twitter')
        ->add('linkedin')
        ->add('instagram')
        ->add('youtube')
        ->add('viadeo')
        ->add('pinterest');
    }
    
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Sadev\BusinessModelBundle\Entity\NetworkSetting',
            'csrf_protection' => false,
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'sadev_businessmodelbundle_networksetting';
    }


}
