<?php

namespace Sadev\BusinessModelBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Sadev\BusinessModelBundle\Form\DataTransformer\StringToDateTimeTransformer;

class BusinessType extends DataType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
        ->add('domaine')
        ->add('metier')
        ->add('speciality')
        ->add('activity')
        ->add('description')
        ->add('budget')
        ->add('ville')
        ->add('bienType')
        ->add('status')
        ->add('surface')
        ->add('pieceNbr')
        ->add('transactionRef')
        ->add('adresse')
        ->add('transactionPrice')
        ->add('contact')
        ->add('transactionConditions')
        ->add('withPartner')
        ->add('imagePrincipale')
        ->add('nomclient')
        ->add('prenomclient')
        ->add('statusclient')
        ->add('raisonclient')
        ->add('siretclient')
        ->add('emailclient')
        ->add('telclient')
        ->add('villeclient')
        ->add('adresseclient')
        ->add('surfacehabitable')
        ->add('nbrpiece')
        ->add('nbrchambre')
        ->add('nbrsallebain')
        ->add('nbrwc')
        ->add('nbretage')
        ->add('etagebien')
        ->add('rez_de_chaussee')
        ->add('dernieretage')
        ->add('ascenseur')
        ->add('anneeconstruction')
        ->add('previsiontravaux')
        ->add('typexterieur', CollectionType::class, [
            'entry_type'    => TextType::class,
            'allow_add'     => true,
            'allow_delete'  => true,
            'prototype'     => true,
            'by_reference'  => false, // important pour que l'array soit modifié correctement
            'required'      => false,
        ])
        ->add('normepmr')
        ->add('classedpe')
        ->add('classeges')
        ->add('descriptionbiensynthetique')
        ->add('statusoccupation')
        ->add('loyermensuelle')
        ->add('chargesrecuperables')
        ->add('chargesnonrecuperables')
        ->add('typbail')
        ->add('datedebutbail', TextType::class, [
            'required' => false,
        ])
        ->add('datefinbail', TextType::class, [
            'required' => false,
        ])
        ->add('locataireajourdesloyer')
        ->add('typeviager')
        ->add('bouquetviager')
        ->add('rentemensuelleviager')
        ->add('indexationviager')
        ->add('methodeindexationviager')
        ->add('ageviager')
        ->add('nbrcredirentiersviager')
        ->add('statusconjugalviager')
        ->add('duhviager')
        ->add('vendeuroccupantviager')
        ->add('repartitionchargesviager')
        ->add('inclushonoraires')
        ->add('modecalculhonoraire')
        ->add('montanthonoraires')
        ->add('chargecopropriete')
        ->add('taxefonciere')
        ->add('nummandat')
        ;

        // Ajouter les transformateurs pour les champs de date
        $builder->get('datedebutbail')->addModelTransformer(new StringToDateTimeTransformer());
        $builder->get('datefinbail')->addModelTransformer(new StringToDateTimeTransformer());
    }/**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Sadev\BusinessModelBundle\Entity\Business',
            'csrf_protection' => false,
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'sadev_businessmodelbundle_business';
    }


}
