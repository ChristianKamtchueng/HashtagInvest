<?php

namespace Sadev\BusinessModelBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

use Symfony\Component\Form\Extension\Core\Type\TextType;

use Symfony\Component\Form\Extension\Core\Type\BirthdayType;

class PersonnalSouscriptionType extends SouscriptionType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {

        // On fait appel à la méthode buildForm du parent, qui va ajouter tous les champs à $builder
        parent::buildForm($builder, $options);

        $builder
        ->add('nom')
        ->add('prenom')
        ->add('birthday', BirthdayType::class, [
            'description' => " date de naissance "])
        ->add('birthplace')
        ->add('sexe', TextType::Class, [
              'description' => " 2 valeurs possibles: 'homme', 'femme', "])
        ->add('nationality')
        ->add('profession')
        ->add('residence')
        ->add('idCniOrPass')
        ->add('bp')
        ->add('gsm')
        ->add('email')
        ->add('nameCo')
        ->add('professionCo')
        ->add('numCniOrPassCo')
        ->add('residenceCo')
        ->add('bpCo')
        ->add('gsmCo')
        ->add('emailCo')
        ;
    }
    
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
          'data_class' => 'Sadev\BusinessModelBundle\Entity\PersonnalSouscription',
          'csrf_protection' => false,
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'sadev_businessmodelbundle_personnalsouscription';
    }


}
