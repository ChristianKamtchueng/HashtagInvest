<?php

namespace Sadev\BusinessModelBundle\Form\DataTransformer;

use Symfony\Component\Form\DataTransformerInterface;
use Symfony\Component\Form\Exception\TransformationFailedException;

class StringToDateTimeTransformer implements DataTransformerInterface
{
    /**
     * Transforme DateTime en string ISO (pour l'affichage)
     */
    public function transform($value)
    {
        if ($value === null) {
            return '';
        }

        if ($value instanceof \DateTime) {
            return $value->format('Y-m-d');
        }

        return $value;
    }

    /**
     * Transforme string ISO en DateTime (à la soumission du formulaire)
     */
    public function reverseTransform($value)
    {
        if ($value === null || $value === '') {
            return null;
        }

        if (!is_string($value)) {
            throw new TransformationFailedException('Expected a string');
        }

        try {
            $dateTime = \DateTime::createFromFormat('Y-m-d', $value);
            if (!$dateTime) {
                throw new TransformationFailedException(
                    'Invalid date format. Expected Y-m-d format.'
                );
            }
            return $dateTime;
        } catch (\Exception $e) {
            throw new TransformationFailedException('Could not transform string to DateTime: ' . $e->getMessage());
        }
    }
}
