Symfony Standard Edition
========================

Welcome to the Symfony Standard Edition - a fully-functional Symfony
application that you can use as the skeleton for your new applications.

For details on how to download and get started with Symfony, see the
[Installation][1] chapter of the Symfony Documentation.

What's inside?
--------------

The Symfony Standard Edition is configured with the following defaults:

  * An AppBundle you can use to start coding;

  * Twig as the only configured template engine;

  * Doctrine ORM/DBAL;

  * Swiftmailer;

  * Annotations enabled for everything.

It comes pre-configured with the following bundles:

  * **FrameworkBundle** - The core Symfony framework bundle

  * [**SensioFrameworkExtraBundle**][6] - Adds several enhancements, including
    template and routing annotation capability

  * [**DoctrineBundle**][7] - Adds support for the Doctrine ORM

  * [**TwigBundle**][8] - Adds support for the Twig templating engine

  * [**SecurityBundle**][9] - Adds security by integrating Symfony's security
    component

  * [**SwiftmailerBundle**][10] - Adds support for Swiftmailer, a library for
    sending emails

  * [**MonologBundle**][11] - Adds support for Monolog, a logging library

  * **WebProfilerBundle** (in dev/test env) - Adds profiling functionality and
    the web debug toolbar

  * **SensioDistributionBundle** (in dev/test env) - Adds functionality for
    configuring and working with Symfony distributions

  * [**SensioGeneratorBundle**][13] (in dev env) - Adds code generation
    capabilities

  * [**WebServerBundle**][14] (in dev env) - Adds commands for running applications
    using the PHP built-in web server

  * **DebugBundle** (in dev/test env) - Adds Debug and VarDumper component
    integration

All libraries and bundles included in the Symfony Standard Edition are
released under the MIT or BSD license.

Enjoy!

[1]:  https://symfony.com/doc/3.4/setup.html
[6]:  https://symfony.com/doc/current/bundles/SensioFrameworkExtraBundle/index.html
[7]:  https://symfony.com/doc/3.4/doctrine.html
[8]:  https://symfony.com/doc/3.4/templating.html
[9]:  https://symfony.com/doc/3.4/security.html
[10]: https://symfony.com/doc/3.4/email.html
[11]: https://symfony.com/doc/3.4/logging.html
[13]: https://symfony.com/doc/current/bundles/SensioGeneratorBundle/index.html
[14]: https://symfony.com/doc/current/setup/built_in_web_server.html


### composer
php -d memory_limit=-1 composer.phar install
php -d memory_limit=-1 composer.phar update


### ajout manuelle dependence symfony  intervention\image

1. Copier le dossier de la bibliothèque
Place le dossier intervention (contenant le code de la bibliothèque) dans le  répertoire vendor de ton projet, par exemple :
f:\wamp64\www\hashtag invest\api-hashtag-invest\vendor\
2. Configurer l’autoloading
Ajoute ou adapte l’autoload PSR-4 dans ton composer.json pour inclure ce chemin si besoin :

"autoload": {
    "psr-4": {
        "Intervention\\Image\\": "vendor/intervention/image/src/Intervention/Image/"
        // ...autres namespaces...
    }
    // ...existing code...
},

3. Regénérer l’autoloader
Même sans installer de dépendance, tu dois régénérer l’autoloader pour que Symfony reconnaisse la bibliothèque :

$ php composer.phar dump-autoload




#### Voici les commandes les plus utiles :

# La base
$ cd dossierDeBaseDuProjetSymfony

$ php bin/console

$ php bin/console server:run

$ php bin/console cache:clear

$ cd dossierDeBaseDuProjetSymfony
 
$ php bin/console
 
$ php bin/console cache:clear


Travailler avec la BD
# Supprime la BD
$ php bin/console doctrine:database:drop

# Crée la BD
$ php bin/console doctrine:database:create

# Crée les tables
$ php bin/console doctrine:schema:create

# Force la mise à jour du schéma
$ php bin/console doctrine:schema:update --force

# Affiche le SQL
$ php bin/console doctrine:schema:update --dump-sql

# Supprime la BD
$ php bin/console doctrine:database:drop
 
# Crée la BD
$ php bin/console doctrine:database:create
 
# Crée les tables
$ php bin/console doctrine:schema:create
 
# Force la mise à jour du schéma
$ php bin/console doctrine:schema:update --force

# Affiche le SQL
$ php bin/console doctrine:schema:update --dump-sql

Charger les données de tests (fixtures)
$ php bin/console doctrine:fixtures:load

$ php bin/console doctrine:fixtures:load

Exécuter une requête SQL
$ php bin/console doctrine:query:sql "select * from nomTable"


Générer une entité
$ php bin/console doctrine:generate:entity 


ReGénérer une entité avec getteur et setteur
$ php bin/console doctrine:generate:entities SadevBusinessModelBundle:Payment

Génération form type
$ php bin/console doctrine:generate:form SadevBusinessModelBundle:Activity

# Use different PHP version CLI executable for one command
alias php='/usr/bin/php7.0'
